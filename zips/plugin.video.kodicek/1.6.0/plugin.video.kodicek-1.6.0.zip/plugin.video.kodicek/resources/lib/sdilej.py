# -*- coding: utf-8 -*-
from __future__ import annotations
import requests
import re
import html
import logging
import pickle
import os
import time
import string
import sys
from urllib.parse import quote, urljoin, urlparse
from typing import Optional, Tuple, List, Dict, Any

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    import xbmcgui
    import xbmcplugin
    xbmc.log("Sdilej.py LOADED – rev 2025-07-07 final slug edition", level=xbmc.LOGINFO)
    ADDON = xbmcaddon.Addon()
    PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)
    COOKIE_FILE = os.path.join(PROFILE_DIR, 'sd_cookies.pkl')
except ImportError:
# Fallback for local testing
    ADDON = None
    COOKIE_FILE = 'sd_cookies.pkl'
    LOGGER = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG)

# --- Globálne premenné pre ochranu pred floodom ---
_login_attempts = 0
_last_login_attempt_time = 0

# --- Základné nastavenie ---
UA = 'okhttp/4.9.3'
_sess = requests.Session()
_sess.headers.update({
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'cs,sk;q=0.8,en-US;q=0.5,en;q=0.3',
})
BASE_URL = 'https://www.sdilej.cz'
API_BASE_URL = 'https://sdilej.cz/api/v2'
LOGGER = logging.getLogger(__name__)

class SdilejError(Exception):
    """Custom exception for Sdilej.cz errors."""
    pass

def _expand_redirect(url: str, sess: requests.Session = None) -> str:
    """If *url* is toplinktracker.com, follow HEAD 302 to the real sdilej.cz URL."""
    if "toplinktracker.com" not in url:
        return url
    s = sess or _sess
    try:
        r = s.head(url, allow_redirects=True, timeout=10)
        if r.ok:
            LOGGER.info(f"Sdilej: expanded to {r.url}")
            return r.url
    except requests.RequestException as e:
        LOGGER.error(f"Sdilej: could not expand redirect {url}: {e}")
    LOGGER.warning("Sdilej: could not expand redirect %s", url)
    return url

# --- Regulárne výrazy na parsovanie ---
SEARCH_RESULTS_RE = re.compile(
    r'<div class="videobox-desc">.*?'
    r'<p class="videobox-title"><a href="(?P<url>[^"]+)"[^>]*>(?P<name>.+?)</a></p>.*?'
    r'<p>(?P<size>[\d.,]+\s*\w*B)',
    re.DOTALL | re.IGNORECASE
)
FREE_DOWNLOAD_RE = re.compile(r'<a href="(?P<url>[^"]+)"[^>]*>\s*Stáhnout zdarma\s*</a>')
STREAM_URL_RE = re.compile(r'data-url="(?P<url>https?://[^"]+)"')

_XHR_HEADERS = {
    'User-Agent': UA,
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': BASE_URL
}

def search(query: str, limit: int = 25) -> List[Dict[str, Any]]:
    """
    Vyhľadá na Sdilej.cz a vráti zoznam výsledkov.
    """
    results = []
    safe_query = quote(query.strip())
    search_url = f'{BASE_URL}/{safe_query}/s'
    try:
        resp = _sess.get(search_url, timeout=10)
        resp.raise_for_status()
        html_content = resp.text
        matches = SEARCH_RESULTS_RE.finditer(html_content)
        for match in matches:
            if len(results) >= limit: break
            data = match.groupdict()
            name = html.unescape(data.get('name', '').strip())
            page_url_raw = html.unescape(data.get('url', ''))
            page_url = _expand_redirect(page_url_raw)
            size = data.get('size', '').strip()
            if name and page_url:
                results.append({"name": name, "url": page_url, "size": size, "ident": page_url}) # Added ident for compatibility
    except requests.RequestException as e:
        LOGGER.error(f"Sdilej.cz search failed for query '{query}': {e}")
    return results

def resolve(page_url: str) -> Optional[Tuple[str, str]]:
    """
    Preloží URL a extrahuje finálny stream link rýchlo a efektívne.
    """
    try:
        # KROK 1: Stránka súboru
        resp1 = _sess.get(page_url, allow_redirects=True, timeout=5)
        resp1.raise_for_status()
        
        # KROK 2: Tlačidlo "Stáhnout zdarma"
        match1 = FREE_DOWNLOAD_RE.search(resp1.text)
        if not match1:
            LOGGER.error(f"Could not find 'Stáhnout zdarma' button on {resp1.url}")
            return None
        
        # KROK 3: Stránka s časovačom
        next_url = urljoin(BASE_URL, match1.group('url'))
        
        # Trik pre rýchlosť: použijeme stream=True a čítame po kúskoch
        with _sess.get(next_url, allow_redirects=True, timeout=5, stream=True) as resp2:
            resp2.raise_for_status()
            final_page_url = resp2.url
            
            # Prečítame len prvých pár KB, kde sa data-url nachádza
            chunk = resp2.content[:4096].decode('utf-8', errors='ignore')
            
            match2 = STREAM_URL_RE.search(chunk)
            if not match2:
                LOGGER.error(f"Could not find stream URL (data-url) in the initial chunk of {final_page_url}")
                return None
                
            stream_url = html.unescape(match2.group('url'))
            
            LOGGER.info(f"Successfully resolved stream URL: {stream_url}")
            return stream_url, final_page_url

    except requests.RequestException as e:
        LOGGER.error(f"Failed to resolve {page_url}: {e}")
        return None

def _save_cookies():
    """Uloží aktuálne cookies session do súboru."""
    try:
        with open(COOKIE_FILE, 'wb') as f:
            pickle.dump(_sess.cookies, f)
        LOGGER.info("Sdilej.cz cookies successfully saved.")
    except Exception as e:
        LOGGER.error(f"Failed to save Sdilej.cz cookies: {e}")

def _load_cookies() -> bool:
    """Načíta cookies zo súboru a vloží ich do session."""
    if not os.path.exists(COOKIE_FILE):
        return False
    try:
        with open(COOKIE_FILE, 'rb') as f:
            cookies = pickle.load(f)
            _sess.cookies.update(cookies)
        LOGGER.info("Sdilej.cz cookies loaded from file.")
        return True
    except Exception as e:
        LOGGER.error(f"Failed to load Sdilej.cz cookies: {e}")
        return False

def login(username, password) -> bool:
    """
    Prihlási užívateľa na Sdilej.cz a uloží cookies.
    """
    login_url = f'{BASE_URL}/?do=loginForm-submit'
    payload = {
        'username': username,
        'password': password,
        'remember': '1',
        'do': 'loginForm-submit'
    }
    try:
        resp = _sess.post(login_url, data=payload, allow_redirects=True)
        resp.raise_for_status()
        
        # Úspešné prihlásenie nastaví cookie priamo v session
        if 'autologin_hash' in _sess.cookies or 'PHPSESSID' in _sess.cookies:
            LOGGER.info("Successfully logged in to Sdilej.cz")
            _save_cookies()
            if ADDON:
                # Uložíme expiráciu na 12 hodín
                exp_time = int(time.time()) + (12 * 3600)
                ADDON.setSettingInt("sd_cookie_exp", exp_time)
            return True
        else:
            LOGGER.error("Login to Sdilej.cz failed. Check credentials.")
            return False
    except requests.RequestException as e:
        LOGGER.error(f"Login request to Sdilej.cz failed: {e}")
        return False

def ensure_logged_in() -> bool:
    """
    Zabezpečí, že užívateľ je prihlásený. Načíta cookies alebo sa prihlási.
    Obsahuje ochranu proti floodovaniu servera pri opakovaných neúspešných pokusoch.
    """
    global _login_attempts, _last_login_attempt_time

    if ADDON:
        exp_time = ADDON.getSettingInt("sd_cookie_exp")
        if exp_time and time.time() < exp_time and 'autologin_hash' in _sess.cookies:
            if _load_cookies():
                LOGGER.debug("Session seems to be valid from cache.")
                return True

    # Ochrana proti floodu
    if _login_attempts >= 3 and (time.time() - _last_login_attempt_time) < 30:
        LOGGER.warning("Too many failed login attempts to Sdilej.cz. Waiting 30s.")
        time.sleep(30)
        _login_attempts = 0 # Reset po pauze

    _last_login_attempt_time = time.time()

    if ADDON:
        user = ADDON.getSetting("sd_user")
        passwd = ADDON.getSetting("sd_pass")
        if user and passwd:
            if login(user, passwd):
                _login_attempts = 0
                return True
            else:
                _login_attempts += 1
                return False
    return False

def _extract_file_id(url: str) -> str | None:
    url = _expand_redirect(url.strip())
    parsed = urlparse(url)
    
    # Check for numeric ID in query first
    m = re.search(r'[?&]id=(\d+)', url, re.I)
    if m:
        return m.group(1)
        
    slug = parsed.path.strip("/")
    if not slug:
        return None
        
    # Return the whole slug if it's not purely numeric
    if not slug.isdigit():
        return slug.lower()
    
    # Fallback for numeric slugs in path
    if slug.isdigit():
        return slug
        
    return None

def _old_ticket_api(file_id: str) -> str | None:
    """
    Resolves a premium download link using the old API method.
    This is kept as a fallback.
    """
    if not ensure_logged_in():
        raise SdilejError("Uživatel není přihlášen (staré API).")

    try:
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json;charset=UTF-8",
            "User-Agent": UA,
            "Referer": "https://sdilej.cz/",
            "Origin": "https://sdilej.cz",
            "X-Requested-With": "XMLHttpRequest"
        }

        # 1) TICKET
        ticket_url = f"{API_BASE_URL}/files/{file_id}/ticket"
        resp = _sess.post(ticket_url, headers=headers, json={})
        
        LOGGER.debug(f"[Sdilej] Old API POST {ticket_url} -> {resp.status_code}")
        if resp.status_code != 200 or not resp.text.strip() or resp.headers.get("Content-Type", "").startswith("text/html"):
            raise SdilejError(f"API /ticket selhalo ({resp.status_code})")
        
        data = resp.json()
        ticket_code = data.get("ticket_code")
        ticket_hash = data.get("hash")
        
        if not ticket_code:
            raise SdilejError("Odpověď z API neobsahuje ticket.")

        # 2) DOWNLOAD-TICKET
        dl_url = f"{API_BASE_URL}/files/{file_id}/download-ticket"
        payload = {"ticket_code": ticket_code, "hash": ticket_hash}
        resp = _sess.post(dl_url, headers=headers, json=payload)
        
        if resp.status_code != 200:
            raise SdilejError(f"API /download-ticket selhalo ({resp.status_code})")
            
        download_data = resp.json()
        download_url = download_data.get("url") or download_data.get("download_url")
        
        if download_url:
             LOGGER.info(f"Successfully resolved link via old API for {file_id}")
             return download_url
        
        raise SdilejError("Odpověď z API neobsahuje finální URL.")

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            raise SdilejError("Soubor nenalezen (404) - staré API.")
        raise SdilejError(f"HTTP chyba (staré API): {e.response.status_code}")
    except (requests.RequestException, ValueError) as e:
        LOGGER.error(f"Exception during old API resolve for {file_id}: {e}")
        raise SdilejError("Nepodařilo se získat odkaz (staré API).")

def resolve(play_id: str) -> bool:
    """
    Resolves a video stream from a file ID.
    Tries the new scraping method first, and falls back to the old API method.
    """
    try:
        addon_handle = int(sys.argv[1])
    except (IndexError, ValueError):
        LOGGER.error("Could not get addon handle. Cannot resolve stream for Kodi.")
        return False

    # Method 1: Scrape the page (new, preferred)
    try:
        page_url = f"https://sdilej.cz/{play_id}"
        
        try:
            user_agent = xbmc.getUserAgent()
        except (NameError, AttributeError):
            user_agent = UA

        resp = _sess.get(page_url, headers={"User-Agent": user_agent})
        resp.raise_for_status()
        page_content = resp.text

        m = re.search(r'"file"\s*:\s*"(?P<url>https[^"]+\.m3u8)"', page_content)
        if m:
            stream_url = m.group('url').replace(r'\/', '/')
            LOGGER.info(f"Scraping successful, found HLS stream: {stream_url}")
            
            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            headers = f"Referer=https://sdilej.cz/\nUser-Agent={user_agent}"
            li.setProperty("inputstream.adaptive.stream_headers", headers)
            
            xbmcplugin.setResolvedUrl(addon_handle, True, li)
            return True
        
        # Fallback to MP4 check if HLS is not found
        m = re.search(r'"file"\s*:\s*"(?P<url>https[^"]+\.mp4)"', page_content)
        if m:
            stream_url = m.group('url').replace(r'\/', '/')
            LOGGER.info(f"Scraping successful, found MP4 stream: {stream_url}")
            li = xbmcgui.ListItem(path=stream_url)
            # For direct MP4, we don't need inputstream.adaptive
            xbmcplugin.setResolvedUrl(addon_handle, True, li)
            return True

        raise SdilejError("Nenalezeno přehrávací URL ve stránce.")

    except Exception as e:
        LOGGER.warning(f"Scraping method failed for {play_id}: {e}. Falling back to old API.")
        # Method 2: Fallback to old ticket API
        try:
            stream_url = _old_ticket_api(play_id) 
            if not stream_url:
                raise SdilejError("Staré API nevrátilo URL.")
            
            LOGGER.info("Fallback to old API successful.")
            li = xbmcgui.ListItem(path=stream_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, li)
            return True

        except Exception as e2:
            LOGGER.error(f"Fallback API method also failed for {play_id}: {e2}")
            try:
                xbmcgui.Dialog().notification('Sdilej.cz', f'Chyba: {e2}', xbmcgui.NOTIFICATION_ERROR, 4000)
            except (ImportError, AttributeError):
                pass
            return False
