#!/bin/bash

# Cesta k Git executable
GIT_CMD="/d/OneDrive - SATRA, spol. s r.o/PRIV/VSC/GIT/bin/git"

set -e 
if [ -z "$1" ]; then
  echo "CHYBA: Nebyla zadána verze." >&2
  echo "Použití: ./release.sh <verze>" >&2
  exit 1
fi
VERSION=$1
TAG="v$VERSION"
ADDON_XML="addon.xml"
if ! "$GIT_CMD" diff-index --quiet HEAD --; then
    echo "CHYBA: Máte neuložené změny. Commitněte je prosím." >&2
    exit 1
fi
echo "Synchronizuji s 'main' větví..."
"$GIT_CMD" checkout main
"$GIT_CMD" pull origin main
echo "Aktualizuji verzi v $ADDON_XML na $VERSION..."
sed -i "s/version=\"[0-9.]*\"/version=\"$VERSION\"/" "$ADDON_XML"
echo "Provádím commit a tagování..."
"$GIT_CMD" add "$ADDON_XML"
"$GIT_CMD" commit -m "chore(release): bump version to $VERSION"
"$GIT_CMD" tag "$TAG"
echo "Nahrávám změny a tag na GitHub..."
"$GIT_CMD" push origin main
"$GIT_CMD" push origin "$TAG"
echo "----------------------------------------------------"
echo "HOTOVO! Verze $VERSION byla úspěšně vydána."
echo "GitHub Actions workflow se nyní automaticky spustí."
echo "----------------------------------------------------"
