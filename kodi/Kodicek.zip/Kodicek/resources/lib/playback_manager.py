# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import xbmcaddon

# Manually add the addon's root to the Python path
# This is necessary for the service to find modules in the root folder
addon_path = xbmcaddon.Addon().getAddonInfo('path')
if addon_path not in sys.path:
    sys.path.insert(0, addon_path)

import xbmc
import xbmcplugin
import xbmcgui
import requests
import hashlib
import md5crypt
import time
import json
import re
from xml.etree import ElementTree as ET
from resources.lib.search_utils import extract_season_episode

# Základní proměnné a session, které budou potřeba
addon = xbmcaddon.Addon()
plugin_name = "Kodíček"
WEBSHARE_API_BASE_URL = "https://webshare.cz/api/"
TMDB_API_BASE_URL = "https://api.themoviedb.org/3/"

_session = requests.Session()
_session.headers.update({'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"})

# --- Pomocné funkce z kodicek.py ---

def api_call(endpoint, data=None, method='post', base_url=WEBSHARE_API_BASE_URL):
    url = base_url + endpoint
    if base_url == WEBSHARE_API_BASE_URL and not endpoint.endswith('/'):
        url += "/"
        
    try:
        if method == 'post':
            response = _session.post(url, data=data, timeout=10)
        else: # get
            response = _session.get(url, params=data, timeout=10)
        response.raise_for_status()
        return response.content
    except requests.exceptions.RequestException as e:
        xbmc.log(f"Kodíček (PM): API call to {url} failed: {e}", level=xbmc.LOGERROR)
        # Vracíme None, aby volající mohl reagovat
        return None

def is_xml_ok(xml_root):
    if xml_root is None:
        return False
    status_node = xml_root.find('status')
    if status_node is not None and status_node.text == 'OK':
        return True
    message_node = xml_root.find('message')
    error_message = message_node.text if message_node is not None else "Unknown API error"
    xbmc.log(f"Kodíček (PM): API call not OK. Message: {error_message}", level=xbmc.LOGERROR)
    return False

def search_webshare(token, query, limit=None, offset=0):
    try:
        if limit is None:
            limit = int(addon.getSetting("SEARCH_RESULT_LIMIT"))
    except (ValueError, TypeError):
        limit = 100

    search_params = {
        'wst': token,
        'what': query,
        'category': 'video',
        'limit': limit,
        'offset': offset,
        'sort': 'rating'
    }
    search_response_content = api_call('search', search_params, method='post', base_url=WEBSHARE_API_BASE_URL)
    
    if not search_response_content:
        return []
    try:
        search_xml = ET.fromstring(search_response_content)
    except ET.ParseError as e:
        xbmc.log(f"Kodíček (PM): Failed to parse search XML: {e}. Response: {search_response_content}", level=xbmc.LOGERROR)
        return []
    if not is_xml_ok(search_xml):
        return []
    files_list = []
    for file_elem in search_xml.iter('file'):
        file_data = {
            'ident': file_elem.findtext('ident'),
            'name': file_elem.findtext('name'),
            'size': int(file_elem.findtext('size', '0')),
        }
        if file_data['ident'] and file_data['name']:
            files_list.append(file_data)
    return files_list

def get_stream_link(token, ident):
    possible_params = [
        {'wst': token, 'ident': ident, 'download_type': 'video_stream'},
        {'wst': token, 'ident': ident, 'download_type': 'file_download'},
        {'wst': token, 'ident': ident}
    ]
    for link_params in possible_params:
        link_response_content = api_call('file_link', link_params, method='post', base_url=WEBSHARE_API_BASE_URL)
        if not link_response_content: continue
        try:
            link_xml = ET.fromstring(link_response_content)
        except ET.ParseError: continue
        if not is_xml_ok(link_xml): continue
        link_node = link_xml.find('link')
        if link_node is not None and link_node.text:
            return link_node.text
    # Notifikaci přesuneme do volající funkce, aby manažer jen vracel data
    xbmc.log(f"Kodíček (PM): Nepodařilo se získat stream link pro ident: {ident}", level=xbmc.LOGERROR)
    return None

def normalize_text(text):
    if not text: return ""
    text = text.lower()
    replacements = {
        'á': 'a', 'č': 'c', 'ď': 'd', 'é': 'e', 'ě': 'e', 'í': 'i', 'ň': 'n',
        'ó': 'o', 'ř': 'r', 'š': 's', 'ť': 't', 'ú': 'u', 'ů': 'u', 'ý': 'y',
        'ž': 'z', 'ľ': 'l', 'ĺ': 'l', 'ŕ': 'r', 'ä': 'a', 'ô': 'o'
    }
    for char_from, char_to in replacements.items():
        text = text.replace(char_from, char_to)
    text = text.replace(' ', '.').replace('_', '.').replace('-', '.')
    text = re.sub(r'[^\w.]', '', text)
    text = re.sub(r'\.+', '.', text)
    return text.strip('.')

def build_episode_queries(show_title, season, episode, ep_title=None, year=None):
    cleaned_show_title = show_title.replace('*', '')
    ep_title = ep_title or ""
    show_title = " ".join(cleaned_show_title.split())
    ep_title = " ".join(ep_title.split())

    s_full = f"{season:02d}"
    s_short = str(season)
    e_full = f"{episode:02d}"
    e_short = str(episode)

    code_formats = [
        f"S{s_full}E{e_full}", f"{s_full}x{e_full}",
        f"S{s_short}E{e_short}", f"{s_short}x{e_short}",
    ]

    potential_queries = []
    if year and ep_title:
        for code in code_formats[:2]:
            potential_queries.append(f"{show_title} {code} {ep_title} {year}")
    if ep_title:
        for code in code_formats:
            potential_queries.append(f"{show_title} {code} {ep_title}")
    if year:
        for code in code_formats:
            potential_queries.append(f"{show_title} {code} {year}")
    for code in code_formats:
        potential_queries.append(f"{show_title} {code}")

    final_queries = []
    seen_queries = set()
    for q_str in potential_queries:
        normalized_q_str = " ".join(q_str.split())
        if normalized_q_str and normalized_q_str not in seen_queries:
            final_queries.append(normalized_q_str)
            seen_queries.add(normalized_q_str)
    return final_queries

def filter_episode_results(files, show_title, season, episode):
    """
    Filters a list of files to find matches for a specific episode.
    Uses the tolerant extract_season_episode function.
    """
    norm_show = normalize_text(show_title)
    out = []
    for f_item in files:
        fname_normalized = normalize_text(f_item['name'])
        if norm_show not in fname_normalized:
            continue
        
        extracted = extract_season_episode(f_item['name'])
        if extracted:
            s, e = extracted
            if s == season and e == episode:
                out.append(f_item)
    return out

def tmdb_api_request(api_key, endpoint, params=None, method='get'):
    if not api_key:
        xbmc.log("Kodíček (PM): TMDb API key is missing for request.", level=xbmc.LOGERROR)
        return None
    url = f"{TMDB_API_BASE_URL}{endpoint.lstrip('/')}"
    all_params = {'api_key': api_key}
    if params:
        all_params.update(params)
    try:
        if method == 'get':
            response = _session.get(url, params=all_params, timeout=10)
        else:
            return None
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        xbmc.log(f"Kodíček (PM): TMDb API call to {url} failed: {e}", level=xbmc.LOGERROR)
        return None
    except json.JSONDecodeError as e:
        xbmc.log(f"Kodíček (PM): Failed to parse TMDb JSON response from {url}: {e}", level=xbmc.LOGERROR)
        return None

def find_best_stream_for_episode(token, tmdb_id, season_number, episode_number, show_title, show_year, autoplay_prefs=[]):
    api_key = addon.getSetting("tmdb_api_key")
    episode_name_cs = ""
    episode_name_en = ""

    if api_key:
        ep_details_cs = tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}/episode/{episode_number}", {'language': 'cs-CZ'})
        if ep_details_cs and ep_details_cs.get('name'):
            episode_name_cs = ep_details_cs.get('name')
        ep_details_en = tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}/episode/{episode_number}", {'language': 'en-US'})
        if ep_details_en and ep_details_en.get('name'):
            episode_name_en = ep_details_en.get('name')

    episode_name_for_search = episode_name_cs if episode_name_cs else episode_name_en
    
    queries_to_try = build_episode_queries(show_title, season_number, episode_number, episode_name_for_search, show_year)
    
    webshare_files = []
    for query in queries_to_try:
        xbmc.log(f"Kodíček (PM): Searching Webshare for episode with query: '{query}'", level=xbmc.LOGINFO)
        current_results = search_webshare(token, query) 
        filtered_results = filter_episode_results(current_results, show_title, season_number, episode_number)
        xbmc.log(f"Kodíček (PM): Webshare query '{query}' returned {len(current_results)} results, {len(filtered_results)} relevant.", level=xbmc.LOGINFO)
        if filtered_results:
            webshare_files = filtered_results
            break 
    
    if not webshare_files:
        xbmc.log(f"[PM] Pro '{show_title} S{season_number:02d}E{episode_number:02d}' nebyly nalezeny zdroje.", xbmc.LOGINFO)
        return None

    def score_file(file_item):
        score = 0
        filename_lower = file_item['name'].lower()
        for pref in autoplay_prefs:
            if pref in filename_lower:
                score += 1
        score += file_item.get('size', 0) / (1024*1024*1024)
        return score

    sorted_files = sorted(webshare_files, key=score_file, reverse=True)
    xbmc.log(f"[PM] Nalezeno {len(sorted_files)} souborů, seřazeno podle preferencí: {autoplay_prefs}", xbmc.LOGINFO)

    for file_to_play in sorted_files:
        xbmc.log(f"[PM] Zkouším soubor: {file_to_play['name']} (skóre: {score_file(file_to_play):.2f})", xbmc.LOGINFO)
        stream_url = get_stream_link(token, file_to_play['ident'])
        if stream_url:
            headers_str = urllib.parse.urlencode({'User-Agent': _session.headers.get('User-Agent', 'Mozilla/5.0'), 'Cookie': f'wst={token}'})
            path_with_headers = f"{stream_url}|{headers_str}"
            
            return {
                "url": path_with_headers,
                "name": file_to_play['name'],
                "ident": file_to_play['ident']
            }
        else:
            xbmc.log(f"[PM] Nepodařilo se získat stream link pro {file_to_play['ident']}, zkouším další.", xbmc.LOGWARNING)
    
    xbmc.log("[PM] Nepodařilo se přehrát žádný z nalezených souborů.", xbmc.LOGERROR)
    return None

def get_all_episode_sources(token, tmdb_id, season_number, episode_number, show_title, show_year):
    api_key = addon.getSetting("tmdb_api_key")
    episode_name_cs = ""
    episode_name_en = ""

    if api_key:
        ep_details_cs = tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}/episode/{episode_number}", {'language': 'cs-CZ'})
        if ep_details_cs and ep_details_cs.get('name'):
            episode_name_cs = ep_details_cs.get('name')
        ep_details_en = tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}/episode/{episode_number}", {'language': 'en-US'})
        if ep_details_en and ep_details_en.get('name'):
            episode_name_en = ep_details_en.get('name')

    episode_name_for_search = episode_name_cs if episode_name_cs else episode_name_en
    
    queries_to_try = build_episode_queries(show_title, season_number, episode_number, episode_name_for_search, show_year)
    
    webshare_files = []
    for query in queries_to_try:
        current_results = search_webshare(token, query) 
        filtered_results = filter_episode_results(current_results, show_title, season_number, episode_number)
        if filtered_results:
            webshare_files = filtered_results
            break
            
    return webshare_files
