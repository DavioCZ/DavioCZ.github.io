# -*- coding: utf-8 -*-
import re, datetime as dt
from typing import List, Any

def natural_key(title: str) -> List[Any]:
    if not title: return []
    import re
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', title)]

SPECIAL_RE = re.compile(r"(Váno|Vano|Holiday|Special|Short|Super\s*Star|Swamp|Tales|Stories|Thrilling|Zvonec|Hruza|Hrůza)", re.I)

def sort_key_candidate(c, coll_order: dict) -> tuple:
    """
    Pořadí: filmy → pořadí v kolekci → ne-specialy → vydané → natural title → rok → více hlasů nahoru.
    """
    movie_first = 0 if getattr(c, "media_type", "") == "movie" else 1
    coll_rank = coll_order.get(int(c.id), 10_000)
    is_special = 1 if SPECIAL_RE.search(c.title or "") else 0
    year = int(c.year) if getattr(c, "year", None) else 9999
    try:
        unreleased = 1 if year > dt.date.today().year else 0
    except Exception:
        unreleased = 0
    votes_boost = -(getattr(c, "vote_count", 0) or 0)
    return (movie_first, coll_rank, is_special, unreleased, natural_key(c.title or ""), year, votes_boost)
