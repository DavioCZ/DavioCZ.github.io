# resources/lib/playback_monitor.py
# -*- coding: utf-8 -*-
import xbmc, time
from resources.lib.history import add_to_history

class PlaybackMonitor(xbmc.Monitor):
    def __init__(self, meta, source=None):
        super().__init__()
        self.meta = meta
        self.source = source
        self.player = xbmc.Player()
        self.was_playing = False
        self.pos = 0.0
        self.total = 0.0

    def loop(self):
        while not self.abortRequested():
            if self.player.isPlayingVideo():
                self.was_playing = True
                try:
                    self.pos = float(self.player.getTime())
                    self.total = float(self.player.getTotalTime())
                except: pass
                self.waitForAbort(0.5)
            elif self.was_playing:
                add_to_history(self.meta, pos=self.pos, total=self.total, source=self.source)
                break
            else:
                self.waitForAbort(0.5)
