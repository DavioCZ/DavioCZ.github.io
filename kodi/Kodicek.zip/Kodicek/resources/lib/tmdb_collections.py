# -*- coding: utf-8 -*-
from functools import lru_cache
import xbmcaddon, xbmc
from .playback_manager import tmdb_api_request

ADDON = xbmcaddon.Addon()

def get_api_key() -> str:
    return ADDON.getSetting("tmdb_api_key") or ""

@lru_cache(maxsize=256)
def get_movie_details(movie_id: int, language: str = "cs-CZ"):
    api = get_api_key()
    if not api: 
        return None
    data = tmdb_api_request(api, f"/movie/{movie_id}", params={"language": language})
    if not data and language != "en-US":
        data = tmdb_api_request(api, f"/movie/{movie_id}", params={"language": "en-US"})
    return data or {}

@lru_cache(maxsize=128)
def get_collection_order_map(collection_id: int, language: str = "cs-CZ") -> dict:
    """
    Vrátí mapu {movie_id -> pořadí v kolekci} podle release_date.
    """
    api = get_api_key()
    if not api: 
        return {}
    data = tmdb_api_request(api, f"/collection/{collection_id}", params={"language": language}) or {}
    parts = data.get("parts") or []
    # fallback na en-US, když cs vrátí chudé výsledky
    if not parts and language != "en-US":
        data = tmdb_api_request(api, f"/collection/{collection_id}", params={"language": "en-US"}) or {}
        parts = data.get("parts") or []
    def rdate(p):
        d = (p.get("release_date") or "")[:10]
        return d if d else "9999-12-31"
    parts_sorted = sorted(parts, key=rdate)
    return {p["id"]: i for i, p in enumerate(parts_sorted)}

def resolve_collection_order_for_candidates(candidates: list) -> dict:
    """
    Vezme první rozumné filmové kandidáty, najde jejich 'belongs_to_collection'
    a vrátí mapu {movie_id -> pořadí}. Typicky nalezne jedinou kolekci (Shrek, KFP...).
    """
    movies = [c for c in candidates if getattr(c, "media_type", None) == "movie"]
    # Zkus jen pár prvních, ať to není těžké
    for c in movies[:6]:
        details = get_movie_details(int(c.id)) or {}
        col = details.get("belongs_to_collection")
        if col and col.get("id"):
            return get_collection_order_map(int(col["id"]))
    return {}
