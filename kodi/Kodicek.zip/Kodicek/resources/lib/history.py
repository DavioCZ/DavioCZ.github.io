# resources/lib/history.py
# -*- coding: utf-8 -*-
import json, io, time, os, xbmc, xbmcaddon, xbmcvfs

try:
    translatePath = xbmc.translatePath
except Exception:
    from xbmcvfs import translatePath

ADDON_ID   = xbmcaddon.Addon().getAddonInfo('id')
PROFILE    = translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
HISTORY_FN = os.path.join(PROFILE, "history.json")

def _ensure_dir():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)

def _read_json(path):
    if not xbmcvfs.exists(path):
        return None
    with io.open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def _write_json(path, data):
    _ensure_dir()
    with io.open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, separators=(',',':'))

def _migrate(raw):
    """
    Vrátí list položek ve tvaru nové struktury.
    Akceptuje:
      - None / prázdný => []
      - list položek (nový i starý formát) => normalizace
      - dict se starou strukturou (movies/shows/recent_order) => převod
    """
    def norm(x):
        # minimal canonical item
        it = {
            "kind": x.get("kind") or x.get("media_type") or ("show" if x.get("season") else "movie"),
            "tmdb_id": x.get("tmdb_id") or x.get("id") or x.get("tmdbId"),
            "title": x.get("title"),
            "year": x.get("year"),
            "poster": x.get("poster"),
            "last_played": x.get("last_played") or time.time(),
            "resume": x.get("resume") or {},
            "last": x.get("last") or {"season": x.get("season"), "episode": x.get("episode")}
        }
        # Odstraníme položky bez základních identifikátorů
        if not it["tmdb_id"] or not it["title"]:
            return None
        return it

    if not raw:
        return []
    
    items = []
    if isinstance(raw, list):
        items = [norm(x) for x in raw if isinstance(x, dict)]
    elif isinstance(raw, dict):
        # stará „dict“ schémata
        if "movies" in raw or "shows" in raw:
            for m in raw.get("movies", {}).values():
                items.append(norm({"kind":"movie", **m}))
            for s in raw.get("shows", {}).values():
                items.append(norm({"kind":"show", **s, **(s.get("last") or {})}))
            # zachovej pořadí recent_order, novější dopředu
            ro = raw.get("recent_order") or []
            rank = {k:i for i,k in enumerate(ro)}
            # Filtrujeme None hodnoty před řazením
            items = [i for i in items if i]
            items.sort(key=lambda it: rank.get(f"{'movie' if it['kind']=='movie' else 'show'}:{it['tmdb_id']}", 1_000_000))
            return items
    
    # Finální filtrace pro všechny případy
    return [i for i in items if i]

def load_history():
    """Vrať list položek (nejnovější první). Nikdy nevyhazuj výjimky."""
    try:
        raw = _read_json(HISTORY_FN)
        items = _migrate(raw)
        xbmc.log(f"Kodicek History: loaded {len(items)} items", xbmc.LOGINFO)
        return items
    except Exception as e:
        xbmc.log(f"Kodicek History: load error: {e}", xbmc.LOGWARNING)
        return []

def _upsert(items, item):
    # unikát na kombinaci kind+tmdb_id
    items = [h for h in items if not (h.get("kind")==item.get("kind") and h.get("tmdb_id")==item.get("tmdb_id"))]
    items.insert(0, item)
    return items[:100]

def add_to_history(meta, pos=None, total=None, source=None):
    """
    meta: { kind: "movie"|"show", tmdb_id:int, title, year, poster,
            season:int(optional), episode:int(optional) }
    """
    try:
        # Kontrola základních metadat před přidáním
        if not meta.get("tmdb_id") or not meta.get("title"):
            xbmc.log("Kodicek History: missing tmdb_id or title, skipping add.", xbmc.LOGWARNING)
            return

        items = load_history()
        item = {
            "kind": meta.get("kind") or meta.get("media_type") or ("show" if meta.get("season") else "movie"),
            "tmdb_id": int(meta.get("tmdb_id") or 0),
            "title": meta.get("title"),
            "year": meta.get("year"),
            "poster": meta.get("poster"),
            "last_played": time.time(),
            "resume": {"pos": float(pos or 0.0), "total": float(total or 0.0)},
            "last": {"season": meta.get("season"), "episode": meta.get("episode")},
            "last_source": source or {}
        }
        items = _upsert(items, item)
        _write_json(HISTORY_FN, items)
        xbmc.log("Kodicek History: commit OK", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Kodicek History: commit failed: {e}", xbmc.LOGERROR)

def remove_from_history(kind, tmdb_id):
    """Odstraní položku z historie."""
    try:
        tmdb_id = int(tmdb_id)
        items = load_history()
        original_count = len(items)
        items = [h for h in items if not (h.get("kind") == kind and h.get("tmdb_id") == tmdb_id)]
        
        if len(items) < original_count:
            _write_json(HISTORY_FN, items)
            xbmc.log(f"Kodicek History: Removed {kind}:{tmdb_id}", xbmc.LOGINFO)
            return True
        return False
    except Exception as e:
        xbmc.log(f"Kodicek History: remove failed: {e}", xbmc.LOGERROR)
        return False

def clear_history():
    """Vymaže celou historii přehrávání."""
    try:
        _write_json(HISTORY_FN, [])
        xbmc.log("Kodicek History: Cleared.", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"Kodicek History: clear failed: {e}", xbmc.LOGERROR)
        return False


# --- Search History ---

SEARCH_HISTORY_FN = os.path.join(PROFILE, "search_history.json")
MAX_SEARCH_HISTORY_ITEMS = 25

def load_search_history():
    """Načte historii vyhledávání ze souboru a vrátí ji jako seznam slovníků."""
    _ensure_dir()
    if not xbmcvfs.exists(SEARCH_HISTORY_FN):
        return []
    try:
        with xbmcvfs.File(SEARCH_HISTORY_FN, 'r') as f:
            content = f.read()
            if content:
                return json.loads(content)
            return []
    except Exception as e:
        xbmc.log(f"Kodicek: Error loading search history: {e}", xbmc.LOGWARNING)
        return []

def add_to_search_history(search_item):
    """
    Přidá novou položku do historie vyhledávání.
    Odstraní duplikáty a omezí celkový počet položek.
    `search_item` je slovník, např. {"query": "shrek", "timestamp": 1234567890}
    """
    if not isinstance(search_item, dict) or "query" not in search_item:
        return

    query_to_add = search_item["query"].strip()
    if not query_to_add:
        return

    history = load_search_history()
    
    # Odstranění existujících položek se stejným dotazem (case-insensitive)
    history = [item for item in history if item.get("query", "").lower() != query_to_add.lower()]
    
    # Přidání nové položky na začátek
    history.insert(0, {"query": query_to_add, "timestamp": int(time.time())})
    
    # Omezení na maximální počet položek
    history = history[:MAX_SEARCH_HISTORY_ITEMS]
    
    try:
        _ensure_dir()
        with xbmcvfs.File(SEARCH_HISTORY_FN, 'w') as f:
            f.write(json.dumps(history, indent=4))
        xbmc.log(f"Kodicek: Saving search history, added: '{query_to_add}'", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Kodicek: Error saving search history: {e}", xbmc.LOGERROR)
