# -*- coding: utf-8 -*-

import re
import unicodedata

# --- Normalization and Extraction Helpers ---

def normalize_query(text):
    """
    Normalizuje text pro porovnávání:
    - Odstraní diakritiku (řeší i 'ď', 'ť', 'ň').
    - Převede na malá písmena.
    - Nahradí '&' za 'and'.
    - Odstraní všechny znaky kromě alfanumerických a mezer.
    - Sjednotí vícenásobné mezery na jednu.
    """
    if not text:
        return ""
    
    # NFD normalizace pro oddělení znaků a diakritiky
    text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
    
    text = text.lower()
    text = re.sub(r'\s*&\s*', ' and ', text)
    text = re.sub(r'[^a-z0-9\s]+', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def extract_year(query):
    """
    Extrahuje rok z vyhledávacího dotazu. Hledá 4místné číslo v rozsahu 1900-2099.
    """
    match = re.search(r'\b(19[0-9]{2}|20[0-9]{2})\b', query)
    return int(match.group(1)) if match else None

# --- Auto-pick Logic (REMOVED) ---
# Funkce should_autopick byla odstraněna v rámci refaktoringu.
# Plugin nyní vždy zobrazí seznam kandidátů.
# --- Query Generation ---

# Maximální počet variant dotazů, které se mají vygenerovat.
# TODO: Přenést do nastavení doplňku
SEARCH_MAX_VARIANTS = 12

def generate_tiered_query_variants(meta, mode='movie'):
    """
    Generuje víceúrovňový seznam variant vyhledávacích dotazů pro filmy i epizody.
    """
    if mode == 'movie':
        return _generate_movie_queries(meta)
    elif mode == 'episode':
        return _generate_episode_queries(meta)
    return {'A': [], 'B': [], 'C': []}

def _generate_movie_queries(meta):
    """Generuje dotazy pro filmy."""
    title_cz = meta.get('title', '')
    title_orig = meta.get('original_title', '')
    year = meta.get('year')

    base_cz = normalize_query(title_cz)
    base_orig = normalize_query(title_orig)

    unique_bases = [base_cz]
    if base_orig and base_orig != base_cz:
        unique_bases.append(base_orig)

    year_variants = []
    if year:
        try:
            y = int(year)
            year_variants = [str(y), str(y - 1), str(y + 1)]
        except (ValueError, TypeError):
            pass

    delimiters = [' ', '.', '-', '_']
    
    tier_a = set()
    tier_b = set()
    tier_c = set()

    # Tier A (vysoká přesnost): "{název} {rok}"
    if year_variants:
        for y_var in year_variants:
            for delim in delimiters:
                tier_a.add(base_cz.replace(' ', delim) + delim + y_var)
            tier_a.add(base_cz.replace(' ', '') + y_var)

    # Tier B (střední přesnost): "{název}" (bez roku), "{orig_název} {rok}"
    for base in unique_bases:
        for delim in delimiters:
            tier_b.add(base.replace(' ', delim))
        tier_b.add(base.replace(' ', ''))
    
    if year_variants and base_orig and base_orig != base_cz:
        for y_var in year_variants:
            for delim in delimiters:
                tier_b.add(base_orig.replace(' ', delim) + delim + y_var)
            tier_b.add(base_orig.replace(' ', '') + y_var)

    # Tier C (široký záběr): "{orig_název}" (bez roku)
    if base_orig and base_orig != base_cz:
        for delim in delimiters:
            tier_c.add(base_orig.replace(' ', delim))
        tier_c.add(base_orig.replace(' ', ''))

    return _finalize_tiers(tier_a, tier_b, tier_c)

def _generate_episode_queries(meta):
    """Generuje dotazy pro epizody."""
    show_title = normalize_query(meta.get('show_title', ''))
    ep_title = normalize_query(meta.get('ep_title', ''))
    s = meta.get('season')
    e = meta.get('episode')

    if not all([show_title, s is not None, e is not None]):
        return {'A': [], 'B': [], 'C': []}

    # Různé formáty S/E
    se_formats = [
        f"S{s:02d}E{e:02d}",
        f"S{s}E{e}",
        f"{s}x{e:02d}",
        f"{s}x{e}",
        f"{s}{e:02d}" # 101, 1201
    ]

    delimiters = [' ', '.', '-', '_']
    
    tier_a = set() # {show} {S/E}
    tier_b = set() # {show}{S/E}, {show} {S/E} {ep_title}
    tier_c = set() # {show}{S/E}{ep_title}

    for se in se_formats:
        for delim in delimiters:
            # Tier A
            tier_a.add(show_title.replace(' ', delim) + delim + se)
            # Tier B
            tier_b.add(show_title.replace(' ', '') + se)
            if ep_title:
                tier_b.add(show_title.replace(' ', delim) + delim + se + delim + ep_title.replace(' ', delim))
            # Tier C
            if ep_title:
                tier_c.add(show_title.replace(' ', '') + se + ep_title.replace(' ', ''))

    return _finalize_tiers(tier_a, tier_b, tier_c)

def _finalize_tiers(tier_a, tier_b, tier_c):
    """Deduplikuje, omezí a vrátí finální strukturu úrovní dotazů."""
    seen_tokens = set()
    def filter_by_token_set(queries):
        filtered = []
        sorted_queries = sorted(list(queries), key=len, reverse=True)
        for q in sorted_queries:
            tokens = frozenset(re.split(r'[\.\s\-_]', q))
            if tokens not in seen_tokens:
                seen_tokens.add(tokens)
                filtered.append(q)
        return filtered

    tier_a = filter_by_token_set(tier_a)
    tier_b = filter_by_token_set(tier_b)
    tier_c = filter_by_token_set(tier_c)

    all_queries = tier_a + tier_b + tier_c
    limited_queries = all_queries[:SEARCH_MAX_VARIANTS]
    
    final_tier_a = [q for q in limited_queries if q in tier_a]
    final_tier_b = [q for q in limited_queries if q in tier_b]
    final_tier_c = [q for q in limited_queries if q in tier_c]

    return {
        'A': final_tier_a,
        'B': final_tier_b,
        'C': final_tier_c,
    }

# --- Scoring and Filtering Helpers ---

def is_cam_or_ts(name):
    """
    Checks if the release name indicates a low-quality CAM or TS copy.
    """
    name_lower = name.lower()
    bad_quality_tags = ['.cam.', '.ts.', '.tc.', 'camrip', 'hdcam', 'hdts', 'hd-ts']
    return any(tag in name_lower for tag in bad_quality_tags)

def extract_season_episode(name):
    """
    Extracts season and episode number from a string using various regex patterns.
    Returns a tuple (season, episode) or None if not found.
    """
    name = name.lower()
    patterns = [
        r'[sS]\s?(\d{1,2})\s?[eE]\s?(\d{1,2})', # S01E02, S1E2, S 01 E 02
        r'(\d{1,2})\s?[xX]\s?(\d{1,2})',       # 1x02, 1x2
        r'(?<!\d)(\d)(\d{2})(?!\d)',           # 102 (S01E02) - jen pokud je to 3-místné číslo
    ]
    for pattern in patterns:
        match = re.search(pattern, name)
        if match:
            groups = match.groups()
            # Pro (d)(d{2}) je potřeba spojit skupiny
            if len(groups) == 2:
                 return int(groups[0]), int(groups[1])
    return None

def get_media_badges(filename):
    """Extracts media badges from a filename."""
    filename_lower = filename.lower()
    badges = []
    
    # Quality
    if '2160p' in filename_lower or '4k' in filename_lower: badges.append('4K')
    elif '1080p' in filename_lower: badges.append('1080p')
    elif '720p' in filename_lower: badges.append('720p')
    
    # Language / Audio
    if 'cz' in filename_lower or 'cesky' in filename_lower: badges.append('CZ')
    if 'sk' in filename_lower or 'slovensky' in filename_lower: badges.append('SK')
    if 'dab' in filename_lower: badges.append('DAB')
    if 'tit' in filename_lower: badges.append('TIT')

    # Rip Type
    if 'webrip' in filename_lower: badges.append('WEBRip')
    elif 'web-dl' in filename_lower: badges.append('WEBDL')
    elif 'bluray' in filename_lower: badges.append('Bluray')

    return badges
