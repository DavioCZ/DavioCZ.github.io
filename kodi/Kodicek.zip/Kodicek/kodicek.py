# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
from urllib.parse import unquote
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
from xbmc import Player
import datetime

# Manually add the addon's library to the Python path
lib_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

import requests
import hashlib
import md5crypt
import time
import json
import re
import concurrent.futures
from xml.etree import ElementTree as ET
from resources.lib.history import (
    load_history, clear_history, remove_from_history, add_to_history,
    load_search_history, add_to_search_history
)
from resources.lib.tmdb import search_tmdb as new_search_tmdb
from resources.lib import playback_manager
from resources.lib.search_utils import (
    is_cam_or_ts, generate_tiered_query_variants, get_media_badges, 
    normalize_query, extract_season_episode
)
from resources.lib.tmdb_collections import resolve_collection_order_for_candidates
from resources.lib.utils_sort import sort_key_candidate
from resources.lib.playback_monitor import PlaybackMonitor
from typing import Optional, Literal

# --- Kodi-specific Constants ---
KODI_ICON_MOVIE = "DefaultMovies.png"
KODI_ICON_TV = "DefaultTVShows.png"
# KODI_ICON_FALLBACK = "DefaultVideo.png" # Currently unused, but good to have.

class TmdbCandidate:
    def __init__(self, item):
        self.media_type: Literal["movie", "tv"] = item.get('media_type')
        self.id: int = item.get('id')
        self.vote_average: Optional[float] = item.get('vote_average')
        self.vote_count: Optional[int] = item.get('vote_count')
        self.poster: Optional[str] = f"https://image.tmdb.org/t/p/w500{item.get('poster_path')}" if item.get('poster_path') else None
        self.backdrop: Optional[str] = f"https://image.tmdb.org/t/p/w1280{item.get('backdrop_path')}" if item.get('backdrop_path') else None
        
        if self.media_type == 'movie':
            self.title: str = item.get('title')
            self.original_title: str = item.get('original_title')
            release_date: Optional[str] = item.get('release_date')
            self.year: Optional[int] = int(release_date[:4]) if release_date and release_date[:4].isdigit() else None
        else: # tv
            self.title: str = item.get('name')
            self.original_title: str = item.get('original_name')
            air_date: Optional[str] = item.get('first_air_date')
            self.year: Optional[int] = int(air_date[:4]) if air_date and air_date[:4].isdigit() else None

def _ws_hash_pwd(raw_pwd: str, salt: str) -> str:
    """Webshare digest = SHA1(MD5_CRYPT(password, salt))."""
    md5c = md5crypt.md5crypt(raw_pwd.encode("utf-8"), salt.encode("utf-8"))
    return hashlib.sha1(md5c.encode("utf-8")).hexdigest()

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
BASE_URL_PLUGIN = sys.argv[0] 
plugin_name = "Kodíček"
WEBSHARE_API_BASE_URL = "https://webshare.cz/api/"
TMDB_API_BASE_URL = "https://api.themoviedb.org/3/"
UI_LANG = "cs-CZ"

_session = requests.Session()
_session.headers.update({'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64 x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"})

# Jednoduchá cache v paměti pro výsledky vyhledávání
_search_cache = {} # Cache pro zdroje z Webshare
_tmdb_search_cache = {} # Cache pro kandidáty z TMDB
CACHE_TTL_SECONDS = 24 * 3600  # 24 hodin
TMDB_CACHE_TTL_SECONDS = 60 # 60 sekund pro TMDB vyhledávání

YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")

def strip_year(title: str) -> str:
    if not title:
        return ""
    cleaned = YEAR_RE.sub("", title)
    return " ".join(cleaned.split())

def parse_size_to_bytes(size_str: str) -> int:
    if not isinstance(size_str, str):
        return 0
    size_str = size_str.strip().upper()
    multipliers = {'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4, 'B': 1}
    unit = 'B'
    for u in multipliers:
        if size_str.endswith(u):
            unit = u
            size_str = size_str.replace(u, '')
            break
    numeric_part_str = size_str.replace(',', '.').strip()
    try:
        numeric_value = float(numeric_part_str)
        return int(numeric_value * multipliers[unit])
    except (ValueError, KeyError):
        return 0

def get_credentials():
    token = addon.getSetting("ws_token")
    if token:
        return {"token": token}
    username = addon.getSetting("ws_username")
    password = addon.getSetting("ws_password")
    if not username or not password:
        error_message = addon.getLocalizedString(30101) or "Chybí přihlašovací údaje. Zkontrolujte nastavení."
        xbmcgui.Dialog().notification(plugin_name, error_message, xbmcgui.NOTIFICATION_ERROR)
        addon.openSettings()
        return None
    return {"username": username, "password": password}

def get_tmdb_api_key():
    tmdb_key = addon.getSetting("tmdb_api_key")
    if not tmdb_key:
        default_key = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
        addon.setSetting("tmdb_api_key", default_key)
        tmdb_key = default_key
        xbmcgui.Dialog().notification(plugin_name, "Byl nastaven výchozí TMDb API klíč.", xbmcgui.NOTIFICATION_INFO)
    if not tmdb_key:
        xbmcgui.Dialog().notification(plugin_name, "Chybí TMDb API klíč v nastavení!", xbmcgui.NOTIFICATION_ERROR)
        return None
    return tmdb_key

def login_webshare(username, password):
    salt_response_content = playback_manager.api_call('salt', {'username_or_email': username}, base_url=WEBSHARE_API_BASE_URL)
    if not salt_response_content:
        return None
    try:
        salt_xml = ET.fromstring(salt_response_content)
    except ET.ParseError as e:
        xbmc.log(f"Kodíček: Failed to parse salt XML: {e}. Response: {salt_response_content}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Invalid salt response.", xbmcgui.NOTIFICATION_ERROR)
        return None
    if not playback_manager.is_xml_ok(salt_xml):
        xbmcgui.Dialog().notification(plugin_name, "Login error: Could not get salt.", xbmcgui.NOTIFICATION_ERROR)
        return None
    salt_node = salt_xml.find('salt')
    if salt_node is None or not salt_node.text:
        xbmc.log("Kodíček: Salt not found in XML response.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Salt missing.", xbmcgui.NOTIFICATION_ERROR)
        return None
    salt = salt_node.text
    try:
        pwd_hash = _ws_hash_pwd(password, salt)
    except Exception as e:
        xbmc.log(f"Kodíček: Error during password hashing: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Hashing failed.", xbmcgui.NOTIFICATION_ERROR)
        return None
    login_data = {'username_or_email': username, 'password': pwd_hash, 'keep_logged_in': '1'}
    login_response_content = playback_manager.api_call('login', login_data, base_url=WEBSHARE_API_BASE_URL)
    if not login_response_content:
        return None
    try:
        login_xml = ET.fromstring(login_response_content)
    except ET.ParseError as e:
        xbmc.log(f"Kodíček: Failed to parse login XML: {e}. Response: {login_response_content}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Invalid server response.", xbmcgui.NOTIFICATION_ERROR)
        return None
    if not playback_manager.is_xml_ok(login_xml):
        message = "Login failed. Check credentials or API status."
        msg_node = login_xml.find('message')
        if msg_node is not None and msg_node.text:
            message = msg_node.text
        xbmcgui.Dialog().notification(plugin_name, message, xbmcgui.NOTIFICATION_ERROR)
        return None
    token_node = login_xml.find('token')
    if token_node is not None and token_node.text:
        xbmc.log("Kodíček: Login successful.", level=xbmc.LOGINFO)
        return token_node.text
    else:
        xbmc.log("Kodíček: Token not found in login response.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Token missing.", xbmcgui.NOTIFICATION_ERROR)
        return None

def get_mimetype(filename):
    if '.' in filename:
        ext = filename.rsplit('.', 1)[1].lower()
        if ext == 'mp4': return 'video/mp4'
        elif ext == 'mkv': return 'video/x-matroska'
        elif ext == 'avi': return 'video/x-msvideo'
        elif ext == 'ts': return 'video/mp2t'
    return 'application/octet-stream'

def get_playback_preferences(filename):
    """Analyzes a filename and extracts playback preferences."""
    if not filename:
        return []
    
    filename_lower = filename.lower()
    prefs = []
    
    # Quality
    if '2160p' in filename_lower or '4k' in filename_lower:
        prefs.append('2160p')
    elif '1080p' in filename_lower:
        prefs.append('1080p')
    elif '720p' in filename_lower:
        prefs.append('720p')
        
    # Language
    if any(lang in filename_lower for lang in ['.cz', '.cze', 'cz-dab', 'cesky']):
        prefs.append('cz')
    elif any(lang in filename_lower for lang in ['.sk', '.svk', 'slovensky']):
        prefs.append('sk')
        
    # Video Codec / Rip type
    if 'x265' in filename_lower or 'hevc' in filename_lower:
        prefs.append('x265')
    if 'x264' in filename_lower:
        prefs.append('x264')
    if 'dvdrip' in filename_lower:
        prefs.append('dvdrip')
    if 'webrip' in filename_lower:
        prefs.append('webrip')
    if 'web-dl' in filename_lower:
        prefs.append('web-dl')

    xbmc.log(f"[PREFS] Z názvu '{filename}' extrahovány preference: {prefs}", xbmc.LOGINFO)
    return prefs

def _tmdb_get_for_search_module(endpoint, params):
    api_key = get_tmdb_api_key()
    if not api_key:
        return {"results": []} 
    return playback_manager.tmdb_api_request(api_key, endpoint, params)

def get_banner_image_url(tmdb_item, size="w500"):
    if not tmdb_item: return None
    backdrop_path = tmdb_item.get('backdrop_path')
    if backdrop_path: return f"https://image.tmdb.org/t/p/{size}{backdrop_path}"
    poster_path = tmdb_item.get('poster_path')
    if poster_path: return f"https://image.tmdb.org/t/p/{size}{poster_path}"
    return None

def get_tmdb_details(api_key, tmdb_id, media_type='movie', language='cs-CZ'):
    if not tmdb_id:
        xbmc.log("Kodíček: TMDb ID is missing for get_tmdb_details.", level=xbmc.LOGERROR)
        return None
    request_params = {'language': language, 'append_to_response': 'credits,images,videos,external_ids'}
    data = playback_manager.tmdb_api_request(api_key, f"/{media_type}/{tmdb_id}", request_params)
    if data:
        xbmc.log(f"Kodíček: TMDb details fetched successfully for ID: {tmdb_id}", level=xbmc.LOGINFO)
    else:
        xbmc.log(f"Kodíček: Failed to fetch TMDb details for ID: {tmdb_id}", level=xbmc.LOGWARNING)
    return data

def _fmt_history(h):
    # typ ze 'media_type' (nové záznamy) nebo 'kind' (staré)
    mt = h.get("media_type") or h.get("kind")

    # epizoda: ber flat season/episode, fallback i z h["last"]
    if mt in ("episode", "show") or h.get("season") or isinstance(h.get("last"), dict):
        show = (
            h.get("show_original_title")
            or h.get("show_title")
            or h.get("tvshowtitle")
            or "Neznámý seriál"
        )
        last = h.get("last") or {}
        try:
            s = int(h.get("season") if h.get("season") is not None else last.get("season", 0))
            e = int(h.get("episode") if h.get("episode") is not None else last.get("episode", 0))
        except Exception:
            s = e = 0
        ep = h.get("episode_title") or h.get("title") or ""
        # POŽADOVANÝ FORMÁT: <show> <SSxEE> <episode>
        label = f"{show} {s:02d}x{e:02d}"
        if ep:
            label += f" {ep}"
        return label.strip()

    # film
    title = h.get("title") or "Neznámý film"
    y = h.get("year")
    return f"{title} ({y})" if y else title

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "open_settings":
        addon.openSettings()
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return

    creds = get_credentials()
    if not creds:
        if action: xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    token = creds.get("token")
    if not token:
        token = addon.getSetting('token')

    if not token:
        username = creds.get("username")
        password = creds.get("password")
        token = login_webshare(username, password)
        if token:
            addon.setSetting('token', token)
            addon.setSetting('ws_token', token)
        else:
            if action: xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

    if action == "search":
        what_to_search = params.get("what") 
        ask_for_input = params.get("ask") == "1"

        if ask_for_input:
            search_term_from_dialog = xbmcgui.Dialog().input(f"{plugin_name} – Vyhledat film/seriál", type=xbmcgui.INPUT_ALPHANUM)
            if search_term_from_dialog:
                what_to_search = search_term_from_dialog
                xbmc.log(f"Kodicek: Storing search query from dialog: {what_to_search}", xbmc.LOGINFO)
                add_to_search_history({"query": what_to_search, "timestamp": int(time.time())})
            else:
                what_to_search = None
        
        if what_to_search and not ask_for_input:
            try:
                add_to_search_history({"query": what_to_search, "timestamp": int(time.time())})
            except Exception as e:
                xbmc.log(f"Kodicek: add_to_search_history failed: {e}", xbmc.LOGWARNING)

        if what_to_search:
            tmdb_api_key = get_tmdb_api_key()
            if not tmdb_api_key:
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return

            query_text_for_tmdb = strip_year(what_to_search)
            
            # Fáze E1: Cache pro TMDB
            cached_entry = _tmdb_search_cache.get(query_text_for_tmdb)
            if cached_entry and time.time() - cached_entry['timestamp'] < TMDB_CACHE_TTL_SECONDS:
                xbmc.log(f"[CACHE] TMDB HIT for query: {query_text_for_tmdb}", level=xbmc.LOGINFO)
                tmdb_results = cached_entry['results']
            else:
                xbmc.log(f"[CACHE] TMDB MISS for query: {query_text_for_tmdb}", level=xbmc.LOGINFO)
                tmdb_results = new_search_tmdb(query_text_for_tmdb, _tmdb_get_for_search_module)
                if tmdb_results:
                    _tmdb_search_cache[query_text_for_tmdb] = {'timestamp': time.time(), 'results': tmdb_results}

            if not tmdb_results:
                xbmcgui.Dialog().notification(plugin_name, "Na TMDb nebylo nic nalezeno.", xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return

            # Vždy zobrazit seznam kandidátů, žádný autopick
            xbmc.log(f"[ROUTER] listing TMDB candidates: N={len(tmdb_results)}, query=\"{what_to_search}\"")
            # Předáme i parametr filtru, pokud existuje
            media_filter = params.get("filter")
            list_tmdb_candidates(tmdb_results, what_to_search, media_filter)

        else: 
            xbmcplugin.setPluginCategory(addon_handle, "Vyhledávání")
            li_new_search = xbmcgui.ListItem(label="Nové vyhledávání...")
            li_new_search.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search&ask=1", listitem=li_new_search, isFolder=True)
            search_history_items = load_search_history()
            if search_history_items:
                for item in search_history_items:
                    query_text = item.get("query")
                    if query_text:
                        timestamp_str = time.strftime('%d.%m.%y %H:%M', time.localtime(item['timestamp']))
                        li = xbmcgui.ListItem(label=f"Hledáno: {query_text} ({timestamp_str})")
                        url = f"{BASE_URL_PLUGIN}?action=search&what={urllib.parse.quote(query_text, encoding='utf-8')}"
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

    elif action == "play":
        ident = params.get("ident")
        file_name_for_playback = unquote(params.get("name", "Přehrávaný soubor"))
        if not ident:
            xbmcgui.Dialog().notification(plugin_name, "Chybí ident souboru.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        stream_url = playback_manager.get_stream_link(token, ident)
        if not stream_url:
            xbmcgui.Dialog().notification(plugin_name, "Nepodařilo se získat odkaz.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        headers_str = urllib.parse.urlencode({'User-Agent': _session.headers.get('User-Agent', 'Mozilla/5.0'), 'Cookie': f'wst={token}'})
        path_with_headers = f"{stream_url}|{headers_str}"
        
        li = xbmcgui.ListItem(path=path_with_headers)
        tag = li.getVideoInfoTag()
        tag.setTitle(file_name_for_playback)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType(get_mimetype(file_name_for_playback))

        # Resume position if available
        resume_pos = params.get('resume_pos')
        if resume_pos and float(resume_pos) > 0:
            li.setProperty("StartOffset", str(float(resume_pos)))

        # Uložení do historie PŘED spuštěním přehrávání
        # parametry by měly být již dekódované díky parse_qsl
        media_type_param = params.get("media_type") or params.get("type")

        if media_type_param in ("episode", "tv", "show"):
            history_item = {
                "media_type": "episode",
                "tmdb_id": int(params.get("tmdb_id") or 0),
                "show_original_title": params.get("show_original_title") or params.get("show_title") or "",
                "show_title": params.get("show_title", ""),
                "title": params.get("title", ""),
                "season": int(params.get("season") or 0),
                "episode": int(params.get("episode") or 0),
                "poster": params.get("poster", ""),
            }
            add_to_history(history_item)
        else:
            history_item = {
                "media_type": "movie",
                "tmdb_id": int(params.get("tmdb_id") or 0),
                "title": params.get("title") or params.get("name") or "",
                "year": int(params.get("year") or 0),
                "poster": params.get("poster", ""),
            }
            add_to_history(history_item)

        # Teprve teď spustíme přehrávání
        xbmcplugin.setResolvedUrl(addon_handle, True, li)

    elif action == "show_history":
        xbmcplugin.setPluginCategory(addon_handle, "Historie")
        
        # 1. Položka pro historii vyhledávání
        li_search_history = xbmcgui.ListItem(label="Historie vyhledávání")
        li_search_history.setArt({'icon': 'DefaultAddonsSearch.png'})
        search_history_url = f"{BASE_URL_PLUGIN}?action=search"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_history_url, listitem=li_search_history, isFolder=True)

        # 2. Položka pro vymazání historie
        li_clear = xbmcgui.ListItem(label="[Vymazat historii]")
        li_clear.setArt({'icon': 'DefaultAddonsClean.png'})
        clear_url = f"{BASE_URL_PLUGIN}?action=clear_history"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=clear_url, listitem=li_clear, isFolder=False)

        # 3. Načtení a zobrazení historie přehrávání
        items = load_history()
        for h in items:
            li = xbmcgui.ListItem(label=_fmt_history(h))
            
            art = {"poster": h.get("poster"), "thumb": h.get("poster"), "banner": h.get("poster")}
            li.setArt(art)

            tag = li.getVideoInfoTag()
            kind = h.get('media_type') or h.get('kind')

            if kind in ('show', 'episode'):
                tag.setMediaType('episode')
                tag.setTvShowTitle(h.get('show_original_title') or h.get('show_title') or h.get('tvshowtitle') or '')
                last = h.get('last') or {}
                s = int(h.get('season') if h.get('season') is not None else last.get('season', 0))
                e = int(h.get('episode') if h.get('episode') is not None else last.get('episode', 0))
                tag.setSeason(s)
                tag.setEpisode(e)
                tag.setTitle(h.get('episode_title') or h.get('title') or '')
            else:
                tag.setMediaType('movie')
                tag.setTitle(h.get('title', ''))
                if h.get('year'):
                    tag.setYear(int(h['year']))

            # otevření detailu
            is_movie = (h.get('media_type') == 'movie') or (h.get('kind') == 'movie')
            if is_movie:
                url_params = {'action': 'open_tmdb_title', 'tmdb_id': h["tmdb_id"], 'media_type': 'movie', 'title': h.get('title',''), 'year': h.get('year','')}
                url = f"{BASE_URL_PLUGIN}?{urllib.parse.urlencode(url_params)}"
                is_folder = True
            else:
                show_label = h.get('show_original_title') or h.get('show_title') or h.get('tvshowtitle') or ''
                url = f"{BASE_URL_PLUGIN}?action=show_seasons&tmdb_id={h['tmdb_id']}&show_title={urllib.parse.quote(show_label)}"
                is_folder = True

            # Kontextové menu: pošli správný 'kind'
            menu_kind = (h.get('kind') or ('show' if (h.get('media_type') in ('show','episode')) else 'movie'))
            remove_url = f"RunPlugin({BASE_URL_PLUGIN}?action=remove_from_history&kind={menu_kind}&tmdb_id={h['tmdb_id']})"
            li.addContextMenuItems([('Odstranit z historie', remove_url)])

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)
        
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

    elif action == "clear_history":
        if xbmcgui.Dialog().yesno("Vymazat historii", "Opravdu si přejete smazat celou historii přehrávání?"):
            if clear_history():
                xbmcgui.Dialog().notification(plugin_name, "Historie byla vymazána.", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification(plugin_name, "Smazání historie selhalo.", xbmcgui.NOTIFICATION_ERROR)

    elif action == "remove_from_history":
        kind = params.get("kind")
        tmdb_id = params.get("tmdb_id")
        if kind and tmdb_id:
            if remove_from_history(kind, tmdb_id):
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification(plugin_name, "Odstranění položky selhalo.", xbmcgui.NOTIFICATION_ERROR)
    
    # Tato akce je nyní zastaralá a nahrazena přímým voláním z list_tmdb_candidates
    # elif action == "process_tmdb_selection":
    #     process_media_selection(params, token, mode='movie')

    elif action == "show_seasons":
        try:
            tmdb_id = params.get("tmdb_id")
            show_title = params.get("show_title", "Seriál")
            api_key = get_tmdb_api_key()
            if not api_key or not tmdb_id:
                xbmcgui.Dialog().notification(plugin_name, "Chyba: Chybí API klíč nebo ID seriálu.", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return
            tv_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}", {'language': UI_LANG, 'append_to_response': 'images'})
            if not tv_details or not tv_details.get("seasons"):
                xbmcgui.Dialog().notification(plugin_name, "Nepodařilo se načíst informace o sezónách.", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return
            xbmcplugin.setPluginCategory(addon_handle, f"{show_title} - Sezóny")
            xbmcplugin.setContent(addon_handle, 'tvshows')
            for season in tv_details.get("seasons", []):
                season_number = season.get("season_number")
                
                skip_specials = True 
                try:
                    skip_specials = addon.getSettingBool("tmdb_skip_specials")
                except TypeError:
                    xbmc.log("Kodíček: 'tmdb_skip_specials' setting missing or invalid type, defaulting to True.", level=xbmc.LOGWARNING)

                if season_number == 0 and skip_specials: 
                     continue
                season_name = season.get("name") or f"Sezóna {season_number}"
                episode_count = season.get("episode_count", 0)
                display_label = f"{season_name} ({episode_count} epizod)"
                li = xbmcgui.ListItem(label=display_label)
                art_data = {}
                poster_path = season.get('poster_path') or tv_details.get('poster_path')
                if poster_path: art_data['thumb'] = art_data['poster'] = f"https://image.tmdb.org/t/p/w500{poster_path}"
                fanart_url = get_banner_image_url(tv_details)
                if fanart_url: art_data['fanart'] = fanart_url
                if not art_data.get('thumb') and fanart_url: art_data['thumb'] = fanart_url
                li.setArt(art_data)
                info = {'title': season_name, 'plot': season.get('overview', ''), 'tvshowtitle': show_title, 'season': season_number, 'episode': episode_count, 'mediatype': 'season'}
                if season.get('air_date'): info['premiered'] = season.get('air_date')
                
                tag = li.getVideoInfoTag()
                tag.setTitle(info.get('title', ''))
                tag.setPlot(info.get('plot', ''))
                tag.setTvShowTitle(info.get('tvshowtitle', ''))
                tag.setSeason(info.get('season', -1))
                tag.setEpisode(info.get('episode', -1))
                tag.setMediaType(info.get('mediatype', ''))
                if info.get('premiered'):
                    tag.setPremiered(info.get('premiered'))

                li.setProperty('IsPlayable', 'false')
                url = f"{BASE_URL_PLUGIN}?action=show_episodes&tmdb_id={tmdb_id}&season_number={season_number}&show_title={urllib.parse.quote(show_title, encoding='utf-8')}&show_year={tv_details.get('first_air_date', '')[:4]}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        except Exception as e:
            xbmc.log(f"[ROUTER] fail -> fallback to candidates. Action: show_seasons. Error: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification(plugin_name, "Došlo k chybě, vracím se zpět.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

    elif action == "show_episodes":
        try:
            tmdb_id = params.get("tmdb_id")
            season_number = params.get("season_number")
            show_title = params.get("show_title", "Seriál")
            win = xbmcgui.Window(10000)
            tv_details_full = playback_manager.tmdb_api_request(get_tmdb_api_key(), f"/tv/{tmdb_id}", {'language': UI_LANG})
            if tv_details_full and 'seasons' in tv_details_full:
                show_structure = {
                    'tmdb_id': tmdb_id,
                    'seasons': {s['season_number']: {'episode_count': s['episode_count']} for s in tv_details_full['seasons']}
                }
                win.setProperty(f'{addon.getAddonInfo("id")}.show_structure', json.dumps(show_structure))
            show_year = params.get("show_year", "")
            api_key = get_tmdb_api_key()
            if not api_key or not tmdb_id or season_number is None:
                xbmcgui.Dialog().notification(plugin_name, "Chyba: Chybí API klíč, ID seriálu nebo číslo sezóny.", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return
            season_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}", {'language': UI_LANG, 'append_to_response': 'images'})
            if not season_details or not season_details.get("episodes"):
                xbmcgui.Dialog().notification(plugin_name, "Nepodařilo se načíst informace o epizodách.", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return
            xbmcplugin.setPluginCategory(addon_handle, f"{show_title} - Sezóna {season_number} - Epizody")
            xbmcplugin.setContent(addon_handle, 'episodes')
            for episode in season_details.get("episodes", []):
                episode_number = episode.get("episode_number")
                episode_name = episode.get("name") or f"Epizoda {episode_number}"
                display_label = f"E{episode_number:02d}: {episode_name}"
                li = xbmcgui.ListItem(label=display_label)
                art_data = {}
                still_path = episode.get('still_path')
                if still_path: art_data['thumb'] = art_data['icon'] = f"https://image.tmdb.org/t/p/w300{still_path}"
                else: 
                    season_poster = season_details.get('poster_path')
                    if season_poster: art_data['thumb'] = f"https://image.tmdb.org/t/p/w500{season_poster}"
                li.setArt(art_data)
                info = {'title': episode_name, 'plot': episode.get('overview', ''), 'tvshowtitle': show_title, 'season': int(season_number), 'episode': episode_number, 'mediatype': 'episode', 'premiered': episode.get('air_date','')}
                if episode.get('vote_average'): info['rating'] = episode.get('vote_average')

                tag = li.getVideoInfoTag()
                tag.setTitle(info.get('title', ''))
                tag.setPlot(info.get('plot', ''))
                tag.setTvShowTitle(info.get('tvshowtitle', ''))
                tag.setSeason(info.get('season', -1))
                tag.setEpisode(info.get('episode', -1))
                tag.setMediaType(info.get('mediatype', ''))
                if info.get('premiered'):
                    tag.setPremiered(info.get('premiered'))
                if info.get('rating'):
                    tag.setRating(float(info.get('rating')))

                url = f"{BASE_URL_PLUGIN}?action=play_episode&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&show_title={urllib.parse.quote(show_title, encoding='utf-8')}&episode_name_cs={urllib.parse.quote(episode.get('name', ''), encoding='utf-8')}&show_year={show_year}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        except Exception as e:
            xbmc.log(f"[ROUTER] fail -> fallback to candidates. Action: show_episodes. Error: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification(plugin_name, "Došlo k chybě, vracím se zpět.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

    elif action == "play_episode":
        try:
            # Zde se nyní volá obecná funkce pro vyhledávání zdrojů
            process_media_selection(params, token, mode='episode')
        except Exception as e:
            xbmc.log(f"[ROUTER] fail -> fallback to candidates. Action: play_episode. Error: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification(plugin_name, "Došlo k chybě při hledání zdrojů.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

    elif action == 'movies':
        movies(params)
    elif action == 'series':
        series(params)
    elif action == "search_test":
        xbmc.log(f"Kodíček: Action 'search_test' entered. Params: {params}", level=xbmc.LOGINFO)
        xbmcgui.Dialog().notification(plugin_name, "Testovací vyhledávání spuštěno!", xbmcgui.NOTIFICATION_INFO, 3000)
        search_term = xbmcgui.Dialog().input(f"{plugin_name} – Testovací vyhledávání (Webshare)", type=xbmcgui.INPUT_ALPHANUM)
        if search_term:
            files = playback_manager.search_webshare(token, search_term)
            if not files:
                xbmcgui.Dialog().notification(plugin_name, f"Test: Nic pro '{search_term}'", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcplugin.setPluginCategory(addon_handle, f"Testovací výsledky (Webshare) pro: {search_term}")
                xbmcplugin.setContent(addon_handle, 'videos')
                for file_item in files:
                    li = xbmcgui.ListItem(label=f"[TEST] {file_item['name']}")
                    tag = li.getVideoInfoTag()
                    tag.setTitle(file_item["name"])
                    li.setProperty('IsPlayable', 'true')
                    url = f"{BASE_URL_PLUGIN}?action=play&ident={file_item['ident']}&name={urllib.parse.quote(file_item['name'])}"
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
    elif action == "search_original":
        query = params.get('query', '')
        if query:
            files = playback_manager.search_webshare(token, query)
            if not files:
                xbmcgui.Dialog().notification(plugin_name, f"Pro '{query}' nebylo nic nalezeno.", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcplugin.setPluginCategory(addon_handle, f"Výsledky pro: {query}")
                xbmcplugin.setContent(addon_handle, 'videos')
                for file_item in files:
                    li = xbmcgui.ListItem(label=file_item["name"])
                    size_bytes = file_item.get("size", 0)
                    size_str = f"{size_bytes/(1024*1024*1024):.2f} GB"
                    tag = li.getVideoInfoTag()
                    tag.setTitle(file_item["name"])
                    tag.setPlot(f"Velikost: {size_str}")
                    # 'size' is not a standard InfoTagVideo property, so we omit it from the tag.
                    li.setProperty('IsPlayable', 'true')
                    url = f"{BASE_URL_PLUGIN}?action=play&ident={file_item['ident']}&name={urllib.parse.quote(file_item['name'], encoding='utf-8')}"
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
    elif action == "open_tmdb_title":
        try:
            # Tato akce je nyní vstupním bodem pro vyhledávání zdrojů pro film
            xbmc.log(f"[OPEN] movie tmdb_id={params.get('tmdb_id')} -> start search_webshare(mode=movie)")
            process_media_selection(params, token, mode='movie')
        except Exception as e:
            xbmc.log(f"[ROUTER] fail -> fallback to candidates. Action: open_tmdb_title. Error: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification(plugin_name, "Došlo k chybě při hledání zdrojů.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    else:
        display_main_menu()

def build_candidate_label(c):
    media_type_str = "[FILM]" if c.media_type == "movie" else "[SERIÁL]"
    rating = f"{int(c.vote_average * 10)}%" if c.vote_average is not None else "–"
    year = f" ({c.year})" if c.year else ""
    return f"{media_type_str} {c.title}{year} — {rating}"

def list_tmdb_candidates(candidates_raw, original_query, media_filter=None):
    """Zobrazí seznam TMDB kandidátů, s možností seskupování a filtrování."""
    xbmcplugin.setPluginCategory(addon_handle, f"Výsledky pro: '{original_query}'")
    xbmcplugin.setContent(addon_handle, 'videos')

    # Načtení nastavení
    group_by_type = addon.getSettingBool('group_results_by_type')

    cands = [TmdbCandidate(item) for item in candidates_raw if item.get('media_type') in ['movie', 'tv']]
    
    # Pokud je zapnuté seskupování a ještě nefiltrujeme, zobrazíme složky
    if group_by_type and not media_filter:
        movies = [c for c in cands if c.media_type == 'movie']
        tvs = [c for c in cands if c.media_type == 'tv']
        
        if movies:
            url = f"{BASE_URL_PLUGIN}?action=search&what={urllib.parse.quote(original_query.encode('utf-8'))}&filter=movie"
            li = xbmcgui.ListItem(label=f"🎬 Filmy ({len(movies)})")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        if tvs:
            url = f"{BASE_URL_PLUGIN}?action=search&what={urllib.parse.quote(original_query.encode('utf-8'))}&filter=tv"
            li = xbmcgui.ListItem(label=f"📺 Seriály a speciály ({len(tvs)})")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return

    # Filtrování, pokud je aktivní
    if media_filter:
        cands = [c for c in cands if c.media_type == media_filter]

    # ... po filtrování cands / media_filter
    coll_map = resolve_collection_order_for_candidates(cands)
    cands_sorted = sorted(cands, key=lambda c: sort_key_candidate(c, coll_map))

    for c in cands_sorted:
        li = xbmcgui.ListItem(label=build_candidate_label(c))

        # Odstraněno nastavování ikon, které způsobovalo problémy.
        # Místo toho je typ média zobrazen přímo v popisku.
        art = {}
        if getattr(c, "backdrop", None):
            art["fanart"] = c.backdrop
        if getattr(c, "poster", None):
            art["poster"] = c.poster # Ponecháme pro detailní zobrazení

        if art:
            li.setArt(art)

        # InfoTagVideo: rok + TMDB rating
        tag = li.getVideoInfoTag()
        tag.setTitle(c.title or "")
        if c.year: tag.setYear(int(c.year))
        if c.vote_average is not None:
            # rating + počet hlasů, aby skiny mohly ukázat hvězdičky
            tag.setRating(float(c.vote_average), votes=int(c.vote_count or 0))
        # pro některé skiny pomáhá nastavit mediatype
        try:
            tag.setMediaType("movie" if c.media_type == "movie" else "tvshow")
        except Exception:
            pass

        if c.media_type == 'tv':
            url = f"{BASE_URL_PLUGIN}?action=show_seasons&tmdb_id={c.id}&show_title={urllib.parse.quote(c.title.encode('utf-8'))}"
        else: # movie
            url_params = {
                'action': 'open_tmdb_title', 'tmdb_id': c.id, 'media_type': c.media_type,
                'title': urllib.parse.quote(c.title.encode('utf-8')), 'year': c.year or ''
            }
            url = f"{BASE_URL_PLUGIN}?{urllib.parse.urlencode(url_params)}"

        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

def process_media_selection(params, token, mode='movie'):
    """
    Sjednocená funkce pro vyhledávání a zobrazení zdrojů pro filmy i epizody.
    """
    # --- Získání metadat ---
    if mode == 'movie':
        tmdb_id = params.get('tmdb_id')
        title = unquote(params.get('title', ''))
        year = params.get('year', '')
        cache_key = f"movie:{tmdb_id}|{title}|{year}"
    else: # episode
        tmdb_id = params.get('tmdb_id')
        show_title = unquote(params.get('show_title', ''))
        season = int(params.get('season', 0))
        episode = int(params.get('episode', 0))
        xbmc.log(f"[OPEN] episode show_id={tmdb_id} S={season} E={episode} -> start search_webshare(mode=episode)")
        cache_key = f"episode:{tmdb_id}|S{season:02d}E{episode:02d}"

    # --- Cache ---
    if cache_key in _search_cache:
        cached_data = _search_cache[cache_key]
        if time.time() - cached_data['timestamp'] < CACHE_TTL_SECONDS:
            xbmc.log(f"[CACHE] HIT for key: {cache_key}", level=xbmc.LOGINFO)
            # Zde bychom mohli rovnou zobrazit výsledky z cache
            # Pro jednoduchost zatím jen logujeme, plná implementace by vyžadovala i uložení a zobrazení ListItem
            # V tomto refaktoringu se zaměříme na logiku sběru dat
            pass # pass, aby se kód provedl a na konci uložil čerstvá data

    # --- Načtení nastavení ---
    if mode == 'movie':
        COLLECT_THR = 1.2
        FINAL_THR = 1.5
        STOP_AFTER_K = 30
        GLOBAL_TIMEOUT_MS = 3000
        PARALLEL_WORKERS = 4
    else: # episode
        COLLECT_THR = 1.2 # Epizody nepotřebují tak přísné skóre
        FINAL_THR = 1.5
        STOP_AFTER_K = 15
        GLOBAL_TIMEOUT_MS = 3000
        PARALLEL_WORKERS = 4
    
    MAX_PAGES = 3
    RESULTS_PER_PAGE = 100

    xbmc.log(f"[SEARCH] start; mode={mode}; collect_thr={COLLECT_THR}; final_thr={FINAL_THR}; stop_after={STOP_AFTER_K}; timeout={GLOBAL_TIMEOUT_MS}ms", level=xbmc.LOGINFO)

    # --- Příprava metadat a generování dotazů ---
    tmdb_api_key = get_tmdb_api_key()
    meta = {}
    if mode == 'movie':
        detailed_item = get_tmdb_details(tmdb_api_key, tmdb_id, 'movie') if tmdb_api_key and tmdb_id else {}
        meta = {
            'title': detailed_item.get('title', title),
            'original_title': detailed_item.get('original_title', title),
            'year': int(year) if year and year.isdigit() else None
        }
        query_tiers = generate_tiered_query_variants(meta, mode='movie')
    else: # episode
        # Pro epizody potřebujeme detaily seriálu a epizody
        show_details = get_tmdb_details(tmdb_api_key, tmdb_id, 'tv')
        ep_details = playback_manager.tmdb_api_request(tmdb_api_key, f"/tv/{tmdb_id}/season/{season}/episode/{episode}", {'language': UI_LANG})
        meta = {
            'show_title': show_details.get('name', show_title),
            'ep_title': ep_details.get('name', ''),
            'season': season,
            'episode': episode
        }
        query_tiers = generate_tiered_query_variants(meta, mode='episode')
    xbmc.log(f"[SEARCH] Generated tiered queries: A={len(query_tiers['A'])}, B={len(query_tiers['B'])}, C={len(query_tiers['C'])}", level=xbmc.LOGINFO)

    start_time = time.time()
    collected_files = {}  # Slovník pro deduplikaci a ukládání souborů
    dedup_keys = set() # Set pro ukládání deduplikačních klíčů
    total_raw_results = 0

    # --- Pomocné funkce pro scheduler ---
    def _get_dedup_key(file_item):
        """Generuje klíč pro deduplikaci na základě názvu a velikosti."""
        name = file_item.get('name', '')
        size = file_item.get('size', 0)
        
        # Odstranění přípony pro lepší shodu
        base_name = os.path.splitext(name)[0]
        
        # Zaokrouhlení velikosti na 2% toleranci
        size_rounded = int(size / (1024 * 1024 * 0.02)) * int(1024 * 1024 * 0.02)
        
        return f"{base_name.lower()}|{size_rounded}"

    def _calculate_score(ws_file, meta, mode):
        file_name = ws_file.get('name', '')
        fname_normalized = normalize_query(file_name)
        score = 0.0

        if mode == 'movie':
            norm_title = normalize_query(strip_year(meta['title']))
            norm_orig_title = normalize_query(strip_year(meta['original_title']))
            if norm_title in fname_normalized or (norm_orig_title and norm_orig_title in fname_normalized):
                score += 2.0
            else:
                return 0.0
            
            year_match = re.search(r'\b(19|20)\d{2}\b', file_name)
            if year_match and meta['year']:
                if abs(int(year_match.group(0)) - meta['year']) <= 1: score += 1.5
                else: score -= 0.5
        else: # episode
            se = extract_season_episode(fname_normalized)
            if se and se[0] == meta['season'] and se[1] == meta['episode']:
                score += 2.0
            else:
                return 0.0
            if normalize_query(meta['ep_title']) in fname_normalized:
                score += 0.5

        # Společné skórování
        if any(tag in fname_normalized for tag in ['cz', 'cesky', 'dabing', 'dab']): score += 1.0
        if any(tag in fname_normalized for tag in ['titulky', 'tit']): score += 0.5
        if '2160p' in fname_normalized or '4k' in fname_normalized: score += 1.5
        elif '1080p' in fname_normalized: score += 1.0
        elif '720p' in fname_normalized: score += 0.5
        if 'bluray' in fname_normalized: score += 0.8
        if 'webdl' in fname_normalized or 'web-dl' in fname_normalized: score += 0.7
        if 'webrip' in fname_normalized: score += 0.6
        if file_name.lower().endswith(('.mkv', '.mp4', '.avi')): score += 0.2
        if is_cam_or_ts(file_name): return 0.0
        return score

    def fetch_and_process_page(query, page):
        """Stáhne jednu stránku výsledků a zpracuje ji."""
        offset = page * RESULTS_PER_PAGE
        results = playback_manager.search_webshare(token, query, limit=RESULTS_PER_PAGE, offset=offset)
        if not results:
            return []
        
        newly_found = []
        for item in results:
            dedup_key = _get_dedup_key(item)
            if dedup_key not in dedup_keys:
                score = _calculate_score(item, meta, mode)
                if score >= COLLECT_THR:
                    ident = item['ident']
                    item_with_score = {'file': item, 'score': score}
                    collected_files[ident] = item_with_score
                    dedup_keys.add(dedup_key)
                    newly_found.append(item_with_score)
        return newly_found

    # --- Hlavní smyčka scheduleru ---
    with concurrent.futures.ThreadPoolExecutor(max_workers=PARALLEL_WORKERS) as executor:
        for tier_name, queries in query_tiers.items():
            if not queries: continue
            
            xbmc.log(f"[SCHEDULER] Running Tier {tier_name} with {len(queries)} queries.", level=xbmc.LOGINFO)
            
            # Spustíme první stránku pro všechny dotazy v tieru
            future_to_query = {executor.submit(fetch_and_process_page, q, 0): q for q in queries}
            
            for future in concurrent.futures.as_completed(future_to_query):
                query = future_to_query[future]
                try:
                    page1_results = future.result()
                    total_raw_results += len(page1_results)
                    
                    # Podmíněné stránkování (smart_pages)
                    good_candidates_count = len([f for f in collected_files.values() if f['score'] >= FINAL_THR])
                    if len(page1_results) < 25 or good_candidates_count < 20:
                        for p in range(1, MAX_PAGES):
                            page_results = fetch_and_process_page(query, p)
                            total_raw_results += len(page_results)
                            if not page_results: break
                except Exception as exc:
                    xbmc.log(f'Query {query} generated an exception: {exc}', level=xbmc.LOGERROR)

            # Kontrola STOP podmínek po každém tieru
            good_candidates = [f for f in collected_files.values() if f['score'] >= FINAL_THR]
            elapsed_ms = (time.time() - start_time) * 1000
            
            if len(good_candidates) >= STOP_AFTER_K:
                xbmc.log(f"[SCHEDULER] Stop condition met: Found {len(good_candidates)} >= {STOP_AFTER_K} candidates.", level=xbmc.LOGINFO)
                break
            if elapsed_ms > GLOBAL_TIMEOUT_MS:
                xbmc.log(f"[SCHEDULER] Stop condition met: Timeout {elapsed_ms:.0f}ms > {GLOBAL_TIMEOUT_MS}ms.", level=xbmc.LOGWARNING)
                break

    # --- Zpracování a zobrazení výsledků ---
    final_results = list(collected_files.values())
    final_results.sort(key=lambda x: x['score'], reverse=True)
    
    final_results = [r for r in final_results if r['score'] >= FINAL_THR]
    xbmc.log(f"[SEARCH] Total raw results: {total_raw_results}, Unique collected: {len(collected_files)}, Final (score>={FINAL_THR}): {len(final_results)}", level=xbmc.LOGINFO)

    display_title = meta.get('title') or meta.get('show_title')
    display_year = meta.get('year', '')
    if not final_results:
        title_for_notification = f"{display_title} S{meta['season']:02d}E{meta['episode']:02d}" if mode == 'episode' else f"{display_title} ({display_year})"
        
        # Fallback: Pokud nemáme přesné shody, zobrazíme obecné výsledky
        fallback_results = list(collected_files.values())
        fallback_results = [r for r in fallback_results if not is_cam_or_ts(r['file']['name'])]
        fallback_results.sort(key=lambda x: x['score'], reverse=True)
        
        if fallback_results:
            xbmcgui.Dialog().notification(plugin_name, "Nenašli jsme přesnou shodu, zobrazuji obecné výsledky.", xbmcgui.NOTIFICATION_WARNING)
            final_results = fallback_results[:100] # Omezíme na 100 nejlepších
        else:
            xbmcgui.Dialog().notification(plugin_name, f"Pro '{title_for_notification}' nebyly nalezeny žádné relevantní soubory.", xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
            return

    if mode == 'movie':
        xbmcplugin.setPluginCategory(addon_handle, f"Webshare zdroje pro: {display_title} ({display_year})")
        xbmcplugin.setContent(addon_handle, 'videos')
    else:
        xbmcplugin.setPluginCategory(addon_handle, f"Webshare zdroje pro: {display_title} S{meta['season']:02d}E{meta['episode']:02d}")
        xbmcplugin.setContent(addon_handle, 'episodes')

    if final_results:
        _search_cache[cache_key] = {'timestamp': time.time(), 'results': final_results}
        xbmc.log(f"[CACHE] Stored {len(final_results)} results for key: {cache_key}", level=xbmc.LOGINFO)

    for scored_item in final_results:
        file_item = scored_item['file']
        badges = get_media_badges(file_item['name'])
        badge_str = f"[{' | '.join(badges)}]" if badges else ""
        display_label = f"{badge_str} {file_item['name']}".strip()
        
        li = xbmcgui.ListItem(label=display_label)
        size_bytes = file_item.get("size", 0)
        size_str = f"{size_bytes/(1024*1024*1024):.2f} GB"
        
        tag = li.getVideoInfoTag()
        tag.setTitle(file_item["name"])
        tag.setPlot(f"Velikost: {size_str}")
        # 'size' is not a standard InfoTagVideo property, so we omit it from the tag.
        li.setProperty('IsPlayable', 'true')
        
        url_params = {
            'action': 'play',
            'ident': file_item['ident'],
            'name': file_item['name'],
            'size': file_item.get('size', 0)
        }
        if mode == 'movie':
            poster_url = f"https://image.tmdb.org/t/p/w500{detailed_item.get('poster_path')}" if detailed_item.get('poster_path') else ''
            url_params.update({
                'media_type': 'movie',
                'tmdb_id': tmdb_id,
                'title': meta.get('title', ''),
                'year': meta.get('year', ''),
                'poster': poster_url
            })
        elif mode == 'episode':
            poster_url = f"https://image.tmdb.org/t/p/w500{show_details.get('poster_path')}" if show_details.get('poster_path') else ''
            url_params.update({
                'media_type': 'episode',
                'tmdb_id': tmdb_id,
                'season': meta['season'],
                'episode': meta['episode'],
                'show_title': meta['show_title'],
                'show_original_title': show_details.get('original_name', meta['show_title']),
                'title': meta.get('ep_title', ''),
                'poster': poster_url
            })
        
        # urlencode se postará o správné kódování, není třeba ručně volat quote
        url = f"{BASE_URL_PLUGIN}?{urllib.parse.urlencode(url_params)}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

def movies(params):
    xbmcgui.Dialog().notification(plugin_name, "Zde bude seznam filmů.", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmcplugin.endOfDirectory(addon_handle)

def series(params):
    xbmcgui.Dialog().notification(plugin_name, "Zde bude seznam seriálů.", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmcplugin.endOfDirectory(addon_handle)

# Stará funkce display_combined_history() je nyní nahrazena logikou v history.py
# Můžeme ji smazat nebo zakomentovat pro referenci.
# def display_combined_history(): ...

def display_main_menu():
    li_new_search = xbmcgui.ListItem(label="Vyhledat film/seriál")
    li_new_search.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search&ask=1", listitem=li_new_search, isFolder=True)
    
    listitem_movies = xbmcgui.ListItem(label="Filmy")
    listitem_movies.setArt({'icon': 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=movies", listitem=listitem_movies, isFolder=True)

    listitem_series = xbmcgui.ListItem(label="Seriály")
    listitem_series.setArt({'icon': 'DefaultTVShows.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=series", listitem=listitem_series, isFolder=True)

    li_history_folder = xbmcgui.ListItem(label="Historie")
    li_history_folder.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=show_history", listitem=li_history_folder, isFolder=True)

    testing_enabled = addon.getSetting("testing_functions") == 'true'

    if testing_enabled:
        li_search_test = xbmcgui.ListItem(label="Vyhledávání - test Webshare")
        li_search_test.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search_test", listitem=li_search_test, isFolder=True)

    li_settings = xbmcgui.ListItem(label="Nastavení")
    li_settings.setArt({'icon': 'DefaultAddonService.png', 'thumb': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=open_settings", listitem=li_settings, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def add_dir(label, url, is_folder, icon=None, fanart=None, info=None, properties=None):
    li = xbmcgui.ListItem(label=label)
    art = {}
    if icon: art['icon'] = art['thumb'] = icon
    if fanart: art['fanart'] = fanart
    if art: li.setArt(art)
    if info:
        tag = li.getVideoInfoTag()
        for key, value in info.items():
            setter = getattr(tag, f"set{key.capitalize()}", None)
            if setter and value is not None:
                try:
                    setter(value)
                except: # Ignore errors for simplicity
                    pass
    if properties:
        for key, value in properties.items():
            li.setProperty(key, value)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)

if __name__ == "__main__":
    args = sys.argv[2]
    if args.startswith('?'):
        args = args[1:]
    router(args)
