# -*- coding: utf-8 -*-

FILLER_RANGES = {
    'naruto': (
        (26, 26),
        (97, 97),
        (101, 106),
        (136, 140),
        (143, 219),
    ),
    'shippuden': (
        (57, 71),
        (91, 112),
        (144, 151),
        (170, 171),
        (176, 196),
        (223, 242),
        (257, 260),
        (271, 271),
        (279, 281),
        (284, 295),
        (303, 320),
        (347, 361),
        (376, 377),
        (388, 390),
        (394, 413),
        (416, 417),
        (422, 423),
        (427, 450),
        (464, 468),
        (480, 483),
    ),
}

FILLER_EPISODES = {
    series_id: set(
        ep_num
        for start, end in ranges
        for ep_num in range(start, end + 1)
    )
    for series_id, ranges in FILLER_RANGES.items()
}


def is_filler_episode(series_id, ep_num):
    return ep_num in FILLER_EPISODES.get(series_id, set())


def visible_episode_numbers(series_id, total, skip_fillers):
    if not skip_fillers:
        return list(range(1, total + 1))

    fillers = FILLER_EPISODES.get(series_id, set())
    return [
        ep_num
        for ep_num in range(1, total + 1)
        if ep_num not in fillers
    ]


def is_visible_episode(series_id, ep_num, skip_fillers):
    return not skip_fillers or not is_filler_episode(series_id, ep_num)
