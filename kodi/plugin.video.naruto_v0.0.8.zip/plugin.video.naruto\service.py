# -*- coding: utf-8 -*-

import base64
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon

LIB_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from fillers import is_visible_episode
from progress import set_last_episode


ADDON_ID = 'plugin.video.naruto'
SIGNAL = ADDON_ID + '.SIGNAL'
NOTIFICATION_TIME = 30
SEND_WHEN_REMAINING = 45

SERIES = {
    'naruto': {
        'label': 'Naruto (2002-2007)',
        'folder': 'naruto',
        'torrent': 'naruto.torrent',
        'total': 220,
        'tvshow': 'Naruto',
        'season': 1,
    },
    'shippuden': {
        'label': 'Naruto Shippuden',
        'folder': 'shippuden',
        'torrent': 'naruto-shippuden.torrent',
        'total': 500,
        'tvshow': 'Naruto: Shippuden',
        'season': 1,
    },
}


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[plugin.video.naruto:upnext] %s' % message, level=level)


def addon_path():
    return xbmcaddon.Addon(ADDON_ID).getAddonInfo('path')


def load_json_file(series_folder, filename):
    path = os.path.join(addon_path(), 'resources', series_folder, filename)
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception as exc:
        log('Failed to load %s/%s: %s' % (series_folder, filename, exc), xbmc.LOGWARNING)
        return {}


def skip_fillers_enabled():
    addon = xbmcaddon.Addon(ADDON_ID)
    try:
        return addon.getSettingBool('skip_fillers')
    except AttributeError:
        return addon.getSetting('skip_fillers') == 'true'
    except Exception:
        return False


def get_series_id(tvshow):
    normalized = (tvshow or '').strip().lower()
    for series_id, cfg in SERIES.items():
        if normalized == cfg['tvshow'].lower() or normalized == cfg['label'].lower():
            return series_id
    return None


def current_episode_from_playing_file(player):
    try:
        playing_file = player.getPlayingFile()
    except Exception:
        return None, None

    try:
        parsed = urllib.parse.urlparse(playing_file)
        if parsed.scheme != 'plugin' or parsed.netloc != ADDON_ID:
            return None, None
        params = dict(urllib.parse.parse_qsl(parsed.query))
        series_id = params.get('series')
        ep_num = int(params.get('episode', '0'))
    except Exception:
        return None, None

    if series_id in SERIES and ep_num > 0:
        return series_id, ep_num
    return None, None


def episode_key(ep_num):
    return 'E%03d' % ep_num


def episode_number(key):
    try:
        return int(key[1:])
    except Exception:
        return None


def find_next_episode(series_id, ep_num, data_map, skip_fillers=False):
    cfg = SERIES[series_id]
    e2idx = data_map.get('e2idx', {})
    current_idx = e2idx.get(episode_key(ep_num))

    for next_ep in range(ep_num + 1, cfg['total'] + 1):
        if not is_visible_episode(series_id, next_ep, skip_fillers):
            continue

        next_key = episode_key(next_ep)
        if next_key not in e2idx:
            continue
        if current_idx is not None and e2idx.get(next_key) == current_idx:
            continue
        return next_ep
    return None


def make_elementum_url(series_id, ep_num, data_map):
    cfg = SERIES[series_id]
    key = episode_key(ep_num)
    e2idx = data_map.get('e2idx', {})
    e2oidx = data_map.get('e2oidx', e2idx)
    if key not in e2idx:
        return None

    torrent_path = os.path.join(addon_path(), 'resources', cfg['folder'], cfg['torrent'])
    if not os.path.exists(torrent_path):
        log('Torrent file missing: %s' % torrent_path, xbmc.LOGWARNING)
        return None

    torrent_uri = urllib.parse.quote_plus(torrent_path.replace('\\', '/'))
    return (
        'plugin://plugin.video.elementum/play'
        '?uri=%s&oindex=%s&doresume=false' % (torrent_uri, e2oidx.get(key, e2idx[key]))
    )


def make_plugin_play_url(series_id, ep_num, data_map):
    elementum_url = make_elementum_url(series_id, ep_num, data_map)
    if not elementum_url:
        return None

    return (
        'plugin://%s/?action=play&series=%s&episode=%d&uri=%s'
        % (ADDON_ID, series_id, ep_num, urllib.parse.quote_plus(elementum_url))
    )


def episode_payload(series_id, ep_num, metadata):
    cfg = SERIES[series_id]
    key = episode_key(ep_num)
    meta = metadata.get(key, {})
    title = meta.get('title') or ('Epizoda %03d' % ep_num)
    plot = meta.get('plot') or ''
    thumb = meta.get('thumb') or ''
    art = {}
    if thumb:
        art = {'thumb': thumb, 'icon': thumb, 'fanart': thumb}

    return {
        'episodeid': '%s-%s' % (series_id, key),
        'tvshowid': series_id,
        'title': title,
        'showtitle': cfg['tvshow'],
        'tvshowtitle': cfg['tvshow'],
        'season': cfg['season'],
        'episode': ep_num,
        'plot': plot,
        'art': art,
    }


def notify_upnext(payload):
    encoded = base64.b64encode(json.dumps(payload).encode('utf-8')).decode('ascii')
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'JSONRPC.NotifyAll',
        'params': {
            'sender': SIGNAL,
            'message': 'upnext_data',
            'data': [encoded],
        },
    }
    xbmc.executeJSONRPC(json.dumps(request))


class NarutoPlayer(xbmc.Player):
    def __init__(self):
        super(NarutoPlayer, self).__init__()
        self.state = None

    def onAVStarted(self):
        series_id, ep_num = current_episode_from_playing_file(self)

        if not series_id:
            try:
                info = self.getVideoInfoTag()
                series_id = get_series_id(info.getTVShowTitle())
                ep_num = int(info.getEpisode())
            except Exception:
                self.state = None
                return

        if not series_id or ep_num <= 0:
            self.state = None
            return

        try:
            set_last_episode(series_id, ep_num)
            log('Saved progress: %s E%03d' % (series_id, ep_num))
        except Exception as exc:
            log('Failed to save progress for %s E%03d: %s' % (series_id, ep_num, exc), xbmc.LOGWARNING)

        cfg = SERIES[series_id]
        data_map = load_json_file(cfg['folder'], 'map.json')
        metadata = load_json_file(cfg['folder'], 'metadata.json')
        next_ep = find_next_episode(
            series_id,
            ep_num,
            data_map,
            skip_fillers_enabled(),
        )
        if not next_ep:
            self.state = None
            return

        play_url = make_plugin_play_url(series_id, next_ep, data_map)
        if not play_url:
            self.state = None
            return

        self.state = {
            'sent': False,
            'series_id': series_id,
            'episode': ep_num,
            'next_episode': next_ep,
            'payload': {
                'current_episode': episode_payload(series_id, ep_num, metadata),
                'next_episode': episode_payload(series_id, next_ep, metadata),
                'play_url': play_url,
                'notification_time': NOTIFICATION_TIME,
            },
        }
        log('Prepared UpNext override: %s E%03d -> E%03d' % (series_id, ep_num, next_ep))

    def onPlayBackStopped(self):
        self.state = None

    def onPlayBackEnded(self):
        self.state = None


def run():
    log('Service started')
    monitor = xbmc.Monitor()
    player = NarutoPlayer()

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

        state = player.state
        if not state or state.get('sent'):
            continue

        try:
            if not player.isPlayingVideo():
                continue
            total = player.getTotalTime()
            current = player.getTime()
        except Exception:
            continue

        if total <= 0:
            continue

        remaining = total - current
        if remaining <= SEND_WHEN_REMAINING:
            notify_upnext(state['payload'])
            state['sent'] = True
            log(
                'Sent UpNext override for %s E%03d -> E%03d, remaining %.1fs'
                % (state['series_id'], state['episode'], state['next_episode'], remaining)
            )

    log('Service stopped')


if __name__ == '__main__':
    run()
