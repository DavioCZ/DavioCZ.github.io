# -*- coding: utf-8 -*-

import sys
import os
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import bencode

# Základní URL a handle pluginu
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])


def get_params():
    """
    Vrátí parametry pluginu jako slovník.
    """
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}

def list_seasons():
    """
    Zobrazí seznam sérií (1-34).
    """
    xbmcplugin.setPluginCategory(_HANDLE, "Série")
    for i in range(1, 35):
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i})
        url = f"{_URL}?action=list_episodes&season={i}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(_HANDLE)

def list_episodes(season):
    """
    Zobrazí seznam epizod pro danou sérii.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'simpsons.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        return

    with open(torrent_file_path, 'rb') as f:
        torrent_data = bencode.bdecode(f.read())
    
    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f[b'path']]
            files_in_torrent.append({'path': os.path.join(*path_parts), 'index': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'index': 0})

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")
    
    episode_items = []
    # Regex pro extrakci série a epizody (např. s01e01)
    episode_pattern = re.compile(r's(\d{2})e(\d{2})', re.IGNORECASE)
    
    for file_info in files_in_torrent:
        f_path = file_info['path']
        f_index = file_info['index']
        filename = os.path.basename(f_path)

        if not filename.lower().endswith('.mkv'):
            continue

        match = episode_pattern.search(filename)
        if match:
            file_season = int(match.group(1))
            episode_num = int(match.group(2))

            if file_season == int(season):
                list_item = xbmcgui.ListItem(label=filename)
                list_item.setInfo('video', {'title': filename, 'season': file_season, 'episode': episode_num})
                list_item.setProperty('IsPlayable', 'true')

                play_url = f"{_URL}?action=play_playlist&season={file_season}&episode={episode_num}"
                
                episode_items.append((episode_num, play_url, list_item))

    # Seřadíme epizody podle čísla a přidáme je do seznamu
    for ep_num, url, item in sorted(episode_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)

def play_playlist(season, start_episode):
    """
    Vytvoří playlist od zadané epizody a spustí přehrávání.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'simpsons.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        return

    with open(torrent_file_path, 'rb') as f:
        torrent_data = bencode.bdecode(f.read())

    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f[b'path']]
            files_in_torrent.append({'path': os.path.join(*path_parts), 'index': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'index': 0})

    episode_pattern = re.compile(r's(\d{2})e(\d{2})', re.IGNORECASE)
    
    all_episodes_in_season = []
    for file_info in files_in_torrent:
        f_path = file_info['path']
        f_index = file_info['index']
        filename = os.path.basename(f_path)

        if not filename.lower().endswith('.mkv'):
            continue

        match = episode_pattern.search(filename)
        if match:
            file_season = int(match.group(1))
            episode_num = int(match.group(2))

            if file_season == int(season):
                all_episodes_in_season.append({
                    'season': file_season,
                    'episode': episode_num,
                    'title': filename,
                    'oindex': f_index,
                    'torrent_path': torrent_file_path
                })

    # Seřadíme všechny epizody v sérii
    all_episodes_in_season.sort(key=lambda x: x['episode'])

    # Najdeme index startovací epizody
    start_index = -1
    for i, ep in enumerate(all_episodes_in_season):
        if ep['episode'] == int(start_episode):
            start_index = i
            break
    
    if start_index == -1:
        xbmcgui.Dialog().notification("Chyba", "Startovací epizoda nebyla nalezena.", xbmcgui.NOTIFICATION_ERROR)
        return

    # Vytvoříme playlist
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    # Přidáme startovací a následující epizody (max 10)
    for i in range(start_index, min(start_index + 10, len(all_episodes_in_season))):
        ep = all_episodes_in_season[i]
        
        torrent_uri_encoded = urllib.parse.quote_plus(f"file://{ep['torrent_path']}")
        title_encoded = urllib.parse.quote_plus(ep['title'])
        
        elementum_url = (f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&oindex={ep['oindex']}"
                         f"&title={title_encoded}&show=Simpsonovi&season={ep['season']}&episode={ep['episode']}&tmdbid=456")

        list_item = xbmcgui.ListItem(label=ep['title'])
        list_item.setInfo('video', {
            'title': ep['title'],
            'season': ep['season'],
            'episode': ep['episode'],
            'tvshowtitle': 'Simpsonovi'
        })
        list_item.setProperty('IsPlayable', 'true')
        
        playlist.add(url=elementum_url, listitem=list_item)

    xbmc.Player().play(playlist)


def router(paramstring):
    """
    Hlavní router pluginu.
    """
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if action == 'play_playlist':
        play_playlist(params['season'], params['episode'])
    elif action == 'list_episodes':
        list_episodes(params.get('season'))
    else:
        list_seasons()

if __name__ == '__main__':
    router(sys.argv[2])
