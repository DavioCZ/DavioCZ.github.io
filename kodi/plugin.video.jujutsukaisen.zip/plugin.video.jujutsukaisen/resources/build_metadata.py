# resources/build_metadata.py
# -*- coding: utf-8 -*-

import json
import os
import urllib.request
import urllib.parse
import time

# --- KONFIGURACE ---
SHOW_ID = "95479" 
SHOW_NAME = "Jujutsu Kaisen"
# Stahujeme jen "Sérii 1", protože API vrací vše v ní (Absolute ordering)
# Skript to pak sám rozdělí.
TMDB_API_KEY = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
# -------------------

def tmdb_get(endpoint, params=None):
    if params is None: params = {}
    params["api_key"] = TMDB_API_KEY
    url = f"{TMDB_BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        print(f"!!! Chyba HTTP {e.code} při stahování: {url}")
        return None
    except Exception as e:
        print(f"!!! Obecná chyba: {e}")
        return None

def build_metadata():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, "metadata.json")

    print(f"=== ZAČÁTEK STAHOVÁNÍ PRO: {SHOW_NAME} (ID: {SHOW_ID}) ===")
    metadata = {} 

    # Stahujeme primárně "Sérii 1", protože TMDB vrací Absolute Ordering (vše v S1)
    print(f"\nStahuji data (očekávám absolutní číslování)...")
    
    s_data = tmdb_get(f"/tv/{SHOW_ID}/season/1", {"language": "cs-CZ"})
    s_en_backup = None
    
    if not s_data:
        print("  -> Čeština nedostupná, zkouším angličtinu...")
        s_data = tmdb_get(f"/tv/{SHOW_ID}/season/1", {"language": "en-US"})
    else:
        # Záloha angličtiny pro chybějící popisky
        s_en_backup = tmdb_get(f"/tv/{SHOW_ID}/season/1", {"language": "en-US"})

    if not s_data:
        print("KRITICKÁ CHYBA: Žádná data.")
        return

    en_map = {}
    if s_en_backup and "episodes" in s_en_backup:
        en_map = {ep["episode_number"]: ep for ep in s_en_backup["episodes"]}
    elif s_data and "episodes" in s_data:
        en_map = {ep["episode_number"]: ep for ep in s_data["episodes"]}

    if "episodes" in s_data:
        ep_count = len(s_data['episodes'])
        print(f"  -> Staženo {ep_count} epizod.")
        print("  -> Provádím přečíslování (S01E25 -> S02E01)...")

        for ep in s_data["episodes"]:
            abs_ep_num = ep.get("episode_number") # Absolutní číslo (např. 25)
            
            # --- LOGIKA PŘEČÍSLOVÁNÍ PRO JUJUTSU KAISEN ---
            # Série 1 má 24 dílů.
            # Cokoliv nad 24 patří do Série 2.
            if abs_ep_num <= 24:
                final_season = 1
                final_ep = abs_ep_num
            else:
                final_season = 2
                final_ep = abs_ep_num - 24 # 25 -> 1, 26 -> 2, atd.
            
            key = f"S{final_season:02d}E{final_ep:02d}"
            
            # Zbytek je stejný (popisky, obrázky)
            ep_en = en_map.get(abs_ep_num, {})
            title = ep.get("name") or ep_en.get("name", f"Epizoda {final_ep}")
            plot = ep.get("overview")
            if not plot:
                plot = ep_en.get("overview", "Popis není k dispozici.")
            
            path = ep.get("still_path") or ep_en.get("still_path")
            thumb = f"https://image.tmdb.org/t/p/w500{path}" if path else ""

            metadata[key] = {"title": title, "plot": plot, "thumb": thumb}
            # Debug výpis pro kontrolu
            if final_ep == 1:
                print(f"     [DEBUG] Mapuji: Původní {abs_ep_num} -> Nové {key} ({title})")

    else:
        print(f"  -> Varování: Žádná data epizod!")

    # Uložení
    print(f"\nUkládám soubor: {output_file}")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    print("=== HOTOVO ===")

if __name__ == "__main__":
    build_metadata()