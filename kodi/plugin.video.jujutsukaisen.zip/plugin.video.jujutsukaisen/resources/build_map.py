# resources/build_map.py
# -*- coding: utf-8 -*-
import io, os, re, json
from collections import OrderedDict

# Regex:
# 1. (?i) - ignoruje velikost písmen
# 2. S(\d+)E(\d+) - klasika S01E01
# 3. SO(\d+)E(\d+) - chytá překlepy v názvech 2. série (SO2E01 - písmeno O místo nuly)
# 4. (\d+)x(\d+) - formát 1x01
SE_RE = re.compile(r'(?i)(?:S|SO)(\d{1,2})E(\d{1,2})|(\d{1,2})x(\d{1,2})')

def bdecode(data: bytes):
    s = io.BytesIO(data)
    def r(n=1):
        b = s.read(n)
        if not b: raise ValueError("Unexpected EOF")
        return b
    def p():
        x = s.read(1)
        if not x: return b""
        s.seek(-1, 1); return x
    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-': num += ch; ch = r(1)
            while ch != b'e':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad int")
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e': out.append(parse())
            r(1); return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                if not isinstance(k, (bytes, bytearray)): raise ValueError("Key must be bytes")
                d[bytes(k)] = parse()
            r(1); return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad strlen")
                ln += ch; ch = r(1)
            n = int(ln); return r(n)
        raise ValueError("Bad prefix: %r" % c)
    return parse()

def parse_filetree(node, prefix):
    files = []
    for name_b, sub in node.items():
        if name_b == b'':
            length = int(sub.get(b'length', 0)) if isinstance(sub, dict) else 0
            files.append(("/".join(prefix), length)); continue
        name = name_b.decode("utf-8", "ignore")
        if isinstance(sub, dict):
            if b'' in sub:
                meta = sub[b'']
                length = int(meta.get(b'length', 0)) if isinstance(meta, dict) else 0
                files.append(("/".join(prefix + [name]), length))
            children = {k: v for k, v in sub.items() if k != b''}
            if children:
                files += parse_filetree(children, prefix + [name])
    return files

def load_files(torrent_path):
    if not os.path.isfile(torrent_path):
        print(f"POZOR: Soubor {torrent_path} nebyl nalezen.")
        return []
        
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})
    files = []
    if b'files' in info:
        for f in info[b'files']:
            parts = [p.decode("utf-8", "ignore") for p in f.get(b'path', [])]
            files.append(("/".join(parts), int(f.get(b'length', 0))))
    elif b'name' in info and b'length' in info:
        files.append((info[b'name'].decode("utf-8", "ignore"), int(info[b'length'])))
    elif b'file tree' in info:
        root = info.get(b'name', b'').decode("utf-8", "ignore")
        files = parse_filetree(info[b'file tree'], [root] if root else [])
    
    # Filtrujeme video soubory
    return [(p, l) for p, l in files if p.lower().endswith(('.mkv', '.mp4', '.avi'))]

def parse_se(path):
    m = SE_RE.search(path.replace(" ", "")) # Odstraníme mezery pro snazší regex
    if not m: return None
    # Skupiny 1,2 jsou pro SxxExx/SOxxExx, 3,4 pro 1x01
    if m.group(1): return int(m.group(1)), int(m.group(2))
    return int(m.group(3)), int(m.group(4))

def build_map_for_season(files, season_filter):
    # Vytvoří mapu pouze pro soubory, které odpovídají dané sérii
    ep_map = {}
    count = 0
    for idx, (path, _) in enumerate(files):
        se = parse_se(path)
        if se:
            s, e = se
            # Uložíme pouze pokud sedí číslo série
            if s == season_filter:
                ep_map[f"S{s:02d}E{e:02d}"] = idx
                count += 1
    return ep_map, count

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Definice souborů
    t1_path = os.path.join(script_dir, "jujutsu_s1.torrent")
    t2_path = os.path.join(script_dir, "jujutsu_s2.torrent")
    json_path = os.path.join(script_dir, "map.json")

    print("Zpracovávám Sérii 1...")
    files_s1 = load_files(t1_path)
    map_s1, c1 = build_map_for_season(files_s1, 1)
    print(f" -> Nalezeno {c1} epizod pro S01.")

    print("Zpracovávám Sérii 2...")
    files_s2 = load_files(t2_path)
    map_s2, c2 = build_map_for_season(files_s2, 2)
    print(f" -> Nalezeno {c2} epizod pro S02.")

    # OPRAVA: Odstraněn operátor := pro lepší kompatibilitu
    full_map = {
        "1": map_s1,
        "2": map_s2
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(full_map, f, ensure_ascii=False, indent=2)

    print(f"Hotovo. Mapa uložena do {json_path}")

if __name__ == "__main__":
    main()