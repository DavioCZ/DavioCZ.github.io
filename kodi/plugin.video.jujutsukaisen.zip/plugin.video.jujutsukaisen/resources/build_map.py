# resources/build_map.py
# -*- coding: utf-8 -*-
import io, os, re, json
from collections import OrderedDict

# Regex
SE_RE = re.compile(r'(?i)(?:S|SO)(\d{1,2})E(\d{1,2})|(\d{1,2})x(\d{1,2})')

def bdecode(data: bytes):
    s = io.BytesIO(data)
    def r(n=1):
        b = s.read(n)
        if not b: raise ValueError("Unexpected EOF")
        return b
    def p():
        x = s.read(1)
        if not x: return b""
        s.seek(-1, 1); return x
    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-': num += ch; ch = r(1)
            while ch != b'e':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad int")
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e': out.append(parse())
            r(1); return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                if not isinstance(k, (bytes, bytearray)): raise ValueError("Key must be bytes")
                d[bytes(k)] = parse()
            r(1); return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad strlen")
                ln += ch; ch = r(1)
            n = int(ln); return r(n)
        raise ValueError("Bad prefix: %r" % c)
    return parse()

def parse_filetree(node, prefix):
    files = []
    for name_b, sub in node.items():
        if name_b == b'':
            length = int(sub.get(b'length', 0)) if isinstance(sub, dict) else 0
            files.append(("/".join(prefix), length)); continue
        name = name_b.decode("utf-8", "ignore")
        if isinstance(sub, dict):
            if b'' in sub:
                meta = sub[b'']
                length = int(meta.get(b'length', 0)) if isinstance(meta, dict) else 0
                files.append(("/".join(prefix + [name]), length))
            children = {k: v for k, v in sub.items() if k != b''}
            if children:
                files += parse_filetree(children, prefix + [name])
    return files

def load_files_with_indices(torrent_path):
    """
    Načte soubory a vrátí seznam tuplů: (cesta, délka, ORIGINAL_INDEX)
    Original index je klíčový pro Elementum.
    """
    if not os.path.isfile(torrent_path):
        print(f"POZOR: Soubor {torrent_path} nebyl nalezen.")
        return []
        
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})
    
    all_files = []
    
    # 1. Získat všechny soubory bez filtrování, abychom měli správné indexy
    if b'files' in info:
        for idx, f in enumerate(info[b'files']):
            parts = [p.decode("utf-8", "ignore") for p in f.get(b'path', [])]
            path = "/".join(parts)
            length = int(f.get(b'length', 0))
            all_files.append((path, length, idx)) # Ukládáme idx!
            
    elif b'name' in info and b'length' in info:
        # Jednosouborový torrent
        path = info[b'name'].decode("utf-8", "ignore")
        length = int(info[b'length'])
        all_files.append((path, length, 0))
        
    elif b'file tree' in info:
        # Experimentální podpora pro file tree, indexy mohou být složitější
        # Většina torrentů používá b'files'
        root = info.get(b'name', b'').decode("utf-8", "ignore")
        temp_files = parse_filetree(info[b'file tree'], [root] if root else [])
        for idx, (path, length) in enumerate(temp_files):
            all_files.append((path, length, idx))
    
    # 2. Vyfiltrovat jen video soubory, ale zachovat jejich původní index
    video_files = []
    for path, length, original_index in all_files:
        if path.lower().endswith(('.mkv', '.mp4', '.avi')):
            video_files.append((path, length, original_index))
            
    return video_files

def parse_se(path):
    m = SE_RE.search(path.replace(" ", "")) 
    if not m: return None
    if m.group(1): return int(m.group(1)), int(m.group(2))
    return int(m.group(3)), int(m.group(4))

def build_map_for_season(files_with_indices, season_filter):
    ep_map = {}
    count = 0
    # files_with_indices je seznam (cesta, delka, index)
    for path, _, original_index in files_with_indices:
        se = parse_se(path)
        if se:
            s, e = se
            if s == season_filter:
                # ZDE JE ZMĚNA: Ukládáme original_index, ne pořadí v cyklu
                ep_map[f"S{s:02d}E{e:02d}"] = original_index
                count += 1
    return ep_map, count

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    t1_path = os.path.join(script_dir, "jujutsu_s1.torrent")
    t2_path = os.path.join(script_dir, "jujutsu_s2.torrent")
    json_path = os.path.join(script_dir, "map.json")

    print("Zpracovávám Sérii 1...")
    files_s1 = load_files_with_indices(t1_path)
    map_s1, c1 = build_map_for_season(files_s1, 1)
    print(f" -> Nalezeno {c1} epizod pro S01.")

    print("Zpracovávám Sérii 2...")
    files_s2 = load_files_with_indices(t2_path)
    map_s2, c2 = build_map_for_season(files_s2, 2)
    print(f" -> Nalezeno {c2} epizod pro S02.")

    full_map = {
        "1": map_s1,
        "2": map_s2
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(full_map, f, ensure_ascii=False, indent=2)

    print(f"Hotovo. Mapa uložena do {json_path}")

if __name__ == "__main__":
    main()