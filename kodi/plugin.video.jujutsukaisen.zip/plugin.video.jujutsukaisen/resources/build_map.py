# resources/build_map.py
# -*- coding: utf-8 -*-
import io, os, re, json
from collections import OrderedDict

# Regex pro detekci S01E01, SO2E10, 1x01 atd.
SE_RE = re.compile(r'(?i)(?:S|SO)(\d{1,2})E(\d{1,2})|(\d{1,2})x(\d{1,2})')

def bdecode(data: bytes):
    s = io.BytesIO(data)
    def r(n=1):
        b = s.read(n)
        if not b: raise ValueError("Unexpected EOF")
        return b
    def p():
        x = s.read(1)
        if not x: return b""
        s.seek(-1, 1); return x
    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-': num += ch; ch = r(1)
            while ch != b'e':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad int")
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e': out.append(parse())
            r(1); return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                if not isinstance(k, (bytes, bytearray)): raise ValueError("Key must be bytes")
                d[bytes(k)] = parse()
            r(1); return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad strlen")
                ln += ch; ch = r(1)
            n = int(ln); return r(n)
        raise ValueError("Bad prefix: %r" % c)
    return parse()

def get_sorted_files_from_torrent(torrent_path):
    """
    Načte soubory, SEŘADÍ JE ABECEDNĚ a vrátí je se správnými indexy.
    Elementum soubory řadí, takže to musíme udělat taky.
    """
    if not os.path.isfile(torrent_path):
        print(f"!!! CHYBA: Soubor {torrent_path} neexistuje.")
        return []

    with open(torrent_path, 'rb') as f:
        try:
            meta = bdecode(f.read())
        except Exception as e:
            print(f"!!! CHYBA: Nelze dekódovat {torrent_path}: {e}")
            return []

    info = meta.get(b'info', {})
    files_list = []
    
    # 1. Načteme všechny soubory (zatím bez indexů)
    if b'files' in info:
        for f in info[b'files']:
            # Cesta je seznam bajtů
            path_parts = [p.decode('utf-8', 'ignore') for p in f.get(b'path', [])]
            filename = os.path.join(*path_parts)
            # Normalizujeme cestu (lomítka) pro správné řazení
            filename = filename.replace('\\', '/')
            files_list.append(filename)
    else:
        # Jednosouborový torrent
        name = info.get(b'name', b'unknown').decode('utf-8', 'ignore')
        files_list.append(name)
        
    # 2. SEŘADÍME JE PODLE ABECEDY (stejně jako Elementum)
    files_list.sort()
    
    # 3. Přiřadíme indexy podle seřazeného seznamu
    indexed_files = []
    for idx, filename in enumerate(files_list):
        indexed_files.append({
            'index': idx, # Toto je index v seřazeném poli
            'name': filename
        })

    return indexed_files

def parse_episode_info(filename):
    clean_name = filename.replace(" ", "")
    m = SE_RE.search(clean_name)
    if m:
        if m.group(1): 
            return int(m.group(1)), int(m.group(2))
        elif m.group(3):
            return int(m.group(3)), int(m.group(4))
    return None, None

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    torrents = {
        "1": os.path.join(script_dir, "jujutsu_s1.torrent"),
        "2": os.path.join(script_dir, "jujutsu_s2.torrent")
    }
    
    final_map = {"1": {}, "2": {}}

    print(f"{'TORRENT':<10} | {'INDEX':<5} | {'EPISODE':<10} | {'FILENAME'}")
    print("-" * 80)

    for season_id, t_path in torrents.items():
        # Získáváme SEŘAZENÉ soubory
        files = get_sorted_files_from_torrent(t_path)
        
        for f in files:
            if not f['name'].lower().endswith(('.mkv', '.mp4', '.avi')):
                continue

            s_num, e_num = parse_episode_info(f['name'])
            
            if s_num is not None:
                if int(season_id) == s_num:
                    key = f"S{s_num:02d}E{e_num:02d}"
                    final_map[season_id][key] = f['index']
                    print(f"Season {season_id:<3} | {f['index']:<5} | {key:<10} | {f['name']}")

    json_path = os.path.join(script_dir, "map.json")
    with open(json_path, "w", encoding="utf-8") as out:
        json.dump(final_map, out, ensure_ascii=False, indent=2)

    print("-" * 80)
    print(f"Mapa uložena do: {json_path}")
    print("SOUBORY BYLY SEŘAZENY ABECEDNĚ - TOHLE BY MĚLO ODPOVÍDAT ELEMENTUM.")

if __name__ == "__main__":
    main()