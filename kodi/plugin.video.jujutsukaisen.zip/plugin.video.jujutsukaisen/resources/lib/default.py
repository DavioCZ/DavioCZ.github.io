# -*- coding: utf-8 -*-

import sys
import os
import re
import urllib.parse
import json
import io
from collections import OrderedDict
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# --- BDECODE ---
def bdecode(data: bytes):
    s = io.BytesIO(data)
    def r(n=1):
        b = s.read(n)
        if not b: raise ValueError("Unexpected EOF")
        return b
    def p():
        x = s.read(1)
        if not x: return b""
        s.seek(-1, 1); return x
    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-': num += ch; ch = r(1)
            while ch != b'e':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad int")
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e': out.append(parse())
            r(1); return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                if not isinstance(k, (bytes, bytearray)): raise ValueError("Key must be bytes")
                d[bytes(k)] = parse()
            r(1); return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                if not (b'0' <= ch <= b'9'): raise ValueError("Bad strlen")
                ln += ch; ch = r(1)
            n = int(ln); return r(n)
        raise ValueError("Bad prefix: %r" % c)
    return parse()
# ----------------

_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}

def load_json_file(filename):
    try:
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        file_path = os.path.join(addon_path, 'resources', filename)
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"[jujutsu] Error loading {filename}: {e}", level=xbmc.LOGWARNING)
    return {}

def list_seasons():
    xbmcplugin.setPluginCategory(_HANDLE, "Jujutsu Kaisen")
    
    # 2 série
    for i in range(1, 3): 
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i, 'tvshowtitle': 'Jujutsu Kaisen'})
        url = f"{_URL}?action=list_episodes&season={i}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)

def get_torrent_path(season):
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    
    # Rozcestník pro torrent soubory
    if int(season) == 1:
        fname = 'jujutsu_s1.torrent'
    else:
        fname = 'jujutsu_s2.torrent'
        
    return os.path.join(addon_path, 'resources', fname)

def list_episodes(season):
    season = int(season)
    torrent_file_path = get_torrent_path(season)

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", f"Torrent pro S{season} nenalezen!", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    try:
        with open(torrent_file_path, 'rb') as f:
            torrent_data = bdecode(f.read())
    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", f"Nepodařilo se načíst torrent: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f.get(b'path', [])]
            if not path_parts: continue
            files_in_torrent.append({'path': os.path.join(*path_parts), 'oindex': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'oindex': 0})

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")

    # Načtení mapy
    full_map = load_json_file('map.json')
    current_season_map = full_map.get(str(season), {})
    metadata = load_json_file('metadata.json')
    
    # Regex pro názvy souborů (stejný jako v build_map)
    episode_pattern = re.compile(r'(?i)(?:S|SO)(\d{1,2})E(\d{1,2})|(\d{1,2})x(\d{1,2})')

    episode_items = []

    for file_info in files_in_torrent:
        f_path = file_info['path']
        oindex = file_info['oindex']
        filename = os.path.basename(f_path)

        # Video filtry
        if not filename.lower().endswith(('.mkv', '.mp4', '.avi')):
            continue

        match = episode_pattern.search(filename.replace(" ", ""))
        if not match:
            continue

        if match.group(1):
            file_season = int(match.group(1))
            episode_num = int(match.group(2))
        else:
            file_season = int(match.group(3))
            episode_num = int(match.group(4))

        if file_season != season:
            continue

        episode_key = f"S{file_season:02d}E{episode_num:02d}"
        
        mapped_index = current_season_map.get(episode_key, oindex)
        meta_data = metadata.get(episode_key, {})
        
        display_title = meta_data.get('title', f"{file_season}x{episode_num} - {filename}")
        display_plot = meta_data.get('plot', 'Popis není k dispozici.')
        display_thumb = meta_data.get('thumb', '')

        torrent_uri_encoded = urllib.parse.quote_plus(torrent_file_path)
        elementum_url = f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&index={mapped_index}"

        list_item = xbmcgui.ListItem(label=display_title)
        list_item.setInfo('video', {
            'title': display_title,
            'season': file_season,
            'episode': episode_num,
            'plot': display_plot,
            'tvshowtitle': 'Jujutsu Kaisen',
            'mediatype': 'episode'
        })
        
        if display_thumb:
            list_item.setArt({'thumb': display_thumb, 'icon': display_thumb, 'fanart': display_thumb})
            
        list_item.setProperty('IsPlayable', 'true')
        play_url = f"{_URL}?action=play&uri={elementum_url}"
        episode_items.append((episode_num, play_url, list_item))

    for ep_num, url, item in sorted(episode_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)

def play_item(uri):
    list_item = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)

def router(paramstring):
    if 'action=play' in paramstring:
        try:
            uri_part = paramstring.split('&uri=', 1)[1]
            play_item(uri_part)
        except IndexError: pass
    else:
        params = get_params()
        action = params.get('action')
        
        if action is None:
            list_seasons()
        elif action == 'list_episodes':
            list_episodes(params['season'])

if __name__ == '__main__':
    router(sys.argv[2])