# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Inicializace
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}

def load_json_file(filename):
    try:
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        file_path = os.path.join(addon_path, 'resources', filename)
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"[jujutsu] Chyba pri nacitani {filename}: {e}", level=xbmc.LOGWARNING)
    return {}

def list_seasons():
    xbmcplugin.setPluginCategory(_HANDLE, "Jujutsu Kaisen")
    
    # Máme 2 série (podle toho, že máme 2 torrenty)
    for i in range(1, 3): 
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i, 'tvshowtitle': 'Jujutsu Kaisen'})
        
        # Odkaz na funkci list_episodes
        url = f"{_URL}?action=list_episodes&season={i}"
        
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)

def get_torrent_path(season):
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    
    # Výběr správného souboru podle série
    if int(season) == 1:
        fname = 'jujutsu_s1.torrent'
    else:
        fname = 'jujutsu_s2.torrent'
        
    return os.path.join(addon_path, 'resources', fname)

def list_episodes(season):
    season_str = str(season)
    torrent_file_path = get_torrent_path(season)

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", f"Torrent pro S{season} nenalezen!", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")

    # 1. Načteme mapu a metadata
    full_map = load_json_file('map.json')
    season_map = full_map.get(season_str, {}) # Získáme jen část pro aktuální sérii ("1" nebo "2")
    metadata = load_json_file('metadata.json')

    if not season_map:
        xbmcgui.Dialog().notification("Chyba", "Mapa epizod je prázdná!", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    # 2. Seřadíme epizody podle klíče (S01E01, S01E02...)
    sorted_episodes = sorted(season_map.keys())

    # 3. Projdeme mapu a vytvoříme položky
    for episode_key in sorted_episodes:
        # Tady je to kouzlo: Bereme PŘESNĚ ten index, který vypočítal build_map.py
        file_index = season_map[episode_key]
        
        # Načtení informací z metadat (nebo fallback, pokud chybí)
        meta_data = metadata.get(episode_key, {})
        display_title = meta_data.get('title', episode_key)
        display_plot = meta_data.get('plot', 'Popis není k dispozici.')
        display_thumb = meta_data.get('thumb', '')

        # Parsování čísla epizody z klíče (např. "S01E05" -> 5) pro InfoTag
        try:
            ep_num = int(episode_key.lower().split('e')[-1])
        except:
            ep_num = 0

        # Příprava odkazu pro Elementum
        # Říkáme: "Přehraj tento torrent soubor a pusť soubor na indexu X"
        torrent_uri_encoded = urllib.parse.quote_plus(torrent_file_path)
        elementum_url = f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&index={file_index}"

        list_item = xbmcgui.ListItem(label=display_title)
        list_item.setInfo('video', {
            'title': display_title,
            'season': int(season),
            'episode': ep_num,
            'plot': display_plot,
            'tvshowtitle': 'Jujutsu Kaisen',
            'mediatype': 'episode'
        })
        
        if display_thumb:
            list_item.setArt({'thumb': display_thumb, 'icon': display_thumb, 'fanart': display_thumb})
            
        list_item.setProperty('IsPlayable', 'true')
        
        # Vytvoření akce "play"
        play_url = f"{_URL}?action=play&uri={elementum_url}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=play_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)

def play_item(uri):
    # Předáme URL přímo Elementu
    list_item = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)

def router(paramstring):
    if 'action=play' in paramstring:
        try:
            # Vytáhneme URI pro Elementum
            uri_part = paramstring.split('&uri=', 1)[1]
            play_item(uri_part)
        except IndexError: pass
    else:
        params = get_params()
        action = params.get('action')
        
        if action is None:
            list_seasons()
        elif action == 'list_episodes':
            list_episodes(params['season'])

if __name__ == '__main__':
    router(sys.argv[2])