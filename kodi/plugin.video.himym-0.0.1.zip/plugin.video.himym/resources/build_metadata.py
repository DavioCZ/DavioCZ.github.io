# resources/build_metadata.py
# -*- coding: utf-8 -*-

import json
import os
import urllib.request
import urllib.parse
import time

# --- KONFIGURACE ---
TMDB_API_KEY = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
SHOW_NAME = "How I Met Your Mother"
SEASONS_COUNT = 9
# -------------------

def tmdb_get(endpoint, params=None):
    """Pomocná funkce pro GET request na TMDB"""
    if params is None:
        params = {}
    params["api_key"] = TMDB_API_KEY
    
    url = f"{TMDB_BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    print(f"Stahuji: {url}")
    
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as response:
            data = response.read().decode('utf-8')
            return json.loads(data)
    except Exception as e:
        print(f"Chyba při stahování {url}: {e}")
        return None

def get_show_id(show_name):
    """Najde ID seriálu podle názvu"""
    params = {"query": show_name, "language": "cs-CZ"}
    data = tmdb_get("/search/tv", params)
    if data and data.get("results"):
        return data["results"][0]["id"]
    return None

def build_metadata():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, "metadata.json")

    print(f"Hledám ID pro seriál: {SHOW_NAME}...")
    show_id = get_show_id(SHOW_NAME)
    
    if not show_id:
        print("Seriál nenalezen!")
        return

    print(f"ID seriálu: {show_id}")
    
    metadata = {} # Struktura: {"S01E01": {title, plot, thumb}, ...}

    for season_num in range(1, SEASONS_COUNT + 1):
        print(f"Zpracovávám sérii {season_num}...")
        
        # Stáhneme data pro sérii v češtině (priorita)
        season_data_cs = tmdb_get(f"/tv/{show_id}/season/{season_num}", {"language": "cs-CZ"})
        # Stáhneme data pro sérii v angličtině (fallback)
        season_data_en = tmdb_get(f"/tv/{show_id}/season/{season_num}", {"language": "en-US"})
        
        if not season_data_cs:
            print(f" - Nepodařilo se stáhnout sérii {season_num}")
            continue

        # Přetvoříme EN data do slovníku pro snadný přístup podle čísla epizody
        en_episodes_map = {}
        if season_data_en and "episodes" in season_data_en:
            for ep in season_data_en["episodes"]:
                en_episodes_map[ep["episode_number"]] = ep

        # Zpracujeme epizody
        for ep_cs in season_data_cs.get("episodes", []):
            ep_num = ep_cs.get("episode_number")
            ep_key = f"S{season_num:02d}E{ep_num:02d}"
            
            # Získáme anglický ekvivalent pro fallback
            ep_en = en_episodes_map.get(ep_num, {})
            
            # --- LOGIKA DATA ---
            # Název: CS > EN > Původní
            title = ep_cs.get("name")
            if not title or title == f"Episode {ep_num}": # Někdy TMDB vrátí generický název
                title = ep_en.get("name", f"Epizoda {ep_num}")

            # Popis: CS > EN > Default hláška
            plot = ep_cs.get("overview")
            if not plot:
                plot = ep_en.get("overview", "Popis není k dispozici.")

            # Obrázek
            still_path = ep_cs.get("still_path")
            if not still_path:
                still_path = ep_en.get("still_path")
            
            thumb_url = ""
            if still_path:
                thumb_url = f"https://image.tmdb.org/t/p/w500{still_path}"

            # Uložíme do slovníku
            metadata[ep_key] = {
                "title": title,
                "plot": plot,
                "thumb": thumb_url
            }

        # Slušnost k API
        time.sleep(0.2)

    # Uložení do JSON
    print(f"Ukládám metadata do {output_file}...")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    
    print("Hotovo! Nyní spusť Kodi plugin.")

if __name__ == "__main__":
    build_metadata()