# -*- coding: utf-8 -*-

import sys
import os
import re
import urllib.parse
import json

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import bencode

# Základní URL a handle pluginu
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])


def get_params():
    """
    Vrátí parametry pluginu jako slovník.
    """
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def load_map():
    """
    Načte mapu z resources/map.json
    Očekává strukturu:
      {
        "o2e": { "0": 17, ... },
        "se2e": { "S01E01": 0, ... }
      }
    """
    try:
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        map_path = os.path.join(addon_path, 'resources', 'map.json')
        if os.path.exists(map_path):
            with open(map_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    data.setdefault("se2e", {})
                    data.setdefault("o2e", {})
                    return data
    except Exception as e:
        # ZMĚNA ZDE: logovací zpráva pro HIMYM
        xbmc.log(f"[himym] load_map() error: {e}", level=xbmc.LOGWARNING)
    return {"se2e": {}, "o2e": {}}


def list_seasons():
    """
    Zobrazí seznam sérií pro HIMYM.
    HIMYM má 9 sérií.
    """
    xbmcplugin.setPluginCategory(_HANDLE, "How I Met Your Mother")

    # Série pro HIMYM (1-9)
    for i in range(1, 10):  # Rozsah pro 9 sérií
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i, 'tvshowtitle': 'How I Met Your Mother'})
        url = f"{_URL}?action=list_episodes&season={i}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)

    # V HIMYM torrentu nejsou žádné filmy, takže nebudeme přidávat položku pro filmy.

    xbmcplugin.endOfDirectory(_HANDLE)


def get_torrent_files_info():
    """
    Pomocná funkce pro načtení a dekódování torrentu,
    aby se kód neopakoval ve více funkcích.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    # ZMĚNA ZDE: název torrentu na himym.torrent
    torrent_file_path = os.path.join(addon_path, 'resources', 'himym.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[himym] Torrent file not found: {torrent_file_path}", level=xbmc.LOGERROR)
        return None, None

    try:
        with open(torrent_file_path, 'rb') as f:
            torrent_data = bencode.bdecode(f.read())
    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", f"Nepodařilo se načíst torrent: {e}", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[himym] Failed to decode torrent: {e}", level=xbmc.LOGERROR)
        return None, None

    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f.get(b'path', [])]
            if not path_parts:
                continue
            files_in_torrent.append({'path': os.path.join(*path_parts), 'oindex': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'oindex': 0})
    else:
        xbmcgui.Dialog().notification("Chyba", "Torrent neobsahuje podporovanou strukturu (files/name).", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log("[himym] Torrent has unsupported structure.", level=xbmc.LOGERROR)
        return None, None

    return files_in_torrent, torrent_file_path


def list_episodes(season):
    """
    Zobrazí seznam epizod pro danou sérii.
    """
    files_in_torrent, torrent_file_path = get_torrent_files_info()
    if files_in_torrent is None:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")

    # Regex pro SxxExx (z tvého torrentu HIMYM)
    episode_pattern = re.compile(r'S(\d{1,2})E(\d{1,2})', re.IGNORECASE)

    emap = load_map()
    se2e = emap.get("se2e", {})

    episode_items = []

    for file_info in files_in_torrent:
        f_path = file_info['path']
        oindex = file_info['oindex']
        filename = os.path.basename(f_path)

        # ZMĚNA ZDE: jen video .mkv (pro HIMYM)
        if not filename.lower().endswith('.mkv'):
            continue
        
        # Ignorujeme soubory "folder.jpg", které se objevují v tvém torrentu
        if filename.lower() == "folder.jpg":
            continue

        match = episode_pattern.search(filename)
        if not match:
            # Přeskočí soubory, které neodpovídají vzoru epizody
            continue

        file_season = int(match.group(1))
        episode_num = int(match.group(2))

        if file_season != int(season):
            continue

        episode_key = f"S{file_season:02d}E{episode_num:02d}"
        mapped_index = se2e.get(episode_key, oindex)

        torrent_uri_encoded = urllib.parse.quote_plus(torrent_file_path)
        elementum_url = f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&index={mapped_index}"

        label = filename.replace('.1080p.WEB-DL.DD5.1.H.264.CZ-GHDC.mkv', '').replace('.mkve', '') # Zkrášlení názvu
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {
            'title': label,
            'season': file_season,
            'episode': episode_num,
            # ZMĚNA ZDE: tvshowtitle na 'How I Met Your Mother'
            'tvshowtitle': 'How I Met Your Mother'
        })
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{_URL}?action=play&uri={elementum_url}"
        episode_items.append((episode_num, play_url, list_item))

    for ep_num, url, item in sorted(episode_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)


# Funkce list_movies() a související akce v routeru NEBUDOU pro HIMYM potřeba.
# Jsem je odstranil, protože v torrentu nejsou žádné samostatné filmy.


def play_item(uri):
    """
    Vytvoří přehrávatelnou položku a předá ji Kodi k přehrání.
    """
    # ZMĚNA ZDE: logovací zpráva pro HIMYM
    xbmc.log(f"[himym] Attempting to play URI: {uri}", level=xbmc.LOGINFO)
    list_item = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)


def router(paramstring):
    """
    Hlavní router pluginu.
    """
    if 'action=play' in paramstring:
        try:
            uri_part = paramstring.split('&uri=', 1)[1]
            play_item(uri_part)
        except IndexError:
            # ZMĚNA ZDE: logovací zpráva pro HIMYM
            xbmc.log("[himym] Failed to parse URI for playback.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Chyba", "Nepodařilo se zpracovat URL pro přehrání.", xbmcgui.NOTIFICATION_ERROR)
    else:
        params = get_params()
        action = params.get('action')

        if action is None:
            list_seasons()
        elif action == 'list_episodes':
            list_episodes(params['season'])
        # Akce 'list_movies' není potřeba pro HIMYM.


if __name__ == '__main__':
    router(sys.argv[2])