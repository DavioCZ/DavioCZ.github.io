# resources/build_map.py
# -*- coding: utf-8 -*-
#
# Clarksonova farma – build_map.py
# Generuje map.json z clarkson_farm.torrent
#
# Soubory v torrentu:
#   S01/S01E01 - Práce s traktorem.mkv   -> S01E01
#   S03/Clarksons.Farm.S03E01.*.srt      -> přeskočeno (není video)
#
# Výstup map.json:
#   {
#     "e2idx": { "S01E01": 0, "S01E02": 1, ... }   <- klíč -> Elementum index
#     "idx2e": { "0": ["S01E01"], ... }             <- index -> klíč
#   }

import io, os, re, json, argparse
from collections import OrderedDict

# Regex pro SxxExx v názvu souboru (case-insensitive)
EPISODE_RE = re.compile(r'[Ss](\d{1,2})[Ee](\d{1,2})')

VIDEO_EXTS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv'}


# ---------------------------------------------------------------------------
# Minimalistický bdecoder
# ---------------------------------------------------------------------------
def bdecode(data: bytes):
    s = io.BytesIO(data)

    def r(n=1):
        b = s.read(n)
        if not b:
            raise ValueError("Unexpected EOF")
        return b

    def p():
        x = s.read(1)
        if not x:
            return b""
        s.seek(-1, 1)
        return x

    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-':
                num += ch; ch = r(1)
            while ch != b'e':
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e':
                out.append(parse())
            r(1)
            return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                d[bytes(k)] = parse()
            r(1)
            return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                ln += ch; ch = r(1)
            return r(int(ln))
        raise ValueError("Bad prefix: %r" % c)

    return parse()


def load_files(torrent_path):
    """Vrátí seznam (path, length) pro video soubory."""
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})
    files = []
    if b'files' in info:
        for f in info[b'files']:
            parts = [p.decode('utf-8', 'ignore') for p in f.get(b'path', [])]
            files.append(('/'.join(parts), int(f.get(b'length', 0))))
    elif b'name' in info and b'length' in info:
        files.append((info[b'name'].decode('utf-8', 'ignore'), int(info[b'length'])))
    else:
        raise ValueError("Nepodporovaná struktura torrentu.")
    # Vrátíme jen video soubory
    return [(p, l) for p, l in files
            if os.path.splitext(p)[1].lower() in VIDEO_EXTS]


def parse_episode(filename):
    """Ze jména souboru vrátí klíč 'SxxExx', nebo None."""
    m = EPISODE_RE.search(os.path.basename(filename))
    if m:
        s = int(m.group(1))
        e = int(m.group(2))
        return f"S{s:02d}E{e:02d}"
    return None


def build_map(files):
    """
    Vytvoří:
      e2idx  – "S01E01" -> Elementum file index (abecední pořadí všech souborů v torrentu)
      idx2e  – "0"      -> ["S01E01"]
    """
    # Elementum indexuje VŠECHNY soubory v torrentu abecedně (včetně .srt)
    # Proto musíme načíst kompletní seznam souborů pro správné indexy
    sorted_paths_all = None  # načteme zvlášť v main

    sorted_paths = sorted(p for p, _ in files)
    path2eidx = {p: i for i, p in enumerate(sorted_paths)}

    e2idx = {}
    idx2e = {}
    unmatched = []

    for path, _ in files:
        key = parse_episode(path)
        if key is None:
            unmatched.append(path)
            continue
        eidx = path2eidx[path]
        eidx_str = str(eidx)
        e2idx[key] = eidx
        idx2e[eidx_str] = [key]

    return e2idx, idx2e, unmatched


def build_map_full(torrent_path):
    """
    Sestaví mapu s Elementum indexy počítanými přes VŠECHNY soubory v torrentu
    (Elementum indexuje i .srt a ostatní soubory).
    """
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})

    all_files = []
    if b'files' in info:
        for f in info[b'files']:
            parts = [p.decode('utf-8', 'ignore') for p in f.get(b'path', [])]
            all_files.append('/'.join(parts))
    elif b'name' in info and b'length' in info:
        all_files.append(info[b'name'].decode('utf-8', 'ignore'))

    # Elementum řadí abecedně
    sorted_all = sorted(all_files)
    path2eidx = {p: i for i, p in enumerate(sorted_all)}

    e2idx = {}
    idx2e = {}
    unmatched = []

    for path in all_files:
        ext = os.path.splitext(path)[1].lower()
        if ext not in VIDEO_EXTS:
            continue
        key = parse_episode(path)
        if key is None:
            unmatched.append(path)
            continue
        eidx = path2eidx[path]
        eidx_str = str(eidx)
        e2idx[key] = eidx
        idx2e[eidx_str] = [key]

    return e2idx, idx2e, unmatched


def main():
    script_dir      = os.path.dirname(os.path.abspath(__file__))
    default_torrent = os.path.join(script_dir, 'clarkson_farm.torrent')
    default_json    = os.path.join(script_dir, 'map.json')

    ap = argparse.ArgumentParser(description='Clarksonova farma – generátor mapy epizod')
    ap.add_argument('--torrent', '-t', default=default_torrent)
    ap.add_argument('--out-json', default=default_json)
    args = ap.parse_args()

    if not os.path.isfile(args.torrent):
        print(f"Chybí soubor: {args.torrent}")
        raise SystemExit(2)

    print(f"Načítám torrent: {args.torrent}")
    e2idx, idx2e, unmatched = build_map_full(args.torrent)

    with open(args.out_json, 'w', encoding='utf-8') as f:
        json.dump({'e2idx': e2idx, 'idx2e': idx2e}, f, ensure_ascii=False, indent=2)

    print(f"Mapa vytvořena: {len(e2idx)} epizod -> {args.out_json}")
    print()
    print("Přehled epizod:")
    for key in sorted(e2idx.keys()):
        print(f"  {key} -> Elementum index {e2idx[key]}")

    if unmatched:
        print(f"\nBez matche ({len(unmatched)}):")
        for p in unmatched:
            print(f"  {p}")


if __name__ == '__main__':
    main()
