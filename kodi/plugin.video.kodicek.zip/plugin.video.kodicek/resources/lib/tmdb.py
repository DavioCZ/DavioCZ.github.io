# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-
import xbmcaddon
from resources.lib import playback_manager

ADDON = xbmcaddon.Addon()
TMDB_API_BASE_URL = "https://api.themoviedb.org/3/"
UI_LANG = "cs-CZ"

def _get_tmdb_api_key():
    return ADDON.getSetting("tmdb_api_key")

def _tmdb_api_request(endpoint, params=None, method='get'):
    api_key = _get_tmdb_api_key()
    if not api_key:
        xbmc.log("Kodíček (TMDB): TMDb API key is missing for request.", level=xbmc.LOGERROR)
        return None
    return playback_manager.tmdb_api_request(api_key, endpoint, params, method)

def search_tmdb(query, tmdb_get_func):
    """
    Searches TMDB using multi search, with language fallback and fuzzy alias.
    """
    langs = ["cs-CZ", "en-US"]
    
    for lang in langs:
        params = {"query": query, "language": lang}
        res = tmdb_get_func("/search/multi", params)
        if res and res.get("results"):
            return res["results"]
            
    alt_query = query.replace(" a ", " and ")
    if alt_query != query:
        return search_tmdb(alt_query, tmdb_get_func)
        
    return []

def get_show_details(tmdb_id: int):
    """ Získá detailní informace o seriálu z TMDb. """
    return _tmdb_api_request(f"/tv/{tmdb_id}", {'language': UI_LANG, 'append_to_response': 'images,credits'})

def get_season_episodes(tmdb_id: int, season_number: int):
    """ Získá seznam epizod pro danou sezónu seriálu z TMDb. """
    season_details = _tmdb_api_request(f"/tv/{tmdb_id}/season/{season_number}", {'language': UI_LANG, 'append_to_response': 'images'})
    return season_details.get('episodes', []) if season_details else []

def season_exists(tmdb_id: int, season_number: int):
    """ Zkontroluje, zda daná sezóna existuje pro seriál. """
    show_details = get_show_details(tmdb_id)
    if show_details and 'seasons' in show_details:
        for season in show_details['seasons']:
            if season.get('season_number') == season_number:
                return True
    return False

def image_url(path: str, size="w500"):
    """ Vrací plnou URL k obrázku z TMDb. """
    if path:
        return f"https://image.tmdb.org/t/p/{size}{path}"
    return ""

if __name__ == '__main__':
    # Example usage (requires a mock or real tmdb_get function)
    def mock_tmdb_get(endpoint, params):
        print(f"Mock TMDB GET: {endpoint} with params {params}")
        if params["query"] == "Test Show" and params["language"] == "cs-CZ":
            return {"results": [{"id": 1, "name": "Test Show CS", "media_type": "tv"}]}
        if params["query"] == "Test Show" and params["language"] == "en-US":
            return {"results": [{"id": 1, "name": "Test Show EN", "media_type": "tv"}]}
        if params["query"] == "NonExistent a Show" and params["language"] == "cs-CZ":
            return {"results": []}
        if params["query"] == "NonExistent a Show" and params["language"] == "en-US":
            return {"results": []}
        if params["query"] == "NonExistent and Show" and params["language"] == "cs-CZ":
            return {"results": [{"id": 2, "name": "NonExistent and Show CS (from alias)", "media_type": "movie"}]}
        return {"results": []}

    print("Searching for 'Test Show':")
    results = search_tmdb("Test Show", mock_tmdb_get)
    print(f"Results: {results}\n")

    print("Searching for 'NonExistent a Show' (will try alias):")
    results_alias = search_tmdb("NonExistent a Show", mock_tmdb_get)
    print(f"Results: {results_alias}\n")

    print("Searching for 'Only English Show' (mock needs to be adjusted to test this path):")
    # To test this, mock_tmdb_get should return empty for cs-CZ and results for en-US
    def mock_tmdb_get_en_fallback(endpoint, params):
        print(f"Mock TMDB GET (EN Fallback): {endpoint} with params {params}")
        if params["query"] == "Only English Show" and params["language"] == "cs-CZ":
            return {"results": []}
        if params["query"] == "Only English Show" and params["language"] == "en-US":
            return {"results": [{"id": 3, "name": "Only English Show EN", "media_type": "tv"}]}
        return {"results": []}
    results_en = search_tmdb("Only English Show", mock_tmdb_get_en_fallback)
    print(f"Results: {results_en}\n")
