# -*- coding: utf-8 -*-
from resources.lib import tmdb

def compute_next_episode(tmdb_id: int, season: int, episode: int):
    show = tmdb.get_show_details(tmdb_id)
    tvshowtitle = show.get('name') or show.get('original_name') or ""
    episodes = tmdb.get_season_episodes(tmdb_id, season) or []
    if episode < len(episodes):
        nxt = episodes[episode]  # index N+1
        return _meta(tvshowtitle, season, episode + 1, nxt)
    next_season = season + 1
    if tmdb.season_exists(tmdb_id, next_season):
        eps2 = tmdb.get_season_episodes(tmdb_id, next_season) or []
        if eps2:
            return _meta(tvshowtitle, next_season, 1, eps2[0])
    return None

def _meta(tvshowtitle, season, episode, tmdb_ep):
    title = tmdb_ep.get('name') or ""
    plot = tmdb_ep.get('overview') or ""
    duration = int(tmdb_ep.get('runtime') or 0) * 60
    art = {
        "thumb":  tmdb.image_url(tmdb_ep.get('still_path')),
        "poster": tmdb.image_url(tmdb_ep.get('poster_path') or tmdb_ep.get('show_poster')),
        "fanart": tmdb.image_url(tmdb_ep.get('backdrop_path') or tmdb_ep.get('show_backdrop')),
    }
    art = {k: v for k, v in art.items() if v}
    return {
        "tvshowtitle": tvshowtitle,
        "title": title,
        "season": int(season),
        "episode": int(episode),
        "plot": plot,
        "duration": duration,
        "art": art,
    }
