# service.py (root)
# -*- coding: utf-8 -*-
import json, base64, time, urllib.parse
import xbmc, xbmcaddon

ADDON      = xbmcaddon.Addon()
PLUGIN_ID  = ADDON.getAddonInfo('id')  # "plugin.video.kodicek"

def _notify_all(sender, message, data_list):
    payload = {
        "jsonrpc": "2.0",
        "method": "JSONRPC.NotifyAll",
        "params": {"sender": sender, "message": message, "data": data_list},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(payload))

def upnext_signal(next_info: dict):
    # UpNext očekává base64(JSON) v listu pod message=upnext_data
    data_b64 = base64.b64encode(json.dumps(next_info).encode("utf-8")).decode("ascii")
    _notify_all(sender=PLUGIN_ID + ".SIGNAL", message="upnext_data", data_list=[data_b64])
    xbmc.log("[Kodicek UpNext] sent upnext_data", xbmc.LOGINFO)

class UpNextHook(xbmc.Player):
    def onAVStarted(self):
        # Vezmi metadata z právě hraného itemu
        try:
            tag = self.getVideoInfoTag()
        except Exception:
            tag = None
        if not tag:
            return

        tvshow = (tag.getTVShowTitle() or "").strip()
        season = int(tag.getSeason() or 0)
        episode = int(tag.getEpisode() or 0)
        title   = (tag.getTitle() or "").strip()
        tmdb_id = int(tag.getUniqueID("tmdb") or 0)

        if not (tvshow and season > 0 and episode > 0 and tmdb_id > 0):
            return  # nemáme seriálové info, UpNext overlay nedává smysl

        # 1) Spočti next epizodu (máš v resources/lib/utils/next_finder.py)
        from resources.lib.utils.next_finder import compute_next_episode
        nxt = compute_next_episode(
            tmdb_id = tmdb_id,
            season  = season,
            episode = episode
        )
        if not nxt:
            return

        # 2) Připrav „co pustit“ při autoplay
        qs = urllib.parse.urlencode({
            "action": "play_episode",
            "tmdb_id": tmdb_id,
            "season_number": nxt["season"],
            "episode_number": nxt["episode"],
            "show_title": tvshow
        }, doseq=True, safe=":/")
        plugin_url = f"plugin://{PLUGIN_ID}/?{qs}"

        next_info = {
            "current_episode": {
                "tvshowtitle": tvshow,
                "title": title,
                "season": season,
                "episode": episode,
                "art": {}  # nemusíš, ale můžeš doplnit thumbs/poster/fanart
            },
            "next_episode": nxt,           # to, co vrací compute_next_episode (název, S/E, art, atd.)
            "play_info": {"plugin_url": plugin_url}  # jednoduché a blbuvzdorné
        }
        upnext_signal(next_info)

class UpNextMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        # UpNext nám po timeoutu overlaye vrací to, co jsme mu dali do play_info
        if sender == "upnextprovider.SIGNAL":
            try:
                payload = json.loads(base64.b64decode(json.loads(data)[0]).decode("utf-8"))
            except Exception:
                xbmc.log("[Kodicek UpNext] invalid upnext payload", xbmc.LOGERROR)
                return

            plugin_url = payload.get("plugin_url")
            if plugin_url:
                xbmc.log("[Kodicek UpNext] autoplay RunPlugin", xbmc.LOGINFO)
                xbmc.executebuiltin(f"RunPlugin({plugin_url})")

if __name__ == "__main__":
    player  = UpNextHook()
    monitor = UpNextMonitor()
    xbmc.log("[Kodicek UpNext] service started", xbmc.LOGINFO)
    try:
        while not monitor.abortRequested():
            monitor.waitForAbort(1)
    finally:
        xbmc.log("[Kodicek UpNext] service stopped", xbmc.LOGINFO)
