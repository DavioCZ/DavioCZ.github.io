# -*- coding: utf-8 -*-
#
# Love, Death & Robots - resources/build_metadata.py
# Stahne metadata epizod a serii z TMDB a ulozi je jako resources/metadata.json.

import argparse
import json
import os
import time
import urllib.parse
import urllib.request

TMDB_API_KEY = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_SHOW_ID = 86831
SEASONS = (1, 2, 3, 4)


def tmdb_get(endpoint, params=None):
    if params is None:
        params = {}
    params["api_key"] = TMDB_API_KEY
    url = "%s%s?%s" % (TMDB_BASE_URL, endpoint, urllib.parse.urlencode(params))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        print("Chyba %s: %s" % (endpoint, exc))
        return None


def image_url(path):
    if not path:
        return ""
    return "https://image.tmdb.org/t/p/w500%s" % path


def first_text(*values):
    for value in values:
        if value:
            return value
    return ""


def build_metadata(show_id):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, "metadata.json")

    show_cs = tmdb_get("/tv/%s" % show_id, {"language": "cs-CZ"})
    show_en = tmdb_get("/tv/%s" % show_id, {"language": "en-US"})
    if not show_cs and not show_en:
        raise SystemExit("Nepodarilo se nacist serial z TMDB.")

    metadata = {"_seasons": {}}

    for season_num in SEASONS:
        print("Sezona %s..." % season_num)
        s_cs = tmdb_get("/tv/%s/season/%s" % (show_id, season_num), {"language": "cs-CZ"})
        s_en = tmdb_get("/tv/%s/season/%s" % (show_id, season_num), {"language": "en-US"})
        time.sleep(0.25)

        if not s_cs and not s_en:
            print("  preskoceno")
            continue

        season_title = first_text(
            (s_cs or {}).get("name"),
            (s_en or {}).get("name"),
            "Série %s" % season_num,
        )
        season_plot = first_text((s_cs or {}).get("overview"), (s_en or {}).get("overview"))
        season_poster = image_url(first_text((s_cs or {}).get("poster_path"), (s_en or {}).get("poster_path")))

        metadata["_seasons"][str(season_num)] = {
            "title": season_title,
            "plot": season_plot,
            "thumb": season_poster,
        }

        en_map = {
            ep.get("episode_number"): ep
            for ep in (s_en or {}).get("episodes", [])
            if ep.get("episode_number") is not None
        }

        for ep_cs in (s_cs or {}).get("episodes", []):
            ep_num = ep_cs.get("episode_number")
            if ep_num is None:
                continue
            ep_en = en_map.get(ep_num, {})
            key = "S%02dE%02d" % (season_num, ep_num)
            title = first_text(ep_cs.get("name"), ep_en.get("name"), "Epizoda %s" % ep_num)
            plot = first_text(ep_cs.get("overview"), ep_en.get("overview"), "Popis neni k dispozici.")
            thumb = image_url(first_text(ep_cs.get("still_path"), ep_en.get("still_path")))

            metadata[key] = {
                "title": title,
                "plot": plot,
                "thumb": thumb,
            }

    with open(output_file, "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, ensure_ascii=False, indent=2)

    episode_count = len([key for key in metadata if key.startswith("S")])
    print("Ulozeno %s epizod -> %s" % (episode_count, output_file))


def main():
    global TMDB_API_KEY
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-key", default=TMDB_API_KEY)
    parser.add_argument("--show-id", type=int, default=TMDB_SHOW_ID)
    args = parser.parse_args()
    TMDB_API_KEY = args.api_key
    build_metadata(args.show_id)


if __name__ == "__main__":
    main()
