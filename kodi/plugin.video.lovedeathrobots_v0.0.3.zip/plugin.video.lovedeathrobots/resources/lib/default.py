# -*- coding: utf-8 -*-

import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

TVSHOW_TITLE = "Love, Death & Robots"
SEASONS = {
    "1": "season1.torrent",
    "2": "season2.torrent",
    "3": "season3.torrent",
    "4": "season4.torrent",
}


def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def addon_resource_path(*parts):
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo("path")
    return os.path.join(addon_path, "resources", *parts)


def load_json_file(filename):
    file_path = addon_resource_path(filename)
    try:
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as handle:
                return json.load(handle)
    except Exception as exc:
        xbmc.log(
            "[lovedeathrobots] Error loading %s: %s" % (filename, exc),
            level=xbmc.LOGWARNING,
        )
    return {}


def list_seasons():
    xbmcplugin.setPluginCategory(_HANDLE, TVSHOW_TITLE)
    xbmcplugin.setContent(_HANDLE, "tvshows")
    metadata = load_json_file("metadata.json")
    season_art = metadata.get("_seasons", {}) if isinstance(metadata, dict) else {}

    for season in sorted(SEASONS, key=int):
        meta = season_art.get(season, {})
        title = meta.get("title") or "Série %s" % season
        plot = meta.get("plot") or ""
        thumb = meta.get("thumb") or ""
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo(
            "video",
            {
                "title": title,
                "season": int(season),
                "plot": plot,
                "tvshowtitle": TVSHOW_TITLE,
                "mediatype": "season",
            },
        )
        if thumb:
            list_item.setArt({"thumb": thumb, "icon": thumb, "poster": thumb, "fanart": thumb})
        url = "%s?action=list_episodes&season=%s" % (_URL, season)
        xbmcplugin.addDirectoryItem(
            handle=_HANDLE,
            url=url,
            listitem=list_item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(_HANDLE)


def get_torrent_path(season):
    torrent_name = SEASONS.get(str(season))
    if not torrent_name:
        return None
    return addon_resource_path(torrent_name)


def episode_number(episode_key):
    try:
        return int(episode_key.split("E", 1)[1])
    except Exception:
        return 0


def list_episodes(season):
    season = str(season)
    torrent_file_path = get_torrent_path(season)

    if not torrent_file_path or not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification(
            "Chyba",
            "Torrent pro sérii %s nebyl nalezen." % season,
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    full_map = load_json_file("map.json")
    season_map = full_map.get(season, {})
    metadata = load_json_file("metadata.json")

    if not season_map:
        xbmcgui.Dialog().notification(
            "Chyba",
            "Mapa epizod pro sérii %s je prázdná." % season,
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, "Série %s" % season)
    xbmcplugin.setContent(_HANDLE, "episodes")
    torrent_uri = urllib.parse.quote_plus(torrent_file_path)

    for episode_key in sorted(season_map.keys()):
        ep_num = episode_number(episode_key)
        play_idx = season_map[episode_key]
        meta = metadata.get(episode_key, {})
        display_title = meta.get("title") or "%sx%02d" % (season, ep_num)
        display_plot = meta.get("plot") or "Popis není k dispozici."
        display_thumb = meta.get("thumb") or ""

        elementum_url = (
            "plugin://plugin.video.elementum/play"
            "?uri=%s&index=%s&doresume=false" % (torrent_uri, play_idx)
        )
        play_url = "%s?action=play&season=%s&episode=%s&uri=%s" % (
            _URL,
            season,
            ep_num,
            urllib.parse.quote_plus(elementum_url),
        )

        list_item = xbmcgui.ListItem(label=display_title)
        list_item.setInfo(
            "video",
            {
                "title": display_title,
                "season": int(season),
                "episode": ep_num,
                "plot": display_plot,
                "tvshowtitle": TVSHOW_TITLE,
                "mediatype": "episode",
            },
        )
        if display_thumb:
            list_item.setArt(
                {"thumb": display_thumb, "icon": display_thumb, "fanart": display_thumb}
            )
        list_item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            handle=_HANDLE,
            url=play_url,
            listitem=list_item,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(_HANDLE)


def play_item(uri, season=None, episode=None):
    list_item = xbmcgui.ListItem(path=uri)
    try:
        season_num = int(season)
        ep_num = int(episode)
    except Exception:
        season_num = None
        ep_num = None

    if season_num and ep_num:
        episode_key = "S%02dE%02d" % (season_num, ep_num)
        meta = load_json_file("metadata.json").get(episode_key, {})
        title = meta.get("title") or episode_key
        plot = meta.get("plot") or "Popis není k dispozici."
        list_item.setInfo(
            "video",
            {
                "title": title,
                "season": season_num,
                "episode": ep_num,
                "plot": plot,
                "tvshowtitle": TVSHOW_TITLE,
                "mediatype": "episode",
            },
        )
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)


def router():
    params = get_params()
    action = params.get("action")

    if action is None:
        list_seasons()
    elif action == "list_episodes":
        list_episodes(params.get("season", "1"))
    elif action == "play":
        play_item(params.get("uri", ""), params.get("season"), params.get("episode"))


if __name__ == "__main__":
    router()
