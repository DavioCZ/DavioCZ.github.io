# service.py (root)
# -*- coding: utf-8 -*-
import sys
import os
import json
import base64
import time
import uuid
import urllib.parse
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
_addon_path = ADDON.getAddonInfo('path')
if _addon_path not in sys.path:
    sys.path.insert(0, _addon_path)

from resources.lib.utils.logger import log
from resources.lib.core.resume_helper import KodicekPlayer

PLUGIN_ID = ADDON.getAddonInfo('id')  # plugin.video.kodicek
WINDOW = xbmcgui = None
try:
    import xbmcgui as _xbmcgui
    xbmcgui = _xbmcgui
    WINDOW = xbmcgui.Window(10000)
except Exception:
    WINDOW = None


def _state_key(name):
    return "{}.{}".format(PLUGIN_ID, name)


def _set_window_json(name, payload):
    if not WINDOW:
        return
    try:
        WINDOW.setProperty(_state_key(name), json.dumps(payload, ensure_ascii=False))
    except Exception as e:
        log.warning("upnext", "Nelze ulozit window property {}: {}", name, e)


def _get_window_json(name):
    if not WINDOW:
        return {}
    try:
        raw = WINDOW.getProperty(_state_key(name))
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def _clear_window_state(name):
    if not WINDOW:
        return
    try:
        WINDOW.clearProperty(_state_key(name))
    except Exception:
        pass


def _notify_all(sender, message, data_list):
    payload = {
        "jsonrpc": "2.0",
        "method": "JSONRPC.NotifyAll",
        "params": {"sender": sender, "message": message, "data": data_list},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(payload))


def upnext_signal(next_info):
    data_b64 = base64.b64encode(json.dumps(next_info).encode("utf-8")).decode("ascii")
    _notify_all(sender=PLUGIN_ID + ".SIGNAL", message="upnext_data", data_list=[data_b64])
    log.info("upnext", "sent upnext_data")


class UpNextHook(xbmc.Player):
    def onAVStarted(self):
        if ADDON.getSetting('auto_playback') != 'true':
            log.info("upnext", "Auto playback vypnuty, UpNext payload se negeneruje")
            return
        try:
            tag = self.getVideoInfoTag()
        except Exception:
            tag = None
        if not tag:
            return

        tvshow = (tag.getTVShowTitle() or "").strip()
        season = int(tag.getSeason() or 0)
        episode = int(tag.getEpisode() or 0)
        title = (tag.getTitle() or "").strip()
        tmdb_id = int(tag.getUniqueID("tmdb") or 0)

        log.info("upnext", "onAVStarted: show='{}' S{}E{} tmdb_id={} title='{}'",
                 tvshow, season, episode, tmdb_id, title)
        _set_window_json("playback_state", {
            "tmdb_id": tmdb_id,
            "season": season,
            "episode": episode,
            "title": title,
            "show_title": tvshow,
            "started_at": int(time.time()),
        })

        if not (tvshow and season > 0 and episode > 0 and tmdb_id > 0):
            log.info("upnext", "Chybi serialova metadata, UpNext preskocen")
            return

        from resources.lib.utils.next_finder import compute_next_episode
        nxt = compute_next_episode(tmdb_id=tmdb_id, season=season, episode=episode)
        if not nxt:
            log.info("upnext", "compute_next_episode vratil None pro S{}E{}", season, episode)
            return

        log.info("upnext", "Dalsi epizoda: S{}E{} '{}'", nxt['season'], nxt['episode'], nxt.get('title', ''))

        # Add episodeid so UpNext can distinguish current from next (avoids None==None early-exit)
        nxt["episodeid"] = "{}-{}x{}".format(tmdb_id, nxt["season"], nxt["episode"])
        session_id = str(uuid.uuid4())
        source_profile = ADDON.getSetting('manual_source_profile') or ''

        qs = urllib.parse.urlencode({
            "action": "play_episode",
            "tmdb_id": tmdb_id,
            "season_number": nxt["season"],
            "episode_number": nxt["episode"],
            "show_title": tvshow,
            "autoplay": "1",
            "autoplay_session_id": session_id,
            "source_profile": source_profile,
        }, doseq=True, safe=":/")
        plugin_url = "plugin://" + PLUGIN_ID + "/?" + qs
        log.info("upnext", "plugin_url pro UpNext: {}", plugin_url)
        _set_window_json("autoplay_session", {
            "session_id": session_id,
            "current_tmdb_id": tmdb_id,
            "current_season": season,
            "current_episode": episode,
            "next_tmdb_id": tmdb_id,
            "next_season": int(nxt["season"]),
            "next_episode": int(nxt["episode"]),
            "show_title": tvshow,
            "plugin_url": plugin_url,
            "handled": False,
            "created_at": int(time.time()),
        })

        next_info = {
            "current_episode": {
                "tvshowtitle": tvshow,
                "title": title,
                "season": season,
                "episode": episode,
                "episodeid": "{}-{}x{}".format(tmdb_id, season, episode),
                "tvshowid": tmdb_id,
                "art": {}
            },
            "next_episode": nxt,
            "play_info": {"plugin_url": plugin_url}
        }
        upnext_signal(next_info)


class UpNextMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        if "upnext" in sender.lower() or "upnext" in method.lower():
            log.debug("upnext", "onNotification: sender='{}' method='{}' data='{}'",
                      sender, method, (data or "")[:200])

        if sender == "upnextprovider.SIGNAL":
            if ADDON.getSetting('auto_playback') != 'true':
                log.info("upnext", "Auto playback vypnuty, callback ignorovan")
                return
            try:
                payload = json.loads(base64.b64decode(json.loads(data)[0]).decode("utf-8"))
            except Exception as e:
                log.error("upnext", "invalid upnext payload: {} | raw: {}", e, (data or "")[:200])
                return

            plugin_url = payload.get("plugin_url")
            session = _get_window_json("autoplay_session")
            playback = _get_window_json("playback_state")
            log.info("upnext", "UpNextMonitor callback: plugin_url='{}'", plugin_url)
            if not plugin_url:
                return
            if not session:
                log.warning("upnext", "Chybi autoplay session state, callback ignorovan")
                return
            if session.get("handled"):
                log.info("upnext", "Autoplay session {} uz byla obslouzena", session.get("session_id"))
                return
            if session.get("plugin_url") and plugin_url != session.get("plugin_url"):
                log.warning("upnext", "Callback plugin_url neodpovida session state, ignoruji")
                return
            if playback and int(playback.get("tmdb_id") or 0) == int(session.get("next_tmdb_id") or 0) \
               and int(playback.get("season") or 0) == int(session.get("next_season") or 0) \
               and int(playback.get("episode") or 0) == int(session.get("next_episode") or 0):
                log.info("upnext", "Cilova epizoda uz se prehrava, callback ignorovan")
                session["handled"] = True
                _set_window_json("autoplay_session", session)
                return
            session["handled"] = True
            session["handled_at"] = int(time.time())
            _set_window_json("autoplay_session", session)
            log.info("upnext", "autoplay RunPlugin: {}", plugin_url)
            xbmc.executebuiltin("RunPlugin(" + plugin_url + ")")


if __name__ == "__main__":
    player = UpNextHook()
    resume_player = KodicekPlayer()
    monitor = UpNextMonitor()
    log.info("upnext", "service started")
    try:
        while not monitor.abortRequested():
            resume_player.tick()
            monitor.waitForAbort(1)
    finally:
        log.info("upnext", "service stopped")
