# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
from xbmc import Player

# Manually add the addon's library to the Python path
lib_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

import requests
import hashlib
import time
import json
import re
from xml.etree import ElementTree as ET
from resources.lib.core.history import add_to_history, load_history, save_history, add_to_search_history, load_search_history
from resources.lib import tmdb as tmdb_lib
from resources.lib import playback_manager
from resources.lib.utils import md5crypt
from resources.lib.utils.logger import log
from resources.lib.utils.text_utils import normalize_for_matching

MOD = "main"  # module name for logging

def _ws_hash_pwd(raw_pwd: str, salt: str) -> str:
    """Webshare digest = SHA1(MD5_CRYPT(password, salt))."""
    md5c = md5crypt.md5crypt(raw_pwd.encode("utf-8"), salt.encode("utf-8"))
    return hashlib.sha1(md5c.encode("utf-8")).hexdigest()

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
BASE_URL_PLUGIN = sys.argv[0] 
plugin_name = "Kodíček"
WEBSHARE_API_BASE_URL = "https://webshare.cz/api/"
UI_LANG = "cs-CZ"

_session = requests.Session()
_session.headers.update({'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"})

YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")

def strip_year(title: str) -> str:
    if not title:
        return ""
    cleaned = YEAR_RE.sub("", title)
    return " ".join(cleaned.split())

def parse_size_to_bytes(size_str: str) -> int:
    if not isinstance(size_str, str):
        return 0
    size_str = size_str.strip().upper()
    multipliers = {'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4, 'B': 1}
    unit = 'B'
    for u in multipliers:
        if size_str.endswith(u):
            unit = u
            size_str = size_str.replace(u, '')
            break
    numeric_part_str = size_str.replace(',', '.').strip()
    try:
        numeric_value = float(numeric_part_str)
        return int(numeric_value * multipliers[unit])
    except (ValueError, KeyError):
        return 0

def get_credentials():
    token = addon.getSetting("ws_token")
    if token:
        return {"token": token}
    username = addon.getSetting("ws_username")
    password = addon.getSetting("ws_password")
    if not username or not password:
        error_message = addon.getLocalizedString(30101) or "Chybí přihlašovací údaje. Zkontrolujte nastavení."
        xbmcgui.Dialog().notification(plugin_name, error_message, xbmcgui.NOTIFICATION_ERROR)
        addon.openSettings()
        return None
    return {"username": username, "password": password}

def get_tmdb_api_key():
    tmdb_key = addon.getSetting("tmdb_api_key")
    if not tmdb_key:
        default_key = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
        addon.setSetting("tmdb_api_key", default_key)
        tmdb_key = default_key
        xbmcgui.Dialog().notification(plugin_name, "Byl nastaven výchozí TMDb API klíč.", xbmcgui.NOTIFICATION_INFO)
    if not tmdb_key:
        xbmcgui.Dialog().notification(plugin_name, "Chybí TMDb API klíč v nastavení!", xbmcgui.NOTIFICATION_ERROR)
        return None
    return tmdb_key

def login_webshare(username, password):
    salt_response_content = playback_manager.api_call('salt', {'username_or_email': username}, base_url=WEBSHARE_API_BASE_URL)
    if not salt_response_content:
        return None
    try:
        salt_xml = ET.fromstring(salt_response_content)
    except ET.ParseError as e:
        log.error(MOD, "Failed to parse salt XML: {}. Response: {}", e, salt_response_content)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Invalid salt response.", xbmcgui.NOTIFICATION_ERROR)
        return None
    if not playback_manager.is_xml_ok(salt_xml):
        xbmcgui.Dialog().notification(plugin_name, "Login error: Could not get salt.", xbmcgui.NOTIFICATION_ERROR)
        return None
    salt_node = salt_xml.find('salt')
    if salt_node is None or not salt_node.text:
        log.error(MOD, "Salt not found in XML response")
        xbmcgui.Dialog().notification(plugin_name, "Login error: Salt missing.", xbmcgui.NOTIFICATION_ERROR)
        return None
    salt = salt_node.text
    try:
        pwd_hash = _ws_hash_pwd(password, salt)
    except Exception as e:
        log.error(MOD, "Error during password hashing: {}", e)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Hashing failed.", xbmcgui.NOTIFICATION_ERROR)
        return None
    login_data = {'username_or_email': username, 'password': pwd_hash, 'keep_logged_in': '1'}
    login_response_content = playback_manager.api_call('login', login_data, base_url=WEBSHARE_API_BASE_URL)
    if not login_response_content:
        return None
    try:
        login_xml = ET.fromstring(login_response_content)
    except ET.ParseError as e:
        log.error(MOD, "Failed to parse login XML: {}. Response: {}", e, login_response_content)
        xbmcgui.Dialog().notification(plugin_name, "Login error: Invalid server response.", xbmcgui.NOTIFICATION_ERROR)
        return None
    if not playback_manager.is_xml_ok(login_xml):
        message = "Login failed. Check credentials or API status."
        msg_node = login_xml.find('message')
        if msg_node is not None and msg_node.text:
            message = msg_node.text
        xbmcgui.Dialog().notification(plugin_name, message, xbmcgui.NOTIFICATION_ERROR)
        return None
    token_node = login_xml.find('token')
    if token_node is not None and token_node.text:
        log.info(MOD, "Login successful")
        return token_node.text
    else:
        log.error(MOD, "Token not found in login response")
        xbmcgui.Dialog().notification(plugin_name, "Login error: Token missing.", xbmcgui.NOTIFICATION_ERROR)
        return None

def get_mimetype(filename):
    if '.' in filename:
        ext = filename.rsplit('.', 1)[1].lower()
        if ext == 'mp4': return 'video/mp4'
        elif ext == 'mkv': return 'video/x-matroska'
        elif ext == 'avi': return 'video/x-msvideo'
        elif ext == 'ts': return 'video/mp2t'
    return 'application/octet-stream'

def _tmdb_get_for_search_module(endpoint, params):
    api_key = get_tmdb_api_key()
    if not api_key:
        return {"results": []} 
    return playback_manager.tmdb_api_request(api_key, endpoint, params)

def get_banner_image_url(tmdb_item, size="w500"):
    if not tmdb_item: return None
    backdrop_path = tmdb_item.get('backdrop_path')
    if backdrop_path: return f"https://image.tmdb.org/t/p/{size}{backdrop_path}"
    poster_path = tmdb_item.get('poster_path')
    if poster_path: return f"https://image.tmdb.org/t/p/{size}{poster_path}"
    return None


def _is_autoplay_request(params):
    return params.get('autoplay') == '1'


def _should_autoplay_next_episode(params):
    return addon.getSetting('auto_playback') == 'true' and _is_autoplay_request(params)


def _should_autoplay_source(params):
    return addon.getSetting('autoplay_best_source') == 'true' and _is_autoplay_request(params)


def _window_state_key(name):
    return "{}.{}".format(addon.getAddonInfo('id'), name)


def _get_window_json_state(name):
    try:
        raw = xbmcgui.Window(10000).getProperty(_window_state_key(name))
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def _set_window_json_state(name, payload):
    try:
        xbmcgui.Window(10000).setProperty(_window_state_key(name), json.dumps(payload, ensure_ascii=False))
    except Exception as e:
        log.warning(MOD, "Nelze ulozit window state {}: {}", name, e)


def _clear_window_json_state(name):
    try:
        xbmcgui.Window(10000).clearProperty(_window_state_key(name))
    except Exception:
        pass


def _validate_autoplay_request(tmdb_id, season_number, episode_number, show_title, params):
    if not _should_autoplay_next_episode(params):
        return True
    session = _get_window_json_state("autoplay_session")
    playback = _get_window_json_state("playback_state")
    autoplay_session_id = str(params.get('autoplay_session_id') or '').strip()
    if not session:
        log.warning(MOD, "Autoplay request bez session state ignorovan pro tmdb_id={} S{}E{}", tmdb_id, season_number, episode_number)
        return False
    if autoplay_session_id and str(session.get('session_id') or '') != autoplay_session_id:
        log.warning(MOD, "Autoplay request ma jine session_id ({} != {}), ignorovan", autoplay_session_id, session.get('session_id'))
        return False
    if int(session.get('next_tmdb_id') or 0) != int(tmdb_id or 0) or \
       int(session.get('next_season') or 0) != int(season_number or 0) or \
       int(session.get('next_episode') or 0) != int(episode_number or 0):
        log.warning(MOD, "Autoplay request necili na pripravenou epizodu session state, ignorovan")
        return False
    if playback and int(playback.get('tmdb_id') or 0) == int(tmdb_id or 0) and \
       int(playback.get('season') or 0) == int(season_number or 0) and \
       int(playback.get('episode') or 0) == int(episode_number or 0):
        log.info(MOD, "Autoplay request cili na prave prehravanou epizodu '{}', ignorovan", show_title)
        return False
    session['last_consumed_request_at'] = int(time.time())
    _set_window_json_state("autoplay_session", session)
    return True


def _clean_source_profile(profile):
    if not isinstance(profile, dict):
        return {}
    cleaned = {}
    for key in ('lang_tag', 'dub_type', 'quality_tag', 'source_tag', 'codec_tag', 'container_tag', 'size_bucket'):
        value = str(profile.get(key) or '').strip()
        if value:
            cleaned[key] = value
    return cleaned


def _clean_source_fingerprint(fingerprint):
    if not isinstance(fingerprint, dict):
        return {}
    cleaned = {}
    for key in (
        'series_prefix',
        'episode_format',
        'container_tag',
        'quality_tag',
        'lang_tag',
        'source_tag',
        'codec_tag',
        'size_bucket',
        'has_original_title',
    ):
        value = fingerprint.get(key)
        if key == 'has_original_title':
            if value in (True, False):
                cleaned[key] = value
            continue
        value = str(value or '').strip()
        if value:
            cleaned[key] = value
    return cleaned


def _encode_source_profile(profile):
    cleaned = _clean_source_profile(profile)
    if not cleaned:
        return ''
    try:
        return urllib.parse.quote(json.dumps(cleaned, ensure_ascii=False), encoding='utf-8')
    except Exception as e:
        log.warning(MOD, "Nepodařilo se zakódovat source_profile: {}", e)
        return ''


def _decode_source_profile(profile_str):
    if not profile_str:
        return {}
    try:
        return _clean_source_profile(json.loads(urllib.parse.unquote(profile_str)))
    except Exception as e:
        log.warning(MOD, "Nepodařilo se dekódovat source_profile: {}", e)
        return {}


def _encode_source_fingerprint(fingerprint):
    cleaned = _clean_source_fingerprint(fingerprint)
    if not cleaned:
        return ''
    try:
        return urllib.parse.quote(json.dumps(cleaned, ensure_ascii=False), encoding='utf-8')
    except Exception as e:
        log.warning(MOD, "Nepodařilo se zakódovat source_fingerprint: {}", e)
        return ''


def _decode_source_fingerprint(fingerprint_str):
    if not fingerprint_str:
        return {}
    try:
        return _clean_source_fingerprint(json.loads(urllib.parse.unquote(fingerprint_str)))
    except Exception as e:
        log.warning(MOD, "Nepodařilo se dekódovat source_fingerprint: {}", e)
        return {}


def _set_active_source_profile(tmdb_id, show_title, profile, manual=False):
    cleaned = _clean_source_profile(profile)
    try:
        addon.setSetting('current_source_profile', json.dumps(cleaned, ensure_ascii=False) if cleaned else '')
        addon.setSetting('current_source_profile_tmdb_id', str(tmdb_id or ''))
        addon.setSetting('current_source_profile_show_title', str(show_title or ''))
        if manual:
            addon.setSetting('manual_source_profile', json.dumps(cleaned, ensure_ascii=False) if cleaned else '')
            addon.setSetting('manual_source_profile_tmdb_id', str(tmdb_id or ''))
            addon.setSetting('manual_source_profile_show_title', str(show_title or ''))
    except Exception as e:
        log.warning(MOD, "Nelze uložit current source profile: {}", e)


def _set_active_source_fingerprint(tmdb_id, show_title, fingerprint, manual=False):
    cleaned = _clean_source_fingerprint(fingerprint)
    try:
        addon.setSetting('current_source_fingerprint', json.dumps(cleaned, ensure_ascii=False) if cleaned else '')
        addon.setSetting('current_source_fingerprint_tmdb_id', str(tmdb_id or ''))
        addon.setSetting('current_source_fingerprint_show_title', str(show_title or ''))
        if manual:
            addon.setSetting('manual_source_fingerprint', json.dumps(cleaned, ensure_ascii=False) if cleaned else '')
            addon.setSetting('manual_source_fingerprint_tmdb_id', str(tmdb_id or ''))
            addon.setSetting('manual_source_fingerprint_show_title', str(show_title or ''))
    except Exception as e:
        log.warning(MOD, "Nelze uložit source fingerprint: {}", e)


def _get_active_source_profile(tmdb_id=None, show_title=None):
    try:
        profile_raw = addon.getSetting('current_source_profile')
        stored_tmdb_id = addon.getSetting('current_source_profile_tmdb_id')
        stored_show_title = addon.getSetting('current_source_profile_show_title')
    except Exception:
        return {}
    profile = _decode_source_profile(profile_raw)
    if not profile:
        return {}
    if tmdb_id and stored_tmdb_id and str(tmdb_id) == str(stored_tmdb_id):
        return profile
    if show_title and stored_show_title and str(show_title).strip().lower() == str(stored_show_title).strip().lower():
        return profile
    return {}


def _get_active_source_fingerprint(tmdb_id=None, show_title=None):
    try:
        fingerprint_raw = addon.getSetting('current_source_fingerprint')
        stored_tmdb_id = addon.getSetting('current_source_fingerprint_tmdb_id')
        stored_show_title = addon.getSetting('current_source_fingerprint_show_title')
    except Exception:
        return {}
    fingerprint = _decode_source_fingerprint(fingerprint_raw)
    if not fingerprint:
        return {}
    if tmdb_id and stored_tmdb_id and str(tmdb_id) == str(stored_tmdb_id):
        return fingerprint
    if show_title and stored_show_title and str(show_title).strip().lower() == str(stored_show_title).strip().lower():
        return fingerprint
    return {}


def _get_manual_source_profile(tmdb_id=None, show_title=None):
    try:
        profile_raw = addon.getSetting('manual_source_profile')
        stored_tmdb_id = addon.getSetting('manual_source_profile_tmdb_id')
        stored_show_title = addon.getSetting('manual_source_profile_show_title')
    except Exception:
        return {}
    profile = _decode_source_profile(profile_raw)
    if not profile:
        return {}
    if tmdb_id and stored_tmdb_id and str(tmdb_id) == str(stored_tmdb_id):
        return profile
    if show_title and stored_show_title and str(show_title).strip().lower() == str(stored_show_title).strip().lower():
        return profile
    return {}


def _get_manual_source_fingerprint(tmdb_id=None, show_title=None):
    try:
        fingerprint_raw = addon.getSetting('manual_source_fingerprint')
        stored_tmdb_id = addon.getSetting('manual_source_fingerprint_tmdb_id')
        stored_show_title = addon.getSetting('manual_source_fingerprint_show_title')
    except Exception:
        return {}
    fingerprint = _decode_source_fingerprint(fingerprint_raw)
    if not fingerprint:
        return {}
    if tmdb_id and stored_tmdb_id and str(tmdb_id) == str(stored_tmdb_id):
        return fingerprint
    if show_title and stored_show_title and str(show_title).strip().lower() == str(stored_show_title).strip().lower():
        return fingerprint
    return {}


def _source_profile_from_scored_item(scored_item):
    if not isinstance(scored_item, dict):
        return {}
    file_item = scored_item.get('file') or {}
    file_name = str(file_item.get('name') or '')
    _, ext = os.path.splitext(file_name)
    ext = ext.lower().lstrip('.')
    size_bytes = int(file_item.get('size') or 0)
    if size_bytes <= 350 * 1024 ** 2:
        size_bucket = "XS"
    elif size_bytes <= 800 * 1024 ** 2:
        size_bucket = "S"
    elif size_bytes <= 1600 * 1024 ** 2:
        size_bucket = "M"
    else:
        size_bucket = "L"
    return _clean_source_profile({
        'lang_tag': scored_item.get('lang_tag'),
        'dub_type': scored_item.get('dub_type'),
        'quality_tag': scored_item.get('quality_tag'),
        'source_tag': scored_item.get('source_tag'),
        'codec_tag': scored_item.get('codec_tag'),
        'container_tag': ext.upper() if ext else '',
        'size_bucket': size_bucket,
    })


def _source_fingerprint_from_name(file_name, scored_item=None):
    file_name = str(file_name or '')
    normalized = normalize_for_matching(file_name)
    _, ext = os.path.splitext(file_name)
    ext = ext.lower().lstrip('.')
    episode_format = ''
    match = re.search(r'\bs\d{1,2}e\d{1,2}\b', normalized)
    if match:
        episode_format = 'sxe'
    else:
        match = re.search(r'\b\d{1,2}x\d{1,2}\b', normalized)
        if match:
            episode_format = 'x'
    series_prefix = normalized
    if match:
        series_prefix = normalized[:match.start()]
    series_prefix = " ".join(series_prefix.split())
    if series_prefix:
        series_prefix = " ".join(series_prefix.split()[:4])
    size_bucket = ''
    quality_tag = ''
    lang_tag = ''
    source_tag = ''
    codec_tag = ''
    if isinstance(scored_item, dict):
        candidate_profile = _source_profile_from_scored_item(scored_item)
        size_bucket = candidate_profile.get('size_bucket', '')
        quality_tag = str(scored_item.get('quality_tag') or '')
        lang_tag = str(scored_item.get('lang_tag') or '')
        source_tag = str(scored_item.get('source_tag') or '')
        codec_tag = str(scored_item.get('codec_tag') or '')
    return _clean_source_fingerprint({
        'series_prefix': series_prefix,
        'episode_format': episode_format,
        'container_tag': ext.upper() if ext else '',
        'quality_tag': quality_tag,
        'lang_tag': lang_tag,
        'source_tag': source_tag,
        'codec_tag': codec_tag,
        'size_bucket': size_bucket,
        'has_original_title': '(' in file_name and ')' in file_name,
    })


def _source_profile_match_bonus(scored_item, preferred_profile):
    preferred = _clean_source_profile(preferred_profile)
    if not preferred:
        return 0.0
    bonus = 0.0
    if preferred.get('quality_tag') and preferred.get('quality_tag') == scored_item.get('quality_tag'):
        bonus += 3.0
    if preferred.get('lang_tag') and preferred.get('lang_tag') == scored_item.get('lang_tag'):
        bonus += 2.5
    if preferred.get('dub_type') and preferred.get('dub_type') == scored_item.get('dub_type'):
        bonus += 1.5
    if preferred.get('source_tag') and preferred.get('source_tag') == scored_item.get('source_tag'):
        bonus += 1.0
    if preferred.get('codec_tag') and preferred.get('codec_tag') == scored_item.get('codec_tag'):
        bonus += 0.5
    candidate_profile = _source_profile_from_scored_item(scored_item)
    if preferred.get('container_tag') and preferred.get('container_tag') == candidate_profile.get('container_tag'):
        bonus += 2.0
    if preferred.get('size_bucket') and preferred.get('size_bucket') == candidate_profile.get('size_bucket'):
        bonus += 2.0
    return bonus


def _source_fingerprint_match_bonus(scored_item, preferred_fingerprint):
    preferred = _clean_source_fingerprint(preferred_fingerprint)
    if not preferred:
        return 0.0
    file_item = scored_item.get('file') or {}
    candidate = _source_fingerprint_from_name(file_item.get('name', ''), scored_item)
    bonus = 0.0
    if preferred.get('series_prefix') and preferred.get('series_prefix') == candidate.get('series_prefix'):
        bonus += 8.0
    if preferred.get('episode_format') and preferred.get('episode_format') == candidate.get('episode_format'):
        bonus += 5.0
    if preferred.get('container_tag') and preferred.get('container_tag') == candidate.get('container_tag'):
        bonus += 4.0
    if preferred.get('has_original_title') in (True, False) and preferred.get('has_original_title') == candidate.get('has_original_title'):
        bonus += 1.5
    for key, weight in (
        ('quality_tag', 2.0),
        ('lang_tag', 1.5),
        ('source_tag', 1.0),
        ('codec_tag', 0.5),
        ('size_bucket', 1.5),
    ):
        if preferred.get(key) and preferred.get(key) == candidate.get(key):
            bonus += weight
    return bonus


def _apply_source_profile_preference(scored_items, preferred_profile, preferred_fingerprint=None):
    preferred = _clean_source_profile(preferred_profile)
    preferred_fingerprint = _clean_source_fingerprint(preferred_fingerprint)
    if not preferred and not preferred_fingerprint:
        return scored_items
    for item in scored_items:
        profile_bonus = _source_profile_match_bonus(item, preferred)
        fingerprint_bonus = _source_fingerprint_match_bonus(item, preferred_fingerprint)
        item['profile_bonus'] = profile_bonus
        item['fingerprint_bonus'] = fingerprint_bonus
        item['preferred_score'] = item.get('score', 0.0) + profile_bonus + fingerprint_bonus
    scored_items.sort(key=lambda x: (x.get('preferred_score', x.get('score', 0.0)), x.get('score', 0.0)), reverse=True)
    top_profile = _source_profile_from_scored_item(scored_items[0]) if scored_items else {}
    top_fingerprint = _source_fingerprint_from_name(scored_items[0]['file'].get('name', ''), scored_items[0]) if scored_items else {}
    log.info(MOD, "Source preference aktivni: profil={} fingerprint={} | nejlepsi po boostu: {:.1f} (+profil {:.1f} +nazev {:.1f}) {} | kandidat profil: {} | kandidat fingerprint: {}",
             preferred,
             preferred_fingerprint,
             scored_items[0].get('preferred_score', scored_items[0].get('score', 0.0)) if scored_items else 0.0,
             scored_items[0].get('profile_bonus', 0.0) if scored_items else 0.0,
             scored_items[0].get('fingerprint_bonus', 0.0) if scored_items else 0.0,
             scored_items[0]['file'].get('name', '') if scored_items else '',
             top_profile,
             top_fingerprint)
    return scored_items


def _next_autoplay_episode(tmdb_id, season_number, episode_number):
    try:
        from resources.lib.utils.next_finder import compute_next_episode
        return compute_next_episode(int(tmdb_id), int(season_number), int(episode_number))
    except Exception as e:
        log.warning(MOD, "Autoplay next episode lookup selhal pro tmdb_id={} S{}E{}: {}", tmdb_id, season_number, episode_number, e)
        return None


def _advance_autoplay_episode(tmdb_id, season_number, episode_number, show_title, show_year, autoplay_skips, reason):
    max_skips = 5
    if autoplay_skips >= max_skips:
        log.warning(MOD, "Autoplay skip limit dosažen po {} přeskočeních pro tmdb_id={} S{}E{} ({})", autoplay_skips, tmdb_id, season_number, episode_number, reason)
        xbmcgui.Dialog().notification(plugin_name, "Autoplay nenašel přehratelný další díl.", xbmcgui.NOTIFICATION_INFO, 6000)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return True
    next_ep = _next_autoplay_episode(tmdb_id, season_number, episode_number)
    if not next_ep:
        log.info(MOD, "Autoplay nenašel další epizodu po S{}E{} ({})", season_number, episode_number, reason)
        xbmcgui.Dialog().notification(plugin_name, "Další dostupná epizoda nebyla nalezena.", xbmcgui.NOTIFICATION_INFO, 6000)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return True
    next_season = int(next_ep.get('season'))
    next_episode = int(next_ep.get('episode'))
    next_title = (next_ep.get('title') or '').strip()
    log.info(MOD, "Autoplay přeskakuje z S{}E{} na S{}E{} ({})", season_number, episode_number, next_season, next_episode, reason)
    qs = urllib.parse.urlencode({
        'action': 'play_episode',
        'tmdb_id': tmdb_id,
        'season_number': next_season,
        'episode_number': next_episode,
        'show_title': show_title,
        'show_year': show_year,
        'episode_name_cs': next_title,
        'autoplay': '1',
        'autoplay_skips': str(int(autoplay_skips) + 1),
    }, doseq=True, safe=':/')
    xbmc.executebuiltin("RunPlugin(" + BASE_URL_PLUGIN + "?" + qs + ")")
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
    return True

def get_tmdb_details(api_key, tmdb_id, media_type='movie', language='cs-CZ'):
    if not tmdb_id:
        log.error(MOD, "TMDb ID is missing for get_tmdb_details")
        return None
    request_params = {'language': language, 'append_to_response': 'credits,images,videos,external_ids'}
    data = playback_manager.tmdb_api_request(api_key, f"/{media_type}/{tmdb_id}", request_params)
    if data:
        log.debug(MOD, "TMDb details fetched for ID: {}", tmdb_id)
    else:
        log.warning(MOD, "Failed to fetch TMDb details for ID: {}", tmdb_id)
    return data


def _add_tmdb_result_item(item):
    media_type = item.get('media_type')
    if not media_type or media_type not in ['movie', 'tv']:
        return
    tmdb_id = item.get('id')
    title = item.get('title') if media_type == 'movie' else item.get('name')
    overview = item.get('overview', '')
    release_date = item.get('release_date') if media_type == 'movie' else item.get('first_air_date')
    year = release_date[:4] if release_date and len(release_date) >= 4 else ""
    display_title = f"{title} ({year})" if year else title
    display_title = f"[{media_type.upper()}] {display_title}"

    li = xbmcgui.ListItem(label=display_title)
    info_tag = li.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(overview)
    info_tag.setMediaType(media_type)
    if year and year.isdigit():
        info_tag.setYear(int(year))
    if tmdb_id:
        info_tag.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb')
    if media_type == 'tv':
        info_tag.setTvShowTitle(title)

    art_data = {}
    thumb_url = get_banner_image_url(item, "w500")
    if thumb_url:
        art_data['thumb'] = art_data['poster'] = art_data['fanart'] = thumb_url
    li.setArt(art_data)
    li.setProperty('IsPlayable', 'false')
    if tmdb_id:
        similar_url = (
            f"{BASE_URL_PLUGIN}?action=show_similar&tmdb_id={tmdb_id}"
            f"&media_type={media_type}&title={urllib.parse.quote(str(title), encoding='utf-8')}"
        )
        li.addContextMenuItems([
            ("Podobné tituly", f"Container.Update({similar_url})"),
        ])

    if media_type == 'movie':
        action_url = (
            f"{BASE_URL_PLUGIN}?action=process_tmdb_selection&tmdb_id={tmdb_id}"
            f"&media_type=movie&title={urllib.parse.quote(title, encoding='utf-8')}&year={year}"
        )
    else:
        action_url = (
            f"{BASE_URL_PLUGIN}?action=show_seasons&tmdb_id={tmdb_id}"
            f"&show_title={urllib.parse.quote(title, encoding='utf-8')}"
        )
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=action_url, listitem=li, isFolder=True)


def display_related_titles(params):
    tmdb_id = params.get('tmdb_id')
    media_type = params.get('media_type')
    title = params.get('title', 'Podobné')
    if not tmdb_id or media_type not in ('movie', 'tv'):
        xbmcgui.Dialog().notification(plugin_name, "Chybí informace pro podobné tituly.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return
    related_items = tmdb_lib.get_related_titles(tmdb_id, media_type)
    if not related_items:
        xbmcgui.Dialog().notification(plugin_name, "Pro tento titul nebyly nalezeny podobné položky.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return
    xbmcplugin.setPluginCategory(addon_handle, f"Podobné: {title}")
    xbmcplugin.setContent(addon_handle, 'videos')
    for item in related_items:
        _add_tmdb_result_item(item)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

# ---- UpNext helpers ----
def _tmdb_art(tv_poster=None, season_poster=None, still_path=None):
    art = {}
    if still_path:
        art['thumb'] = art['icon'] = f"https://image.tmdb.org/t/p/w300{still_path}"
    if season_poster and 'thumb' not in art:
        art['thumb'] = f"https://image.tmdb.org/t/p/w500{season_poster}"
    if tv_poster:
        art['tvshow.poster'] = f"https://image.tmdb.org/t/p/w500{tv_poster}"
    return art

def _build_upnext_item(tmdb_id, show_title, info_ep, tv_poster=None, season_poster=None):
    return {
        "episodeid": info_ep.get("id") or f"{tmdb_id}-{info_ep.get('season_number')}x{info_ep.get('episode_number')}",
        "tvshowid": tmdb_id,
        "title": info_ep.get("name") or f"E{info_ep.get('episode_number')}",
        "art": _tmdb_art(tv_poster, season_poster, info_ep.get("still_path")),
        "season": info_ep.get("season_number"),
        "episode": info_ep.get("episode_number"),
        "showtitle": show_title,
        "plot": info_ep.get("overview", ""),
        "playcount": 0,
        "rating": info_ep.get("vote_average"),
        "firstaired": info_ep.get("air_date"),
        "runtime": (info_ep.get("runtime") or 0) * 60
    }

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    # --- SAFE DEFAULTS pro show_year ---
    show_year = None
    val = params.get('show_year')
    if val:
        try:
            show_year = int(val)
        except (ValueError, TypeError):
            show_year = None

    if show_year is None:
        try:
            # home window je 10000, tam si ukládej vlastnosti
            win = xbmcgui.Window(10000)
            y = win.getProperty(f'{addon.getAddonInfo("id")}.show_year')
            if y:
                show_year = int(y)
        except (ValueError, TypeError):
            show_year = None
    # --- Konec SAFE DEFAULTS pro show_year ---

    if action == "open_settings":
        addon.openSettings()
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return

    creds = get_credentials()
    if not creds:
        if action: xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    token = creds.get("token")
    if not token:
        token = addon.getSetting('token')

    if not token:
        username = creds.get("username")
        password = creds.get("password")
        token = login_webshare(username, password)
        if token:
            addon.setSetting('token', token)
            addon.setSetting('ws_token', token)
        else:
            if action: xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

    log.info(MOD, "Action='{}', token={}...", action or "menu", token[:8] if token else "NONE")

    # Verify token validity on play action (most critical)
    if action == 'play':
        token_valid, vip_status = playback_manager.verify_token(token)
        if not token_valid:
            log.warning(MOD, "Token neplatný ({}), zkouším re-login...", vip_status)
            username = addon.getSetting("ws_username")
            password = addon.getSetting("ws_password")
            if username and password:
                new_token = login_webshare(username, password)
                if new_token:
                    token = new_token
                    addon.setSetting('token', token)
                    addon.setSetting('ws_token', token)
                    playback_manager.clear_search_cache()
                    log.info(MOD, "Re-login úspěšný, nový token={}...", token[:8])
                else:
                    log.error(MOD, "Re-login selhal")
            else:
                log.error(MOD, "Nelze re-login: chybí username/password v nastavení")
        elif vip_status != '1' and vip_status != 'true':
            log.warning(MOD, "Účet NEMÁ VIP status (vip={}). Streamování nemusí fungovat!", vip_status)

    if action == "search":
        what_to_search = params.get("what") 
        ask_for_input = params.get("ask") == "1"

        if ask_for_input:
            search_term_from_dialog = xbmcgui.Dialog().input(f"{plugin_name} – Vyhledat film/seriál", type=xbmcgui.INPUT_ALPHANUM)
            if search_term_from_dialog:
                what_to_search = search_term_from_dialog
                add_to_search_history({"query": what_to_search, "timestamp": int(time.time())})
            else:
                what_to_search = None

        if what_to_search:
            tmdb_api_key = get_tmdb_api_key()
            tmdb_results_to_display = []

            if tmdb_api_key:
                query_text_for_tmdb = strip_year(what_to_search)
                tmdb_search_results = tmdb_lib.search_tmdb(query_text_for_tmdb, _tmdb_get_for_search_module)
                if tmdb_search_results:
                    tmdb_results_to_display.extend(tmdb_search_results)
            
            if tmdb_results_to_display:
                xbmcplugin.setPluginCategory(addon_handle, f"TMDb Výsledky pro: {what_to_search}")
                xbmcplugin.setContent(addon_handle, 'videos')
                for item in tmdb_results_to_display:
                    _add_tmdb_result_item(item)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
                return
            else: 
                log.info(MOD, "No results from TMDb, proceeding with Webshare search")
                query_for_webshare = strip_year(what_to_search)
                files = playback_manager.search_webshare(token, query_for_webshare)
                if not files:
                    xbmcgui.Dialog().notification(plugin_name, "Nic nebylo nalezeno na Webshare.", xbmcgui.NOTIFICATION_INFO)
                else:
                    xbmcplugin.setPluginCategory(addon_handle, f"Výsledky pro: {what_to_search}")
                    xbmcplugin.setContent(addon_handle, 'videos')
                    for file_item in files:
                        li = xbmcgui.ListItem(label=file_item["name"])
                        size_bytes = file_item.get("size", 0)
                        size_str = f"{size_bytes/(1024*1024*1024):.2f} GB" if size_bytes > 1024*1024*1024 else f"{size_bytes/(1024*1024):.2f} MB"
                        
                        # Používáme InfoTagVideo
                        info_tag = li.getVideoInfoTag()
                        info_tag.setTitle(file_item["name"])
                        li.setProperty('filesize', str(size_bytes)) # Volitelně pro UI/debug
                        info_tag.setPlot(f"Velikost: {size_str}")
                        info_tag.setMediaType('video') # Obecný typ pro soubory z Webshare

                        li.setProperty('IsPlayable', 'true')
                        url = f"{BASE_URL_PLUGIN}?action=play&ident={file_item['ident']}&name={urllib.parse.quote(file_item['name'], encoding='utf-8')}"
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

        else: 
            xbmcplugin.setPluginCategory(addon_handle, "Vyhledávání")
            li_new_search = xbmcgui.ListItem(label="Nové vyhledávání...")
            li_new_search.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search&ask=1", listitem=li_new_search, isFolder=True)
            search_history_items = load_search_history()
            if search_history_items:
                for item in search_history_items:
                    query_text = item.get("query")
                    if query_text:
                        timestamp_str = time.strftime('%d.%m.%y %H:%M', time.localtime(item['timestamp']))
                        li = xbmcgui.ListItem(label=f"Hledáno: {query_text} ({timestamp_str})")
                        # Používáme InfoTagVideo
                        info_tag = li.getVideoInfoTag()
                        info_tag.setTitle(f"Hledáno: {query_text}")
                        info_tag.setPlot(f"Naposledy hledáno: {timestamp_str}")
                        info_tag.setMediaType('video') # Obecný typ
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search&what={urllib.parse.quote(query_text, encoding='utf-8')}", listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

    elif action == 'play':
        # Nacteme parametry potrebne pro prehrani aktualni polozky
        ident = params.get('ident')
        file_name_for_playback = params.get('name')  # muze byt None, nevadi

        tmdb_id = params.get('tmdb_id')
        media_type = params.get('media_type')
        season_number = params.get('season_number')
        episode_number = params.get('episode_number')
        show_title = params.get('show_title')
        episode_title = params.get('episode_title')
        episode_plot = params.get('episode_plot')
        episode_duration = params.get('episode_duration')
        episode_art_str = params.get('episode_art')
        playback_title = params.get('playback_title')
        playback_plot = params.get('playback_plot')
        playback_art_str = params.get('playback_art')
        playback_year = params.get('playback_year')
        source_profile_str = params.get('source_profile')
        source_profile = _decode_source_profile(source_profile_str)
        source_fingerprint_str = params.get('source_fingerprint')
        source_fingerprint = _decode_source_fingerprint(source_fingerprint_str)
        try:
            resume_time = int(float(params.get('resume_time') or 0))
        except Exception:
            resume_time = 0
        if not ident:
            xbmcgui.Dialog().notification(plugin_name, 'Chybi ident souboru.', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        stream_url = playback_manager.get_stream_link(token, ident)
        if not stream_url and playback_manager.is_temporarily_unavailable_error():
            xbmcgui.Dialog().notification(plugin_name, 'Zdroj je na Webshare docasne nedostupny. Zkuste jiny zdroj nebo to opakujte pozdeji.', xbmcgui.NOTIFICATION_INFO, 8000)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        if not stream_url and playback_manager.is_timeout_stream_error():
            xbmcgui.Dialog().notification(plugin_name, 'Webshare neodpovedel vcas. Zkuste prehrani znovu za chvili.', xbmcgui.NOTIFICATION_INFO, 8000)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        # If stream link failed, try re-login with fresh token and retry once
        if not stream_url:
            log.warning(MOD, "Stream link selhal, zkouším re-login a retry...")
            username = addon.getSetting("ws_username")
            password = addon.getSetting("ws_password")
            if username and password:
                new_token = login_webshare(username, password)
                if new_token:
                    token = new_token
                    addon.setSetting('token', token)
                    addon.setSetting('ws_token', token)
                    playback_manager.clear_search_cache()
                    log.info(MOD, "Re-login úspěšný, retry get_stream_link")
                    stream_url = playback_manager.get_stream_link(token, ident)
                else:
                    log.error(MOD, "Re-login selhal")
            else:
                log.warning(MOD, "Username/password nejsou v nastavení, nelze re-login")

        if not stream_url:
            xbmcgui.Dialog().notification(plugin_name, 'Nepodařilo se získat odkaz. Zkontrolujte přihlášení.', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        try:
            episode_duration_secs = int(float(episode_duration or 0))
        except Exception:
            episode_duration_secs = 0

        headers_str = urllib.parse.urlencode({
            'User-Agent': _session.headers.get('User-Agent', 'Mozilla/5.0'),
            'Cookie': f'wst={token}'
        })
        path_with_headers = f'{stream_url}|{headers_str}'
        li = xbmcgui.ListItem(path=path_with_headers)

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(episode_title or file_name_for_playback or 'Prehravany soubor')
        if tmdb_id and season_number and episode_number:
            info_tag.setMediaType('episode')
            if show_title:
                info_tag.setTvShowTitle(show_title)
            try:
                info_tag.setSeason(int(season_number))
                info_tag.setEpisode(int(episode_number))
            except Exception:
                pass
            if episode_plot:
                info_tag.setPlot(episode_plot)
            if episode_duration_secs:
                try:
                    info_tag.setDuration(episode_duration_secs)
                except Exception:
                    pass
                try:
                    info_tag.setResumePoint(0, episode_duration_secs)
                except Exception:
                    pass
            info_tag.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb')
        elif media_type == 'movie' and tmdb_id:
            info_tag.setMediaType('movie')
            info_tag.setTitle(playback_title or file_name_for_playback or 'Prehravany soubor')
            if playback_plot:
                info_tag.setPlot(playback_plot)
            if playback_year:
                try:
                    info_tag.setYear(int(playback_year))
                except Exception:
                    pass
            info_tag.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb')
        else:
            info_tag.setMediaType('video')
        if resume_time > 0:
            total_time = max(episode_duration_secs, resume_time + 1)
            try:
                info_tag.setResumePoint(float(resume_time), float(total_time))
            except Exception:
                pass
            li.setProperty('ResumeTime', str(resume_time))
            li.setProperty('StartOffset', str(resume_time))
            li.setProperty('TotalTime', str(total_time))

        if episode_art_str:
            try:
                episode_art = json.loads(urllib.parse.unquote(episode_art_str))
                li.setArt(episode_art)
            except (json.JSONDecodeError, TypeError):
                log.warning(MOD, "Failed to parse episode_art: {}", episode_art_str)
        elif playback_art_str:
            try:
                playback_art = json.loads(urllib.parse.unquote(playback_art_str))
                li.setArt(playback_art)
            except (json.JSONDecodeError, TypeError):
                log.warning(MOD, "Failed to parse playback_art: {}", playback_art_str)

        li.setProperty('IsPlayable', 'true')
        li.setMimeType(get_mimetype(file_name_for_playback or ''))

        xbmcplugin.setResolvedUrl(addon_handle, True, li)

        # Zapiš do historie přehrávání
        history_item = {
            'ident': ident,
            'name': episode_title or playback_title or file_name_for_playback or ident,
            'type': 'video',
            'timestamp': int(time.time()),
        }
        if show_title:
            history_item['show_title'] = show_title
        if tmdb_id:
            history_item['tmdb_id'] = tmdb_id
        if episode_art_str:
            try:
                history_art = json.loads(urllib.parse.unquote(episode_art_str))
                if history_art.get('thumb'):
                    history_item['thumb'] = history_art['thumb']
                if history_art.get('poster'):
                    history_item['poster'] = history_art['poster']
                if history_art.get('fanart'):
                    history_item['fanart'] = history_art['fanart']
            except (json.JSONDecodeError, TypeError):
                pass
        elif playback_art_str:
            try:
                history_art = json.loads(urllib.parse.unquote(playback_art_str))
                if history_art.get('thumb'):
                    history_item['thumb'] = history_art['thumb']
                if history_art.get('poster'):
                    history_item['poster'] = history_art['poster']
                if history_art.get('fanart'):
                    history_item['fanart'] = history_art['fanart']
            except (json.JSONDecodeError, TypeError):
                pass
        if season_number:
            try:
                history_item['season'] = int(season_number)
            except (ValueError, TypeError):
                pass
        if episode_number:
            try:
                history_item['episode'] = int(episode_number)
            except (ValueError, TypeError):
                pass
        if episode_duration_secs:
            history_item['duration_seconds'] = episode_duration_secs
        if source_profile:
            history_item['source_profile'] = source_profile
        if not source_fingerprint and file_name_for_playback:
            source_fingerprint = _source_fingerprint_from_name(file_name_for_playback)
        if source_fingerprint:
            history_item['source_fingerprint'] = source_fingerprint
        add_to_history(history_item)
        log.info(MOD, "Přidáno do historie: ident={}, name='{}'", ident, history_item['name'])
        if show_title or tmdb_id:
            manual_selection = bool(source_profile or source_fingerprint)
            _set_active_source_profile(tmdb_id, show_title, source_profile, manual=manual_selection)
            _set_active_source_fingerprint(tmdb_id, show_title, source_fingerprint, manual=manual_selection)
        if tmdb_id and season_number and episode_number:
            try:
                _set_window_json_state("playback_state", {
                    "tmdb_id": int(tmdb_id),
                    "season": int(season_number),
                    "episode": int(episode_number),
                    "title": episode_title or history_item['name'],
                    "show_title": show_title,
                    "started_at": int(time.time()),
                })
            except Exception:
                pass
        _clear_window_json_state("autoplay_session")

        # Ulož ident pro resume tracking v service.py (KodicekPlayer)
        try:
            addon.setSetting('current_playing_ident', ident)
        except Exception as _e:
            log.warning(MOD, "Nelze uložit current_playing_ident: {}", _e)

    elif action == "history":
        history_items = load_history()
        if not history_items:
            xbmcgui.Dialog().notification(plugin_name, "Historie přehrávání je prázdná.", xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
            return
        xbmcplugin.setPluginCategory(addon_handle, "Historie přehrávání")
        xbmcplugin.setContent(addon_handle, 'videos')
        for item in history_items:
            if not item.get("ident") or not item.get("name") or item.get("type") != "video": continue
            li = xbmcgui.ListItem(label=item["name"])
            timestamp_str = time.strftime('%d.%m.%Y %H:%M', time.localtime(item['timestamp']))
            
            # Používáme InfoTagVideo
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item["name"])
            info_tag.setPlot(f"Naposledy přehráno: {timestamp_str}")
            info_tag.setMediaType('video') # Obecný typ
            
            li.setProperty('IsPlayable', 'true')
            url = f"{BASE_URL_PLUGIN}?action=play&ident={item['ident']}&name={urllib.parse.quote(item['name'], encoding='utf-8')}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)

    elif action == "show_combined_history":
        display_combined_history()
    
    elif action == "process_tmdb_selection":
        process_tmdb_selection(params, token)
    elif action == "show_similar":
        display_related_titles(params)

    elif action == "show_seasons":
        tmdb_id = params.get("tmdb_id")
        show_title = params.get("show_title", "Seriál")
        api_key = get_tmdb_api_key()
        if not api_key or not tmdb_id:
            xbmcgui.Dialog().notification(plugin_name, "Chyba: Chybí API klíč nebo ID seriálu.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
        tv_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}", {'language': UI_LANG, 'append_to_response': 'images'})
        if not tv_details or not tv_details.get("seasons"):
            xbmcgui.Dialog().notification(plugin_name, "Nepodařilo se načíst informace o sezónách.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
        xbmcplugin.setPluginCategory(addon_handle, f"{show_title} - Sezóny")
        xbmcplugin.setContent(addon_handle, 'tvshows')
        for season in tv_details.get("seasons", []):
            season_number = season.get("season_number")
            
            skip_specials = True 
            try:
                skip_specials = addon.getSettingBool("tmdb_skip_specials")
            except TypeError:
                log.warning(MOD, "'tmdb_skip_specials' setting missing or invalid type, defaulting to True")

            if season_number == 0 and skip_specials: 
                 continue
            season_name = season.get("name") or f"Sezóna {season_number}"
            episode_count = season.get("episode_count", 0)
            display_label = f"{season_name} ({episode_count} epizod)"
            li = xbmcgui.ListItem(label=display_label)
            art_data = {}
            poster_path = season.get('poster_path') or tv_details.get('poster_path')
            if poster_path: art_data['thumb'] = art_data['poster'] = f"https://image.tmdb.org/t/p/w500{poster_path}"
            fanart_url = get_banner_image_url(tv_details)
            if fanart_url: art_data['fanart'] = fanart_url
            if not art_data.get('thumb') and fanart_url: art_data['thumb'] = fanart_url
            li.setArt(art_data)
            
            # Používáme InfoTagVideo
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(season_name)
            info_tag.setPlot(season.get('overview', ''))
            info_tag.setTvShowTitle(show_title)
            info_tag.setSeason(season_number)
            info_tag.setEpisode(episode_count)
            info_tag.setMediaType('season')
            if season.get('air_date'): info_tag.setPremiered(season.get('air_date'))
            if tmdb_id: info_tag.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb') # Přidáme TMDb ID pro seriál

            li.setProperty('IsPlayable', 'false')
            url = f"{BASE_URL_PLUGIN}?action=show_episodes&tmdb_id={tmdb_id}&season_number={season_number}&show_title={urllib.parse.quote(show_title, encoding='utf-8')}&show_year={tv_details.get('first_air_date', '')[:4]}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

    elif action == "show_episodes":
        tmdb_id = params.get("tmdb_id")
        season_number = params.get("season_number")
        show_title = params.get("show_title", "Seriál")
        win = xbmcgui.Window(10000)
        tv_details_full = playback_manager.tmdb_api_request(get_tmdb_api_key(), f"/tv/{tmdb_id}", {'language': UI_LANG})
        if tv_details_full and 'seasons' in tv_details_full:
            show_structure = {
                'tmdb_id': tmdb_id,
                'seasons': {s['season_number']: {'episode_count': s['episode_count']} for s in tv_details_full['seasons']}
            }
            win.setProperty(f'{addon.getAddonInfo("id")}.show_structure', json.dumps(show_structure))
        show_year = params.get("show_year", "")
        api_key = get_tmdb_api_key()
        if not api_key or not tmdb_id or season_number is None:
            xbmcgui.Dialog().notification(plugin_name, "Chyba: Chybí API klíč, ID seriálu nebo číslo sezóny.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
        season_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}", {'language': UI_LANG, 'append_to_response': 'images'})
        if not season_details or not season_details.get("episodes"):
            xbmcgui.Dialog().notification(plugin_name, "Nepodařilo se načíst informace o epizodách.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
        xbmcplugin.setPluginCategory(addon_handle, f"{show_title} - Sezóna {season_number} - Epizody")
        xbmcplugin.setContent(addon_handle, 'episodes')
        for episode in season_details.get("episodes", []):
            episode_number = episode.get("episode_number")
            episode_name = episode.get("name") or f"Epizoda {episode_number}"
            display_label = f"E{episode_number:02d}: {episode_name}"
            li = xbmcgui.ListItem(label=display_label)
            art_data = {}
            still_path = episode.get('still_path')
            if still_path: art_data['thumb'] = art_data['icon'] = f"https://image.tmdb.org/t/p/w300{still_path}"
            else: 
                season_poster = season_details.get('poster_path')
                if season_poster: art_data['thumb'] = f"https://image.tmdb.org/t/p/w500{season_poster}"
            li.setArt(art_data)
            
            # Používáme InfoTagVideo
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(episode_name)
            info_tag.setPlot(episode.get('overview', ''))
            info_tag.setTvShowTitle(show_title)
            info_tag.setSeason(int(season_number))
            info_tag.setEpisode(episode_number)
            info_tag.setMediaType('episode')
            if episode.get('air_date'): info_tag.setPremiered(episode.get('air_date',''))
            if episode.get('vote_average'): info_tag.setRating(episode.get('vote_average'))
            if tmdb_id: info_tag.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb') # Přidáme TMDb ID pro seriál

            url = f"{BASE_URL_PLUGIN}?action=play_episode&tmdb_id={tmdb_id}&season_number={season_number}&episode_number={episode_number}&show_title={urllib.parse.quote(show_title, encoding='utf-8')}&episode_name_cs={urllib.parse.quote(episode.get('name', ''), encoding='utf-8')}&show_year={show_year}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

    elif action == "play_episode":
        tmdb_id = params.get("tmdb_id")
        season_number_str = params.get("season_number")
        episode_number_str = params.get("episode_number")
        show_title = params.get("show_title", "Seriál")
        show_year = params.get("show_year", "")
        autoplay_mode = _should_autoplay_next_episode(params)
        autoplay_source_mode = _should_autoplay_source(params)
        source_profile = _decode_source_profile(params.get('source_profile'))
        source_fingerprint = _decode_source_fingerprint(params.get('source_fingerprint'))
        try:
            autoplay_skips = int(params.get("autoplay_skips") or 0)
        except (ValueError, TypeError):
            autoplay_skips = 0
        
        if not all([tmdb_id, season_number_str, episode_number_str]):
            xbmcgui.Dialog().notification(plugin_name, "Chybí informace pro přehrání epizody.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
        try:
            season_num_int = int(season_number_str)
            episode_num_int = int(episode_number_str)
        except ValueError:
            xbmcgui.Dialog().notification(plugin_name, "Neplatné číslo sezóny nebo epizody.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
        if autoplay_mode and not _validate_autoplay_request(tmdb_id, season_num_int, episode_num_int, show_title, params):
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        # Fetch episode details from TMDb
        api_key = get_tmdb_api_key()
        episode_details = None
        season_details = None
        if api_key:
            season_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_num_int}", {'language': UI_LANG, 'append_to_response': 'images'})
            if season_details and 'episodes' in season_details:
                for ep in season_details['episodes']:
                    if ep.get('episode_number') == episode_num_int:
                        episode_details = ep
                        break

        # Prepare UpNext payload for the next episode overlay
        try:
            tv_details_full = playback_manager.tmdb_api_request(get_tmdb_api_key(), f"/tv/{tmdb_id}", {'language': UI_LANG})
        except Exception:
            tv_details_full = None
        tv_poster = (tv_details_full or {}).get('poster_path') if tv_details_full else None

        episodes_list = (season_details or {}).get('episodes', []) or []
        next_ep = None
        for _ep in episodes_list:
            if _ep.get('episode_number') == episode_num_int + 1:
                next_ep = _ep
                break

        next_season = None
        next_season_num = season_num_int
        if not next_ep:
            next_season_num = season_num_int + 1
            next_season = playback_manager.tmdb_api_request(get_tmdb_api_key(),
                                   f"/tv/{tmdb_id}/season/{next_season_num}",
                                   {'language': UI_LANG, 'append_to_response': 'images'})
            if next_season and next_season.get("episodes"):
                for _ep in next_season["episodes"]:
                    if _ep.get("episode_number") == 1:
                        next_ep = _ep
                        break

        current_ep_info = dict(episode_details or {})
        current_ep_info.setdefault("season_number", season_num_int)
        current_ep_info.setdefault("episode_number", episode_num_int)

        next_info_payload = None
        if next_ep:
            next_ep_info = dict(next_ep)
            if next_season_num != season_num_int:
                next_ep_info.setdefault("season_number", next_season_num)
            else:
                next_ep_info.setdefault("season_number", season_num_int)

            current_item = _build_upnext_item(tmdb_id, show_title, current_ep_info,
                                              tv_poster=tv_poster,
                                              season_poster=season_details.get('poster_path') if season_details else None)

            ns_poster = (next_season.get('poster_path') if next_season else None) or (season_details.get('poster_path') if season_details else None)
            next_item = _build_upnext_item(tmdb_id, show_title, next_ep_info,
                                           tv_poster=tv_poster,
                                           season_poster=ns_poster)

            play_info = {
                "tmdb_id": str(tmdb_id),
                "season_number": int(next_ep_info.get("season_number")),
                "episode_number": int(next_ep_info.get("episode_number")),
                "show_title": show_title,
                "show_year": show_year
            }

            next_info_payload = {
                "current_episode": current_item,
                "next_episode": next_item,
                "play_info": play_info
            }

        win = xbmcgui.Window(10000)
        if next_info_payload:
            win.setProperty(f"{addon.getAddonInfo('id')}.upnext_info", json.dumps(next_info_payload))
        else:
            win.clearProperty(f"{addon.getAddonInfo('id')}.upnext_info")
        
        episode_title = episode_details.get('name') if episode_details else params.get("episode_name_cs", f"Epizoda {episode_num_int}")
        episode_plot = episode_details.get('overview', '') if episode_details else ''
        episode_duration = (episode_details.get('runtime') or 0) * 60 if episode_details else 0 # TMDb sometimes gives minutes
        
        episode_art = {}
        if episode_details and episode_details.get('still_path'):
            episode_art['thumb'] = episode_art['icon'] = f"https://image.tmdb.org/t/p/w300{episode_details['still_path']}"
        elif season_details and season_details.get('poster_path'):
            episode_art['thumb'] = f"https://image.tmdb.org/t/p/w500{season_details['poster_path']}"
        
        # Manual mode: show scored+sorted list of sources
        raw_episode_files = playback_manager.get_all_episode_sources(
            token, tmdb_id, season_num_int, episode_num_int, show_title, show_year
        )
        if not raw_episode_files:
            if autoplay_mode and _advance_autoplay_episode(
                tmdb_id, season_num_int, episode_num_int, show_title, show_year, autoplay_skips,
                "žádné zdroje na Webshare"
            ):
                return
            message = f"Pro '{show_title} S{season_num_int:02d}E{episode_num_int:02d}' nebyly na Webshare nalezeny žádné relevantní soubory."
            xbmcgui.Dialog().notification(plugin_name, message, xbmcgui.NOTIFICATION_INFO, 8000)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        normalized_show = normalize_for_matching(show_title)
        ep_scored = []
        log.info(MOD, "Episode scoring: {} zdrojů pro '{}' S{}E{}", len(raw_episode_files), show_title, season_num_int, episode_num_int)
        for f in raw_episode_files:
            fname = f.get('name', '')
            fname_normalized = normalize_for_matching(fname)
            result = _score_video_file(fname, fname_normalized, f.get('size', 0),
                                       normalized_show, is_episode=True)
            if result is not None:
                ep_scored.append({'file': f, 'normalized_name': fname_normalized, **result})
        preferred_source_profile = source_profile or _get_manual_source_profile(tmdb_id, show_title) or _get_active_source_profile(tmdb_id, show_title)
        preferred_source_fingerprint = source_fingerprint or _get_manual_source_fingerprint(tmdb_id, show_title) or _get_active_source_fingerprint(tmdb_id, show_title)
        ep_scored = _apply_source_profile_preference(ep_scored, preferred_source_profile, preferred_source_fingerprint)
        if not preferred_source_profile and not preferred_source_fingerprint:
            ep_scored.sort(key=lambda x: x['score'], reverse=True)
        log.info(MOD, "Episode scoring: {}/{} zdrojů po filtraci, nejlepší: {:.1f}",
                 len(ep_scored), len(raw_episode_files),
                 ep_scored[0].get('preferred_score', ep_scored[0]['score']) if ep_scored else 0.0)

        if not ep_scored:
            if autoplay_mode and _advance_autoplay_episode(
                tmdb_id, season_num_int, episode_num_int, show_title, show_year, autoplay_skips,
                "zdroje neprošly scoringem"
            ):
                return
            xbmcgui.Dialog().notification(plugin_name, f"Pro '{show_title} S{season_num_int:02d}E{episode_num_int:02d}': žádné relevantní soubory.", xbmcgui.NOTIFICATION_INFO, 8000)
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        if len(ep_scored) == 1 and not autoplay_mode:
            only_source = ep_scored[0]['file']
            probe_url = playback_manager.get_stream_link(token, only_source['ident'])
            if not probe_url:
                if playback_manager.is_temporarily_unavailable_error():
                    xbmcgui.Dialog().notification(plugin_name, 'Jediný nalezený zdroj je na Webshare dočasně nedostupný. Zkuste epizodu později.', xbmcgui.NOTIFICATION_INFO, 8000)
                else:
                    xbmcgui.Dialog().notification(plugin_name, 'Jediný nalezený zdroj se nepodařilo ověřit pro přehrání.', xbmcgui.NOTIFICATION_INFO, 8000)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                return

        # 5.1 Auto-play pro epizody
        if autoplay_mode:
            if autoplay_skips > 0:
                xbmcgui.Dialog().notification(plugin_name, f"Autoplay přeskočil {autoplay_skips} nedostupné epizody.", xbmcgui.NOTIFICATION_INFO, 4000)
            for best_ep in ep_scored:
                autoplay_score = best_ep.get('preferred_score', best_ep['score']) if autoplay_source_mode else best_ep['score']
                log.info(MOD, "Auto-play epizoda: zkouším skóre {:.1f}, {}", autoplay_score, best_ep['file']['name'])
                ep_ident = best_ep['file']['ident']
                stream_url = playback_manager.get_stream_link(token, ep_ident)
                if not stream_url:
                    log.warning(MOD, "Auto-play epizoda: stream link selhal pro {}", best_ep['file']['name'])
                    continue
                headers_str = urllib.parse.urlencode({
                    'User-Agent': _session.headers.get('User-Agent', 'Mozilla/5.0'),
                    'Cookie': 'wst={}'.format(token)
                })
                play_item = xbmcgui.ListItem(path='{}|{}'.format(stream_url, headers_str))
                play_item.setMimeType(get_mimetype(best_ep['file']['name']))
                play_item.setContentLookup(False)
                it = play_item.getVideoInfoTag()
                it.setMediaType('episode')
                it.setTvShowTitle(show_title)
                it.setSeason(season_num_int)
                it.setEpisode(episode_num_int)
                it.setTitle(episode_title)
                if tmdb_id:
                    it.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb')
                history_item = {
                    'ident': ep_ident,
                    'name': episode_title or best_ep['file']['name'],
                    'type': 'video',
                    'timestamp': int(time.time()),
                    'show_title': show_title,
                }
                if tmdb_id:
                    history_item['tmdb_id'] = tmdb_id
                if episode_art.get('thumb'):
                    history_item['thumb'] = episode_art['thumb']
                if episode_art.get('poster'):
                    history_item['poster'] = episode_art['poster']
                if episode_art.get('fanart'):
                    history_item['fanart'] = episode_art['fanart']
                try:
                    history_item['season'] = int(season_num_int)
                    history_item['episode'] = int(episode_num_int)
                except (ValueError, TypeError):
                    pass
                if episode_duration:
                    history_item['duration_seconds'] = int(episode_duration)
                source_profile = _source_profile_from_scored_item(best_ep)
                source_fingerprint = _source_fingerprint_from_name(best_ep['file']['name'], best_ep)
                if source_profile:
                    history_item['source_profile'] = source_profile
                if source_fingerprint:
                    history_item['source_fingerprint'] = source_fingerprint
                add_to_history(history_item)
                try:
                    addon.setSetting('current_playing_ident', ep_ident)
                except Exception:
                    pass
                _set_active_source_profile(tmdb_id, show_title, source_profile, manual=False)
                _set_active_source_fingerprint(tmdb_id, show_title, source_fingerprint, manual=False)
                _set_window_json_state("playback_state", {
                    "tmdb_id": int(tmdb_id),
                    "season": int(season_num_int),
                    "episode": int(episode_num_int),
                    "title": episode_title,
                    "show_title": show_title,
                    "started_at": int(time.time()),
                })
                _clear_window_json_state("autoplay_session")
                xbmc.Player().play('{}|{}'.format(stream_url, headers_str), play_item)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
                return
            if _advance_autoplay_episode(
                tmdb_id, season_num_int, episode_num_int, show_title, show_year, autoplay_skips,
                "žádný zdroj dané epizody nebyl přehratelný"
            ):
                return

        xbmcplugin.setPluginCategory(addon_handle, f"Webshare zdroje pro: {show_title} S{season_num_int:02d}E{episode_num_int:02d}")
        xbmcplugin.setContent(addon_handle, 'videos')
        for scored_item in ep_scored:
            file_item = scored_item['file']
            size_bytes = file_item.get('size', 0)
            display_label = _build_source_label(
                scored_item['score'], scored_item['lang_tag'], scored_item['dub_type'],
                scored_item['quality_tag'], scored_item['source_tag'], scored_item['codec_tag'],
                size_bytes, file_item['name']
            )
            li = xbmcgui.ListItem(label=display_label)

            # Používáme InfoTagVideo
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(episode_title)
            li.setProperty('filesize', str(size_bytes))
            info_tag.setPlot(episode_plot)
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(show_title)
            info_tag.setSeason(season_num_int)
            info_tag.setEpisode(episode_num_int)
            if episode_duration: info_tag.setDuration(episode_duration)
            if tmdb_id: info_tag.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb')

            if episode_art:
                li.setArt(episode_art)

            li.setProperty('IsPlayable', 'true')
            source_profile_encoded = _encode_source_profile(_source_profile_from_scored_item(scored_item))
            source_fingerprint_encoded = _encode_source_fingerprint(_source_fingerprint_from_name(file_item['name'], scored_item))
            url = (f"{BASE_URL_PLUGIN}?action=play&ident={file_item['ident']}"
                   f"&name={urllib.parse.quote(file_item['name'], encoding='utf-8')}"
                   f"&tmdb_id={tmdb_id}&season_number={season_num_int}&episode_number={episode_num_int}"
                   f"&show_title={urllib.parse.quote(show_title, encoding='utf-8')}&show_year={show_year}"
                   f"&episode_title={urllib.parse.quote(episode_title, encoding='utf-8')}"
                   f"&episode_plot={urllib.parse.quote(episode_plot, encoding='utf-8')}"
                   f"&episode_duration={episode_duration}"
                   f"&episode_art={urllib.parse.quote(json.dumps(episode_art), encoding='utf-8')}"
                   f"&source_profile={source_profile_encoded}"
                   f"&source_fingerprint={source_fingerprint_encoded}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

    elif action == 'movies':
        movies(params)
    elif action == 'series':
        series(params)
    elif action == 'movies_category':
        movies_category(params)
    elif action == 'series_category':
        series_category(params)
    elif action == 'continue_watching':
        display_continue_watching()
    elif action == 'dismiss_continue':
        ident = params.get('ident')
        if _dismiss_continue_item(ident):
            xbmcgui.Dialog().notification(plugin_name, "Položka byla odebrána z Pokračovat ve sledování.", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification(plugin_name, "Položku se nepodařilo odebrat.", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return
    elif action == "search_test":
        log.info(MOD, "Action 'search_test' entered. Params: {}", params)
        xbmcgui.Dialog().notification(plugin_name, "Testovací vyhledávání spuštěno!", xbmcgui.NOTIFICATION_INFO, 3000)
        search_term = xbmcgui.Dialog().input(f"{plugin_name} – Testovací vyhledávání (Webshare)", type=xbmcgui.INPUT_ALPHANUM)
        if search_term:
            files = playback_manager.search_webshare(token, search_term)
            if not files:
                xbmcgui.Dialog().notification(plugin_name, f"Test: Nic pro '{search_term}'", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcplugin.setPluginCategory(addon_handle, f"Testovací výsledky (Webshare) pro: {search_term}")
                xbmcplugin.setContent(addon_handle, 'videos')
                for file_item in files:
                    li = xbmcgui.ListItem(label=f"[TEST] {file_item['name']}")
                    # Používáme InfoTagVideo
                    info_tag = li.getVideoInfoTag()
                    info_tag.setTitle(file_item["name"])
                    info_tag.setMediaType('video')
                    li.setProperty('IsPlayable', 'true')
                    url = f"{BASE_URL_PLUGIN}?action=play&ident={file_item['ident']}&name={urllib.parse.quote(file_item['name'])}"
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
    else:
        display_main_menu()

_VIDEO_EXTENSIONS = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.ts')

def _score_video_file(fname, fname_normalized, size_bytes, normalized_title,
                      normalized_original_title='', year_str='', is_episode=False):
    """Score a Webshare file against a known title.

    Returns a result dict on success, or None if the file should be skipped.
    Result keys: score, breakdown, lang_tag, dub_type, quality_tag, source_tag, codec_tag.
    """
    if re.search(r'\b(sample|trailer|teaser|preview)\b', fname_normalized):
        log.scoring(MOD, fname, -200, "sample=-200")
        return None

    if not any(fname.lower().endswith(ext) for ext in _VIDEO_EXTENSIONS):
        log.scoring(MOD, fname, -200, "not_video=-200")
        return None

    score = 0.0
    breakdown = []

    cz_match = normalized_title and normalized_title in fname_normalized
    orig_match = (normalized_original_title and
                  normalized_original_title != normalized_title and
                  normalized_original_title in fname_normalized)
    if not cz_match and not orig_match:
        log.scoring(MOD, fname, -100, "title_miss=-100")
        return None

    score += 3.0
    breakdown.append("title=+3.0")
    if orig_match and not cz_match:
        score += 0.5
        breakdown.append("orig_title=+0.5")

    # Year scoring only for movies (episodes rarely have year in filename)
    if not is_episode and year_str:
        yr_match = re.search(r'(19|20)\d{2}', fname_normalized)
        if yr_match and abs(int(yr_match.group()) - int(year_str)) <= 1:
            score += 2.0
            breakdown.append("year=+2.0")
        else:
            score -= 1.0
            breakdown.append("year=-1.0")

    lang_tag = ""
    dub_type = ""
    if re.search(r'\b(cz|cze|czech|cesk)\b', fname_normalized):
        lang_tag = "CZ"
        if re.search(r'\b(dab|dabing|dabovano|dubbed)\b', fname_normalized):
            dub_type = "DAB"
            score += 2.5
            breakdown.append("lang_cz_dab=+2.5")
        elif re.search(r'\b(tit|titulk|sub|subs|subtitles)\b', fname_normalized):
            dub_type = "TIT"
            score += 1.5
            breakdown.append("lang_cz_tit=+1.5")
        else:
            score += 2.0
            breakdown.append("lang_cz=+2.0")
    elif re.search(r'\b(sk|svk|slov|slovensky)\b', fname_normalized):
        lang_tag = "SK"
        if re.search(r'\b(dab|dabing|dabovano|dubbed)\b', fname_normalized):
            dub_type = "DAB"
            score += 2.0
            breakdown.append("lang_sk_dab=+2.0")
        else:
            score += 1.5
            breakdown.append("lang_sk=+1.5")
    elif re.search(r'\b(en|eng|english)\b', fname_normalized):
        lang_tag = "EN"
        score += 0.5
        breakdown.append("lang_en=+0.5")

    quality_tag = ""
    if '2160p' in fname_normalized or re.search(r'\b4k\b', fname_normalized):
        quality_tag = "4K"
        score += 2.0
        breakdown.append("quality_4k=+2.0")
    elif '1080p' in fname_normalized:
        quality_tag = "1080p"
        score += 1.5
        breakdown.append("quality_1080p=+1.5")
    elif '720p' in fname_normalized:
        quality_tag = "720p"
        score += 1.0
        breakdown.append("quality_720p=+1.0")

    source_tag = ""
    if re.search(r'\b(bluray|bdrip|bdremux)\b', fname_normalized) or 'blu ray' in fname_normalized:
        source_tag = "BluRay"
        score += 1.0
        breakdown.append("source_bluray=+1.0")
    elif re.search(r'\b(webdl|webrip)\b', fname_normalized) or 'web dl' in fname_normalized:
        source_tag = "WEB-DL"
        score += 0.5
        breakdown.append("source_webdl=+0.5")
    elif re.search(r'\b(hdrip)\b', fname_normalized):
        source_tag = "HDRip"
        score += 0.3
        breakdown.append("source_hdrip=+0.3")

    codec_tag = ""
    if re.search(r'\b(x265|hevc|h265)\b', fname_normalized):
        codec_tag = "x265"
        score += 0.5
        breakdown.append("codec_hevc=+0.5")
    elif re.search(r'\b(x264|h264|avc)\b', fname_normalized):
        codec_tag = "x264"

    # File size thresholds: smaller for episodes (typically 1-3 GB) vs movies (4-50 GB)
    if is_episode:
        if size_bytes > 1.5 * 1024 ** 3:
            score += 1.0
            breakdown.append("size_1.5gb=+1.0")
        elif size_bytes > 512 * 1024 ** 2:
            score += 0.5
            breakdown.append("size_512mb=+0.5")
    else:
        if size_bytes > 4 * 1024 ** 3:
            score += 1.0
            breakdown.append("size_4gb=+1.0")
        elif size_bytes > 2 * 1024 ** 3:
            score += 0.5
            breakdown.append("size_2gb=+0.5")

    if re.search(r'\b(cam|hcam|hdcam|telesync|tc)\b', fname_normalized):
        score -= 3.0
        breakdown.append("cam_penalty=-3.0")

    log.scoring(MOD, fname, score, " ".join(breakdown))
    return {
        'score': score,
        'lang_tag': lang_tag,
        'dub_type': dub_type,
        'quality_tag': quality_tag,
        'source_tag': source_tag,
        'codec_tag': codec_tag,
    }


def _build_source_label(score, lang_tag, dub_type, quality_tag, source_tag, codec_tag, size_bytes, filename):
    """Build the formatted label shown in Kodi source list."""
    parts = [f"[S: {score:.1f}]"]
    if lang_tag:
        parts.append(f"[{lang_tag}{' ' + dub_type if dub_type else ''}]")
    if quality_tag:
        parts.append(f"[{quality_tag}]")
    codec_parts = [p for p in [source_tag, codec_tag] if p]
    if codec_parts:
        parts.append(f"[{' '.join(codec_parts)}]")
    if size_bytes > 0:
        parts.append(f"({size_bytes / (1024 ** 3):.1f} GB)")
    parts.append(filename)
    return " ".join(parts)


def process_tmdb_selection(params, token):
    tmdb_id = params.get('tmdb_id')
    title = params.get('title', '')
    year = params.get('year', '')
    log.info(MOD, "Processing TMDb MOVIE selection: ID={}, Title='{}', Year='{}'", tmdb_id, title, year)

    tmdb_api_key = get_tmdb_api_key()
    detailed_tmdb_item = None
    if tmdb_api_key and tmdb_id:
        detailed_tmdb_item = get_tmdb_details(tmdb_api_key, tmdb_id, 'movie')
        if detailed_tmdb_item:
            title = detailed_tmdb_item.get('title', title)
            release_date = detailed_tmdb_item.get('release_date')
            if release_date and len(release_date) >= 4: year = release_date[:4]

    tmdb_title_cleaned = strip_year(title)
    normalized_tmdb_title = normalize_for_matching(tmdb_title_cleaned)
    tmdb_year_str = str(year) if year else ""
    original_title_cleaned = strip_year(detailed_tmdb_item.get('original_title', '')) if detailed_tmdb_item else ''

    normalized_original_title = normalize_for_matching(original_title_cleaned) if original_title_cleaned else ""

    # --- Multi-query Webshare search: all queries in parallel, deduplicate by ident ---
    queries_to_try = []
    if tmdb_title_cleaned:
        queries_to_try.append(tmdb_title_cleaned)
        if tmdb_year_str:
            queries_to_try.append(f"{tmdb_title_cleaned} {tmdb_year_str}")
    if original_title_cleaned and original_title_cleaned.lower() != tmdb_title_cleaned.lower():
        queries_to_try.append(original_title_cleaned)
        if tmdb_year_str:
            queries_to_try.append(f"{original_title_cleaned} {tmdb_year_str}")

    unique_queries = []
    seen_q = set()
    for q in queries_to_try:
        if q not in seen_q:
            seen_q.add(q)
            unique_queries.append(q)

    log.info(MOD, "Movie multi-search: {} queries pro '{}' ({})", len(unique_queries), title, tmdb_year_str)
    all_files_by_ident = {}
    for q in unique_queries:
        log.debug(MOD, "Webshare query: '{}'", q)
        for f in playback_manager.search_webshare(token, q):
            if f['ident'] not in all_files_by_ident:
                all_files_by_ident[f['ident']] = f

    webshare_files = list(all_files_by_ident.values())
    log.info(MOD, "Multi-search: {} unikátních souborů z {} queries", len(webshare_files), len(unique_queries))

    if not webshare_files:
        xbmcgui.Dialog().notification(plugin_name, f"Pro '{title}' nebyly na Webshare nalezeny žádné soubory.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return

    scored_files = []
    MIN_SCORE_THRESHOLD = 3.0
    log.info(MOD, "Scoring {} Webshare souborů pro '{}' ({})", len(webshare_files), title, tmdb_year_str)
    for ws_file in webshare_files:
        fname = ws_file.get('name', '')
        fname_normalized = normalize_for_matching(fname)
        size_bytes = ws_file.get('size', 0)
        result = _score_video_file(
            fname, fname_normalized, size_bytes,
            normalized_tmdb_title, normalized_original_title,
            year_str=tmdb_year_str, is_episode=False
        )
        if result is None:
            continue
        if result['score'] >= MIN_SCORE_THRESHOLD:
            scored_files.append({
                'file': ws_file,
                'normalized_name': fname_normalized,
                **result,
            })

    scored_files.sort(key=lambda x: x['score'], reverse=True)
    log.info(MOD, "Scoring hotov: {}/{} souborů prošlo prahem {}", len(scored_files), len(webshare_files), MIN_SCORE_THRESHOLD)
    if scored_files:
        log.info(MOD, "Nejlepší: [S:{:.1f}] {}", scored_files[0]['score'], scored_files[0]['file'].get('name', ''))
    if not scored_files:
        xbmcgui.Dialog().notification(plugin_name, f"Pro '{title} ({year})': žádné relevantní soubory na Webshare.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return

    # 5.1 Auto-play: pokud je zapnuto a nejlepší zdroj má skóre >= 7.0
    if _should_autoplay_source(params):
        best = scored_files[0]
        if best['score'] >= 7.0:
            log.info(MOD, "Auto-play: skóre {:.1f} >= 7.0, přehrávám: {}", best['score'], best['file']['name'])
            stream_url = playback_manager.get_stream_link(token, best['file']['ident'])
            if stream_url:
                play_item = xbmcgui.ListItem(path=stream_url)
                play_item.setMimeType(get_mimetype(best['file']['name']))
                play_item.setContentLookup(False)
                xbmc.Player().play(stream_url, play_item)
                xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
                return
            log.warning(MOD, "Auto-play: stream link selhal, zobrazuji seznam zdrojů")

    xbmcplugin.setPluginCategory(addon_handle, f"Webshare zdroje pro: {title} ({year})")
    xbmcplugin.setContent(addon_handle, 'videos')
    for scored_item in scored_files:
        file_item = scored_item['file']
        size_bytes = file_item.get("size", 0)
        display_label = _build_source_label(
            scored_item['score'], scored_item['lang_tag'], scored_item['dub_type'],
            scored_item['quality_tag'], scored_item['source_tag'], scored_item['codec_tag'],
            size_bytes, file_item['name']
        )
        li = xbmcgui.ListItem(label=display_label)
        size_str = f"{size_bytes / (1024 ** 3):.2f} GB"
        plot_info = f"Velikost: {size_str}\nSkóre: {scored_item['score']:.1f}\nNázev: {scored_item['normalized_name']}"
        art_data = {}
        playback_title_for_url = title
        playback_plot_for_url = ""
        if detailed_tmdb_item:
            # Používáme InfoTagVideo
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(detailed_tmdb_item.get('title', file_item['name']))
            info_tag.setPlot(detailed_tmdb_item.get('overview', plot_info))
            if year and year.isdigit(): info_tag.setYear(int(year))
            info_tag.setGenres([g['name'] for g in detailed_tmdb_item.get('genres', [])])
            info_tag.setRating(detailed_tmdb_item.get('vote_average'))
            info_tag.setMediaType('movie')
            li.setProperty('filesize', str(size_bytes)) # Volitelně pro UI/debug
            if tmdb_id: info_tag.setUniqueIDs({'tmdb': str(tmdb_id)})

            poster = detailed_tmdb_item.get('poster_path')
            fanart = detailed_tmdb_item.get('backdrop_path')
            if poster: art_data['thumb'] = art_data['poster'] = f"https://image.tmdb.org/t/p/w500{poster}"
            if fanart: art_data['fanart'] = f"https://image.tmdb.org/t/p/original{fanart}"
            li.setArt(art_data)
            playback_title_for_url = detailed_tmdb_item.get('title', title)
            playback_plot_for_url = detailed_tmdb_item.get('overview', '')
        else:
            # Používáme InfoTagVideo
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(file_item["name"])
            li.setProperty('filesize', str(size_bytes)) # Volitelně pro UI/debug
            info_tag.setPlot(plot_info)
            info_tag.setMediaType('video') # Obecný typ
        li.setProperty('IsPlayable', 'true')
        url = (f"{BASE_URL_PLUGIN}?action=play&ident={file_item['ident']}"
               f"&name={urllib.parse.quote(file_item['name'], encoding='utf-8')}"
               f"&tmdb_id={urllib.parse.quote(str(tmdb_id), encoding='utf-8')}"
               f"&media_type=movie"
               f"&playback_title={urllib.parse.quote(str(playback_title_for_url or ''), encoding='utf-8')}"
               f"&playback_plot={urllib.parse.quote(str(playback_plot_for_url or ''), encoding='utf-8')}"
               f"&playback_year={urllib.parse.quote(str(year or ''), encoding='utf-8')}"
               f"&playback_art={urllib.parse.quote(json.dumps(art_data), encoding='utf-8')}")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

def movies(params):
    xbmcplugin.setPluginCategory(addon_handle, "Filmy")
    categories = [
        ("Populární", "popular"),
        ("Nejlépe hodnocené", "top_rated"),
        ("Nově v kinech", "now_playing"),
    ]
    for label, cat in categories:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultMovies.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle,
                                    url=f"{BASE_URL_PLUGIN}?action=movies_category&category={cat}",
                                    listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def series(params):
    xbmcplugin.setPluginCategory(addon_handle, "Seriály")
    categories = [
        ("Populární", "popular"),
        ("Nejlépe hodnocené", "top_rated"),
        ("Právě vysíláno", "airing_today"),
        ("Aktuálně na TV", "on_the_air"),
    ]
    for label, cat in categories:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultTVShows.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle,
                                    url=f"{BASE_URL_PLUGIN}?action=series_category&category={cat}",
                                    listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def _tmdb_category_page(endpoint, category_label, content_type, item_builder, params):
    """Generic paginated TMDb category listing."""
    api_key = get_tmdb_api_key()
    if not api_key:
        xbmcgui.Dialog().notification(plugin_name, "Chybí TMDb API klíč.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return
    page = int(params.get('page', 1))
    category = params.get('category', 'popular')
    result = playback_manager.tmdb_api_request(api_key, endpoint, {'language': UI_LANG, 'page': page})
    if not result or not result.get('results'):
        xbmcgui.Dialog().notification(plugin_name, "Nepodařilo se načíst obsah z TMDb.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return
    xbmcplugin.setPluginCategory(addon_handle, category_label)
    xbmcplugin.setContent(addon_handle, content_type)
    for item in result['results']:
        item_builder(item)
    total_pages = min(result.get('total_pages', 1), 10)
    if page < total_pages:
        li_next = xbmcgui.ListItem(label=f"Další stránka ({page + 1}/{total_pages})")
        li_next.setArt({'icon': 'DefaultAddonNext.png'})
        action = 'movies_category' if content_type == 'movies' else 'series_category'
        xbmcplugin.addDirectoryItem(handle=addon_handle,
                                    url=f"{BASE_URL_PLUGIN}?action={action}&category={category}&page={page + 1}",
                                    listitem=li_next, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def movies_category(params):
    category = params.get('category', 'popular')
    labels = {'popular': 'Populární filmy', 'top_rated': 'Nejlépe hodnocené filmy', 'now_playing': 'Nově v kinech'}

    def build_movie_item(item):
        tmdb_id = item.get('id')
        title = item.get('title', '')
        year = (item.get('release_date') or '')[:4]
        li = xbmcgui.ListItem(label=f"{title} ({year})" if year else title)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(item.get('overview', ''))
        info_tag.setMediaType('movie')
        if year.isdigit(): info_tag.setYear(int(year))
        info_tag.setRating(item.get('vote_average', 0))
        if tmdb_id: info_tag.setUniqueIDs({'tmdb': str(tmdb_id)})
        art = {}
        if item.get('poster_path'): art['poster'] = art['thumb'] = f"https://image.tmdb.org/t/p/w500{item['poster_path']}"
        if item.get('backdrop_path'): art['fanart'] = f"https://image.tmdb.org/t/p/original{item['backdrop_path']}"
        li.setArt(art)
        li.setProperty('IsPlayable', 'false')
        if tmdb_id:
            similar_url = (
                f"{BASE_URL_PLUGIN}?action=show_similar&tmdb_id={tmdb_id}"
                f"&media_type=movie&title={urllib.parse.quote(str(title), encoding='utf-8')}"
            )
            li.addContextMenuItems([
                ("Podobné tituly", f"Container.Update({similar_url})"),
            ])
        url = (f"{BASE_URL_PLUGIN}?action=process_tmdb_selection"
               f"&tmdb_id={tmdb_id}&media_type=movie"
               f"&title={urllib.parse.quote(title, encoding='utf-8')}&year={year}")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    _tmdb_category_page(f"/movie/{category}", labels.get(category, 'Filmy'), 'movies', build_movie_item, params)


def series_category(params):
    category = params.get('category', 'popular')
    labels = {
        'popular': 'Populární seriály', 'top_rated': 'Nejlépe hodnocené seriály',
        'airing_today': 'Právě vysíláno', 'on_the_air': 'Aktuálně na TV'
    }

    def build_series_item(item):
        tmdb_id = item.get('id')
        title = item.get('name', '')
        year = (item.get('first_air_date') or '')[:4]
        li = xbmcgui.ListItem(label=f"{title} ({year})" if year else title)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setTvShowTitle(title)
        info_tag.setPlot(item.get('overview', ''))
        info_tag.setMediaType('tvshow')
        if year.isdigit(): info_tag.setYear(int(year))
        info_tag.setRating(item.get('vote_average', 0))
        if tmdb_id: info_tag.setUniqueIDs({'tmdb': str(tmdb_id)})
        art = {}
        if item.get('poster_path'): art['poster'] = art['thumb'] = f"https://image.tmdb.org/t/p/w500{item['poster_path']}"
        if item.get('backdrop_path'): art['fanart'] = f"https://image.tmdb.org/t/p/original{item['backdrop_path']}"
        li.setArt(art)
        li.setProperty('IsPlayable', 'false')
        if tmdb_id:
            similar_url = (
                f"{BASE_URL_PLUGIN}?action=show_similar&tmdb_id={tmdb_id}"
                f"&media_type=tv&title={urllib.parse.quote(str(title), encoding='utf-8')}"
            )
            li.addContextMenuItems([
                ("Podobné tituly", f"Container.Update({similar_url})"),
            ])
        url = (f"{BASE_URL_PLUGIN}?action=show_seasons"
               f"&tmdb_id={tmdb_id}&show_title={urllib.parse.quote(title, encoding='utf-8')}")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    _tmdb_category_page(f"/tv/{category}", labels.get(category, 'Seriály'), 'tvshows', build_series_item, params)

def _history_item_plot(item):
    timestamp_str = time.strftime('%d.%m.%Y %H:%M', time.localtime(item['timestamp']))
    resume = item.get('resume_time')
    if isinstance(resume, (int, float)) and resume > 0:
        h, m, s = resume // 3600, (resume % 3600) // 60, resume % 60
        return f"Naposledy přehráno: {timestamp_str}\nPozice: {h:02d}:{m:02d}:{s:02d} (nedokončeno)"
    if item.get('finished'):
        return f"Naposledy přehráno: {timestamp_str}\n✓ Dokončeno"
    return f"Naposledy přehráno: {timestamp_str}"


def _continue_item_plot(item):
    base_plot = _history_item_plot(item)
    tmdb_id = item.get('tmdb_id')
    season = item.get('season')
    episode = item.get('episode')
    if not (tmdb_id and season is not None and episode is not None):
        return base_plot
    try:
        from resources.lib.utils.next_finder import compute_next_episode
        next_ep = compute_next_episode(int(tmdb_id), int(season), int(episode))
    except Exception:
        next_ep = None
    if not next_ep:
        return base_plot
    next_label = f"S{int(next_ep['season']):02d}E{int(next_ep['episode']):02d}"
    next_title = (next_ep.get('title') or '').strip()
    if next_title:
        next_label = f"{next_label} - {next_title}"
    return f"Navazuje: {next_label}\n{base_plot}"


def _dismiss_continue_item(ident):
    if not ident:
        return False
    history_items = load_history()
    updated = False
    for item in history_items:
        if isinstance(item, dict) and item.get('ident') == ident:
            if 'resume_time' in item:
                item.pop('resume_time', None)
                updated = True
            item.pop('finished', None)
            break
    if updated:
        save_history(history_items)
    return updated


def _continue_group_key(item):
    tmdb_id = item.get('tmdb_id')
    show_title = item.get('show_title')
    if tmdb_id and show_title:
        return f"show:{tmdb_id}"
    if show_title:
        return f"show_title:{show_title.strip().lower()}"
    ident = item.get('ident')
    return f"item:{ident}" if ident else None


def _dedupe_continue_items(history_items):
    resume_items = []
    seen_keys = set()
    for item in history_items:
        if not (
            isinstance(item.get('resume_time'), (int, float))
            and item.get('resume_time') > 0
            and item.get('ident')
            and item.get('name')
            and item.get('type') == 'video'
        ):
            continue
        key = _continue_group_key(item)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        resume_items.append(item)
    return resume_items


def _history_display_label(item):
    show_title = item.get('show_title')
    season = item.get('season')
    episode = item.get('episode')
    base_name = item.get('name', '')
    if show_title and season and episode:
        return f"{show_title} - S{int(season):02d}E{int(episode):02d} - {base_name}"
    if show_title:
        return f"{show_title} - {base_name}"
    return base_name


def _history_art(item):
    art = {}
    tmdb_id = item.get('tmdb_id')
    if tmdb_id:
        api_key = get_tmdb_api_key()
        if api_key:
            if item.get('season') is not None and item.get('episode') is not None:
                tv_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}", {'language': UI_LANG})
                season_details = playback_manager.tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{item.get('season')}", {'language': UI_LANG})
                season_poster = season_details.get('poster_path') if season_details else None
                show_poster = tv_details.get('poster_path') if tv_details else None
                show_fanart = tv_details.get('backdrop_path') if tv_details else None
                if season_poster:
                    art['poster'] = art['thumb'] = art['icon'] = f"https://image.tmdb.org/t/p/w500{season_poster}"
                elif show_poster:
                    art['poster'] = art['thumb'] = art['icon'] = f"https://image.tmdb.org/t/p/w500{show_poster}"
                if show_fanart:
                    art['fanart'] = f"https://image.tmdb.org/t/p/original{show_fanart}"
            else:
                movie_details = playback_manager.tmdb_api_request(api_key, f"/movie/{tmdb_id}", {'language': UI_LANG})
                if movie_details:
                    if movie_details.get('poster_path'):
                        art['poster'] = art['thumb'] = art['icon'] = f"https://image.tmdb.org/t/p/w500{movie_details['poster_path']}"
                    if movie_details.get('backdrop_path'):
                        art['fanart'] = f"https://image.tmdb.org/t/p/original{movie_details['backdrop_path']}"
    if item.get('thumb'):
        art.setdefault('thumb', item['thumb'])
        art.setdefault('icon', item['thumb'])
    if item.get('poster'):
        art.setdefault('poster', item['poster'])
        art.setdefault('thumb', item['poster'])
    if item.get('fanart'):
        art.setdefault('fanart', item['fanart'])
    return art


def display_continue_watching():
    """Zobrazí nedokončená videa s uloženou pozicí přehrávání."""
    history_items = load_history()
    resume_items = _dedupe_continue_items(history_items)
    if not resume_items:
        xbmcgui.Dialog().notification(plugin_name, "Žádná nedokončená videa.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)
        return
    xbmcplugin.setPluginCategory(addon_handle, "Pokračovat ve sledování")
    xbmcplugin.setContent(addon_handle, 'videos')
    for item in resume_items:
        display_label = _history_display_label(item)
        li = xbmcgui.ListItem(label=display_label)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(display_label)
        info_tag.setPlot(_continue_item_plot(item))
        if item.get('show_title') and item.get('season') and item.get('episode'):
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(item['show_title'])
            try:
                info_tag.setSeason(int(item['season']))
                info_tag.setEpisode(int(item['episode']))
            except Exception:
                pass
        else:
            info_tag.setMediaType('video')
        art = _history_art(item)
        if art:
            li.setArt(art)
        resume = item['resume_time']
        try:
            info_tag.setResumePoint(float(resume), float(resume) + 600)
        except Exception:
            pass
        li.setProperty('IsPlayable', 'true')
        dismiss_cmd = (
            f'RunPlugin({BASE_URL_PLUGIN}?action=dismiss_continue'
            f'&ident={urllib.parse.quote(str(item["ident"]), encoding="utf-8")})'
        )
        li.addContextMenuItems([('Odebrat z Pokračovat ve sledování', dismiss_cmd)])
        url = (f"{BASE_URL_PLUGIN}?action=play&ident={item['ident']}"
               f"&name={urllib.parse.quote(item['name'], encoding='utf-8')}"
               f"&resume_time={resume}")
        if item.get('show_title'):
            url += f"&show_title={urllib.parse.quote(str(item['show_title']), encoding='utf-8')}"
        if item.get('tmdb_id'):
            url += f"&tmdb_id={urllib.parse.quote(str(item['tmdb_id']), encoding='utf-8')}"
        if item.get('season') is not None:
            url += f"&season_number={item['season']}"
        if item.get('episode') is not None:
            url += f"&episode_number={item['episode']}"
        if item.get('source_profile'):
            url += f"&source_profile={_encode_source_profile(item.get('source_profile'))}"
        if item.get('source_fingerprint'):
            url += f"&source_fingerprint={_encode_source_fingerprint(item.get('source_fingerprint'))}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def display_combined_history():
    xbmcplugin.setPluginCategory(addon_handle, "Historie")
    li_search_history_folder = xbmcgui.ListItem(label="Historie vyhledávání")
    li_search_history_folder.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search", listitem=li_search_history_folder, isFolder=True)
    history_items = load_history()
    if history_items:
        for item in history_items:
            if not item.get("ident") or not item.get("name") or item.get("type") != "video": continue
            display_label = _history_display_label(item)
            li = xbmcgui.ListItem(label=display_label)
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(display_label)
            info_tag.setPlot(_history_item_plot(item))
            if item.get('show_title') and item.get('season') and item.get('episode'):
                info_tag.setMediaType('episode')
                info_tag.setTvShowTitle(item['show_title'])
                try:
                    info_tag.setSeason(int(item['season']))
                    info_tag.setEpisode(int(item['episode']))
                except Exception:
                    pass
            else:
                info_tag.setMediaType('video')
            art = _history_art(item)
            if art:
                li.setArt(art)
            li.setProperty('IsPlayable', 'true')
            url = f"{BASE_URL_PLUGIN}?action=play&ident={item['ident']}&name={urllib.parse.quote(item['name'])}"
            if item.get('show_title'):
                url += f"&show_title={urllib.parse.quote(str(item['show_title']), encoding='utf-8')}"
            if item.get('tmdb_id'):
                url += f"&tmdb_id={urllib.parse.quote(str(item['tmdb_id']), encoding='utf-8')}"
            if item.get('season') is not None:
                url += f"&season_number={item['season']}"
            if item.get('episode') is not None:
                url += f"&episode_number={item['episode']}"
            if item.get('source_profile'):
                url += f"&source_profile={_encode_source_profile(item.get('source_profile'))}"
            if item.get('source_fingerprint'):
                url += f"&source_fingerprint={_encode_source_fingerprint(item.get('source_fingerprint'))}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def display_main_menu():
    li_new_search = xbmcgui.ListItem(label="Vyhledat film/seriál")
    li_new_search.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search&ask=1", listitem=li_new_search, isFolder=True)
    
    listitem_movies = xbmcgui.ListItem(label="Filmy")
    listitem_movies.setArt({'icon': 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=movies", listitem=listitem_movies, isFolder=True)

    listitem_series = xbmcgui.ListItem(label="Seriály")
    listitem_series.setArt({'icon': 'DefaultTVShows.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=series", listitem=listitem_series, isFolder=True)

    li_continue = xbmcgui.ListItem(label="Pokračovat ve sledování")
    li_continue.setArt({'icon': 'DefaultInProgressShows.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=continue_watching", listitem=li_continue, isFolder=True)

    li_history_folder = xbmcgui.ListItem(label="Historie")
    li_history_folder.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=show_combined_history", listitem=li_history_folder, isFolder=True)

    testing_enabled = addon.getSetting("testing_functions") == 'true'

    if testing_enabled:
        li_search_test = xbmcgui.ListItem(label="Vyhledávání - test Webshare")
        li_search_test.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=search_test", listitem=li_search_test, isFolder=True)

    li_settings = xbmcgui.ListItem(label="Nastavení")
    li_settings.setArt({'icon': 'DefaultAddonService.png', 'thumb': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{BASE_URL_PLUGIN}?action=open_settings", listitem=li_settings, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def add_dir(label, url, is_folder, icon=None, fanart=None, info=None, properties=None):
    li = xbmcgui.ListItem(label=label)
    art = {}
    if icon: art['icon'] = art['thumb'] = icon
    if fanart: art['fanart'] = fanart
    if art: li.setArt(art)
    if info: 
        # Používáme InfoTagVideo
        info_tag = li.getVideoInfoTag()
        if 'title' in info: info_tag.setTitle(info['title'])
        if 'plot' in info: info_tag.setPlot(info['plot'])
        if 'mediatype' in info: info_tag.setMediaType(info['mediatype'])
        if 'year' in info: info_tag.setYear(info['year'])
        if 'season' in info: info_tag.setSeason(info['season'])
        if 'episode' in info: info_tag.setEpisode(info['episode'])
        if 'tvshowtitle' in info: info_tag.setTvShowTitle(info['tvshowtitle'])
        if 'premiered' in info: info_tag.setPremiered(info['premiered'])
        if 'rating' in info: info_tag.setRating(info['rating'])
        if 'genre' in info: info_tag.setGenres(info['genre'])

    if properties:
        for key, value in properties.items():
            li.setProperty(key, value)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)

if __name__ == "__main__":
    args = sys.argv[2]
    if args.startswith('?'):
        args = args[1:]
    router(args)
