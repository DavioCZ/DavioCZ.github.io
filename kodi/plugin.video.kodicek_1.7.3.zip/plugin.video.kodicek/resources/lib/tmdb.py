# -*- coding: utf-8 -*-
import re
import xbmcaddon
from resources.lib import playback_manager
from resources.lib.utils.logger import log

ADDON = xbmcaddon.Addon()
TMDB_API_BASE_URL = "https://api.themoviedb.org/3/"
UI_LANG = "cs-CZ"
_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")
_SEQUEL_SUFFIX_RE = re.compile(r"(?:\s+|[:\-])(?:part\s+)?(?:\d+|[ivxlcdm]+)$", re.IGNORECASE)
_STOP_WORDS = {
    'the', 'a', 'an', 'movie', 'film', 'serie', 'series', 'season', 'part'
}

def _get_tmdb_api_key():
    return ADDON.getSetting("tmdb_api_key")

def _tmdb_api_request(endpoint, params=None, method='get'):
    api_key = _get_tmdb_api_key()
    if not api_key:
        log.error("tmdb", "TMDb API key is missing for request")
        return None
    return playback_manager.tmdb_api_request(api_key, endpoint, params, method)


def _normalize_sort_text(text):
    text = (text or "").lower()
    text = _NON_ALNUM_RE.sub(" ", text)
    return " ".join(text.split())


def _year_from_item(item):
    date_value = item.get('release_date') or item.get('first_air_date') or ''
    year = date_value[:4]
    return int(year) if year.isdigit() else 9999


def _display_title(item):
    return (item.get('title') or item.get('name') or item.get('original_title') or item.get('original_name') or '').strip()


def _family_root(title):
    normalized = _normalize_sort_text(title)
    return _SEQUEL_SUFFIX_RE.sub("", normalized).strip()


def _query_series_group(query_norm, title_norm, family_root):
    if not query_norm:
        return family_root
    if title_norm.startswith(query_norm):
        return query_norm
    if family_root == query_norm:
        return query_norm
    if query_norm in title_norm:
        return query_norm
    return family_root


def _tokenize(text):
    return [token for token in _normalize_sort_text(text).split() if token]


def _title_overlap_score(query_norm, title, original_title=''):
    query_tokens = set(_tokenize(query_norm))
    query_tokens = {token for token in query_tokens if token not in _STOP_WORDS}
    if not query_tokens:
        query_tokens = set(_tokenize(query_norm))
    title_tokens = set(_tokenize(title)) | set(_tokenize(original_title))
    if not title_tokens:
        return 0.0
    shared = query_tokens & title_tokens
    if not shared:
        return 0.0
    return float(len(shared)) / float(max(len(query_tokens), 1))


def _collection_query_score(query_norm, collection_name):
    collection_norm = _normalize_sort_text(collection_name)
    if not query_norm or not collection_norm:
        return 0.0
    return _title_overlap_score(query_norm, collection_norm)


def _query_phrase_match_rank(query_norm, title_norm, original_title_norm=''):
    if not query_norm:
        return 9
    if title_norm == query_norm or original_title_norm == query_norm:
        return 0
    if title_norm.startswith(query_norm) or original_title_norm.startswith(query_norm):
        return 1
    if query_norm in title_norm or query_norm in original_title_norm:
        return 2
    query_tokens = _tokenize(query_norm)
    title_tokens = set(_tokenize(title_norm)) | set(_tokenize(original_title_norm))
    if query_tokens and all(token in title_tokens for token in query_tokens):
        return 3
    if query_tokens and any(token in title_tokens for token in query_tokens):
        return 4
    return 9


def _enrich_movie_collections(query_norm, results, limit=12):
    enriched = {}
    movie_candidates = []
    for item in results:
        if item.get('media_type') != 'movie':
            continue
        title_norm = _normalize_sort_text(_display_title(item))
        if query_norm and query_norm not in title_norm and not title_norm.startswith(query_norm):
            continue
        movie_candidates.append(item)
        if len(movie_candidates) >= limit:
            break
    for item in movie_candidates:
        movie_id = item.get('id')
        if not movie_id:
            continue
        details = _tmdb_api_request(f"/movie/{movie_id}", {'language': UI_LANG})
        collection = (details or {}).get('belongs_to_collection') or {}
        enriched[movie_id] = {
            'collection_id': collection.get('id'),
            'collection_name': _normalize_sort_text(collection.get('name', '')),
            'collection_query_score': _collection_query_score(query_norm, collection.get('name', '')),
        }
    return enriched


def _sort_tmdb_results(query, results):
    query_norm = _normalize_sort_text(query)
    movie_collection_info = _enrich_movie_collections(query_norm, results)

    group_meta = {}
    for item in results:
        media_type = item.get('media_type')
        title = _display_title(item)
        title_norm = _normalize_sort_text(title)
        family_root = _family_root(title)
        series_group = _query_series_group(query_norm, title_norm, family_root)
        collection_info = movie_collection_info.get(item.get('id'), {})
        collection_id = collection_info.get('collection_id')
        group_id = "collection:{}".format(collection_id) if collection_id else "series:{}:{}".format(media_type, series_group)
        meta = group_meta.setdefault(group_id, {
            'min_year': 9999,
            'has_collection': bool(collection_id),
            'series_group': series_group,
            'collection_query_score': 0.0,
        })
        meta['min_year'] = min(meta['min_year'], _year_from_item(item))
        meta['collection_query_score'] = max(
            meta.get('collection_query_score') or 0.0,
            float(collection_info.get('collection_query_score') or 0.0),
        )

    def sort_key(item):
        media_type = item.get('media_type')
        if media_type not in ('movie', 'tv'):
            media_rank = 9
        else:
            media_rank = 0 if media_type == 'movie' else 1
        title = _display_title(item)
        title_norm = _normalize_sort_text(title)
        original_title_norm = _normalize_sort_text(item.get('original_title') or item.get('original_name') or '')
        family_root = _family_root(title)
        series_group = _query_series_group(query_norm, title_norm, family_root)
        collection_info = movie_collection_info.get(item.get('id'), {})
        collection_id = collection_info.get('collection_id')
        group_id = "collection:{}".format(collection_id) if collection_id else "series:{}:{}".format(media_type, series_group)
        meta = group_meta.get(group_id, {})
        overlap_score = _title_overlap_score(query_norm, title, item.get('original_title') or item.get('original_name') or '')
        phrase_rank = _query_phrase_match_rank(query_norm, title_norm, original_title_norm)
        collection_query_score = float(collection_info.get('collection_query_score') or 0.0)
        exact_rank = 0 if title_norm == query_norm else 1
        family_rank = 0 if family_root == query_norm else 1
        contains_rank = 0 if query_norm and query_norm in title_norm else 1
        word_start_rank = 0 if query_norm and title_norm.startswith(query_norm) else 1
        popularity_rank = -float(item.get('popularity') or 0)
        vote_rank = -float(item.get('vote_average') or 0)
        year_rank = _year_from_item(item)
        return (
            media_rank,
            phrase_rank,
            0 if overlap_score >= 0.99 else 1,
            0 if overlap_score >= 0.5 else 1,
            family_rank,
            exact_rank,
            word_start_rank,
            contains_rank,
            0 if series_group == query_norm and query_norm else 1,
            0 if meta.get('has_collection') and query_norm and meta.get('collection_query_score', 0.0) >= 0.75 else 1,
            collection_info.get('collection_name') or series_group,
            meta.get('min_year', 9999),
            year_rank,
            popularity_rank,
            vote_rank,
            title_norm,
        )

    sorted_results = sorted(results, key=sort_key)
    preview = []
    for item in sorted_results[:12]:
        title = _display_title(item)
        year = _year_from_item(item)
        if year == 9999:
            year = 0
        media_type = item.get('media_type')
        title_norm = _normalize_sort_text(title)
        family_root = _family_root(title)
        series_group = _query_series_group(query_norm, title_norm, family_root)
        collection_info = movie_collection_info.get(item.get('id'), {})
        collection_name = collection_info.get('collection_name') or '-'
        collection_id = collection_info.get('collection_id') or '-'
        overlap_score = _title_overlap_score(query_norm, title, item.get('original_title') or item.get('original_name') or '')
        preview.append(
            "{}:{}:{}:cid={}:cq={:.2f}:oq={:.2f}:group={}:col={}".format(
                media_type,
                title,
                year,
                collection_id,
                float(collection_info.get('collection_query_score') or 0.0),
                overlap_score,
                series_group or '-',
                collection_name,
            )
        )
    log.info("tmdb", "TMDb sort '{}' -> {}", query, " | ".join(preview))
    return sorted_results

def search_tmdb(query, tmdb_get_func):
    """
    Searches TMDB using multi search, with language fallback and fuzzy alias.
    """
    langs = ["cs-CZ", "en-US"]
    
    for lang in langs:
        params = {"query": query, "language": lang}
        res = tmdb_get_func("/search/multi", params)
        if res and res.get("results"):
            return _sort_tmdb_results(query, res["results"])
            
    alt_query = query.replace(" a ", " and ")
    if alt_query != query:
        return search_tmdb(alt_query, tmdb_get_func)
        
    return []


def get_related_titles(tmdb_id, media_type):
    endpoint_base = '/movie' if media_type == 'movie' else '/tv'
    merged = {}
    for suffix in ('recommendations', 'similar'):
        data = _tmdb_api_request(f"{endpoint_base}/{tmdb_id}/{suffix}", {'language': UI_LANG})
        for item in (data or {}).get('results', []):
            item_media_type = media_type if item.get('media_type') in (None, '') else item.get('media_type')
            if item_media_type not in ('movie', 'tv'):
                item_media_type = media_type
            item['media_type'] = item_media_type
            key = "{}:{}".format(item_media_type, item.get('id'))
            if key not in merged:
                merged[key] = item
    query_seed = _display_title(next(iter(merged.values()), {}))
    return _sort_tmdb_results(query_seed, list(merged.values()))

def get_show_details(tmdb_id: int):
    """ Získá detailní informace o seriálu z TMDb. """
    return _tmdb_api_request(f"/tv/{tmdb_id}", {'language': UI_LANG, 'append_to_response': 'images,credits'})

def get_season_episodes(tmdb_id: int, season_number: int):
    """ Získá seznam epizod pro danou sezónu seriálu z TMDb. """
    season_details = _tmdb_api_request(f"/tv/{tmdb_id}/season/{season_number}", {'language': UI_LANG, 'append_to_response': 'images'})
    return season_details.get('episodes', []) if season_details else []

def season_exists(tmdb_id: int, season_number: int):
    """ Zkontroluje, zda daná sezóna existuje pro seriál. """
    show_details = get_show_details(tmdb_id)
    if show_details and 'seasons' in show_details:
        for season in show_details['seasons']:
            if season.get('season_number') == season_number:
                return True
    return False

def image_url(path: str, size="w500"):
    """ Vrací plnou URL k obrázku z TMDb. """
    if path:
        return f"https://image.tmdb.org/t/p/{size}{path}"
    return ""

if __name__ == '__main__':
    # Example usage (requires a mock or real tmdb_get function)
    def mock_tmdb_get(endpoint, params):
        print(f"Mock TMDB GET: {endpoint} with params {params}")
        if params["query"] == "Test Show" and params["language"] == "cs-CZ":
            return {"results": [{"id": 1, "name": "Test Show CS", "media_type": "tv"}]}
        if params["query"] == "Test Show" and params["language"] == "en-US":
            return {"results": [{"id": 1, "name": "Test Show EN", "media_type": "tv"}]}
        if params["query"] == "NonExistent a Show" and params["language"] == "cs-CZ":
            return {"results": []}
        if params["query"] == "NonExistent a Show" and params["language"] == "en-US":
            return {"results": []}
        if params["query"] == "NonExistent and Show" and params["language"] == "cs-CZ":
            return {"results": [{"id": 2, "name": "NonExistent and Show CS (from alias)", "media_type": "movie"}]}
        return {"results": []}

    print("Searching for 'Test Show':")
    results = search_tmdb("Test Show", mock_tmdb_get)
    print(f"Results: {results}\n")

    print("Searching for 'NonExistent a Show' (will try alias):")
    results_alias = search_tmdb("NonExistent a Show", mock_tmdb_get)
    print(f"Results: {results_alias}\n")

    print("Searching for 'Only English Show' (mock needs to be adjusted to test this path):")
    # To test this, mock_tmdb_get should return empty for cs-CZ and results for en-US
    def mock_tmdb_get_en_fallback(endpoint, params):
        print(f"Mock TMDB GET (EN Fallback): {endpoint} with params {params}")
        if params["query"] == "Only English Show" and params["language"] == "cs-CZ":
            return {"results": []}
        if params["query"] == "Only English Show" and params["language"] == "en-US":
            return {"results": [{"id": 3, "name": "Only English Show EN", "media_type": "tv"}]}
        return {"results": []}
    results_en = search_tmdb("Only English Show", mock_tmdb_get_en_fallback)
    print(f"Results: {results_en}\n")
