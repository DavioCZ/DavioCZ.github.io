import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import json
import os
from resources.lib.utils.logger import log

_MOD = "resume"

class KodicekPlayer(xbmc.Player):
    def __init__(self):
        super(KodicekPlayer, self).__init__()
        self.current_ident = None
        self._last_saved_pos = 0

    def onPlayBackStarted(self):
        try:
            self._load_current_ident(reset_pos=True)
        except Exception as e:
            log.error(_MOD, "Nelze číst current_playing_ident: {}", e)
            self.current_ident = None
            self._last_saved_pos = 0

    def _load_current_ident(self, reset_pos=False):
        self.current_ident = xbmcaddon.Addon('plugin.video.kodicek').getSetting('current_playing_ident')
        if reset_pos:
            self._last_saved_pos = 0
        log.debug(_MOD, "Aktualni playing ident='{}'", self.current_ident)

    def onPlayBackStopped(self):
        self.save_resume_time(finished=self._should_mark_finished())

    def onPlayBackEnded(self):
        self.save_resume_time(finished=True)

    def _should_mark_finished(self):
        if not self.current_ident:
            return False
        try:
            current_pos_int = int(self.getTime())
            total_time_int = int(self.getTotalTime())
        except Exception:
            current_pos_int = 0
            total_time_int = 0
        if total_time_int <= 0:
            try:
                history_path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.kodicek/history.json')
                if os.path.exists(history_path):
                    with open(history_path, 'r', encoding='utf-8') as f:
                        history = json.load(f)
                    for item in history:
                        if isinstance(item, dict) and item.get("ident") == self.current_ident:
                            total_time_int = int(item.get("duration_seconds") or 0)
                            break
            except Exception:
                total_time_int = 0
        if current_pos_int <= 0 or total_time_int <= 0:
            return False
        remaining = max(total_time_int - current_pos_int, 0)
        watched_ratio = float(current_pos_int) / float(total_time_int)
        return watched_ratio >= 0.92 or (watched_ratio >= 0.85 and remaining <= 180)

    def tick(self):
        if not self.current_ident:
            try:
                self._load_current_ident(reset_pos=False)
            except Exception:
                return
        if not self.current_ident:
            return
        try:
            if not self.isPlayingVideo():
                return
            current_pos_int = int(self.getTime())
        except Exception:
            return
        if current_pos_int >= 10 and current_pos_int - self._last_saved_pos >= 10:
            self.save_resume_time(current_pos_int=current_pos_int)

    def save_resume_time(self, finished=False, current_pos_int=None):
        if not self.current_ident:
            log.debug(_MOD, "Žádný current_ident, resume se neuloží")
            return

        if current_pos_int is None:
            try:
                current_pos_int = int(self.getTime())
            except RuntimeError:
                current_pos_int = 0
        if not finished and current_pos_int <= 0 and self._last_saved_pos > 0:
            current_pos_int = int(self._last_saved_pos)
        log.debug(_MOD, "save_resume_time: ident='{}', pos={}, finished={}", self.current_ident, current_pos_int, finished)

        HISTORY_PATH = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.kodicek/history.json')

        try:
            if os.path.exists(HISTORY_PATH):
                with open(HISTORY_PATH, 'r', encoding='utf-8') as f:
                    history = json.load(f)
            else:
                history = []

            if not isinstance(history, list):
                log.error(_MOD, "Historie není list: {}", type(history))
                history = []

            item_found = False
            for item in history:
                if isinstance(item, dict) and item.get("ident") == self.current_ident:
                    if finished:
                        item.pop("resume_time", None)
                        item["finished"] = True
                        self._last_saved_pos = 0
                        log.debug(_MOD, "Označeno jako dokončeno: {}", self.current_ident)
                    else:
                        if current_pos_int <= 0:
                            log.debug(_MOD, "Pozice je 0 s, resume_time neprepisuji pro ident: {}", self.current_ident)
                            item_found = True
                            break
                        item["resume_time"] = current_pos_int
                        item.pop("finished", None)
                        self._last_saved_pos = current_pos_int
                        log.debug(_MOD, "Uložen resume_time={} pro ident: {}", current_pos_int, self.current_ident)
                    item_found = True
                    break

            if not item_found:
                log.warning(_MOD, "Položka v historii nenalezena pro ident: {}", self.current_ident)

            with open(HISTORY_PATH, 'w', encoding='utf-8') as f:
                json.dump(history, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.error(_MOD, "Chyba při ukládání resume: {}", e)
