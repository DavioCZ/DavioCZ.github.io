# Task List – The Simpsons (Elementum)

## 0. Příprava
- [x] založit repozitář, přidat .gitignore

## 1. Skeleton add-onu
- [x] addon.xml (metadata, závislosti, platform=all)
- [x] default.py router
  - [x] hlavní menu – výpis sérií 1-34
  - [x] podmenu – výpis epizod 1-22
  - [x] play handler → Elementum URL s ?filename=
- [x] balíček ZIP, ruční test v Kodi

## 2. UX vylepšení
- [ ] dynamické počty epizod podle metainfo
- [ ] metadata ListItem → Up Next
- [ ] nastavení HASH v GUI (settings.xml)

## 3. Dokumentace & release
- [ ] README s návodem (instalace, požadavky)
- [ ] CHANGELOG update, tag v0.1.0
