# The Simpsons (Elementum)

Minimalistický Kodi video-addon pro přehrávání Simpsonových z torrentu pomocí Elementum.
