# -*- coding: utf-8 -*-

import io
import json
import os

import xbmcaddon
import xbmcvfs

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath


PROGRESS_FILE = 'progress.json'


def profile_path():
    return translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def progress_path():
    return os.path.join(profile_path(), PROGRESS_FILE)


def ensure_profile_dir():
    path = profile_path()
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)


def load_progress():
    ensure_profile_dir()
    path = progress_path()
    if not xbmcvfs.exists(path):
        return {}

    try:
        with io.open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_progress(progress):
    ensure_profile_dir()
    with io.open(progress_path(), 'w', encoding='utf-8') as handle:
        json.dump(progress, handle, ensure_ascii=False, indent=2)


def set_last_episode(series_id, ep_num):
    progress = load_progress()
    progress['last'] = {
        'series': series_id,
        'episode': int(ep_num),
    }
    progress.setdefault('series', {})[series_id] = int(ep_num)
    save_progress(progress)
