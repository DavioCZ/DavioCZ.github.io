# -*- coding: utf-8 -*-

FILLER_RANGES = {
    'naruto': (
        (26, 26),
        (97, 97),
        (101, 106),
        (136, 140),
        (143, 219),
    ),
    'shippuden': (
        # Source: reddit.com/r/anime/comments/mvds6j/detailed_naruto_shippuden_filler_watching_guide
        #
        # REMOVED from fillers (Reddit says "you should watch"):
        #   57-71   – Land of Fire arc, good fights, story connections
        #   110-112 – end of Three-Tails arc, connects to ep 113
        #   144-151 – introduces character needed for ep 152
        #   284-295 – story connections throughout
        #   303-305, 307-308, 317 – important episodes within 303-320 block
        #   347-361 – Akatsuki origins + Kakashi ANBU years
        #   388-390 – no plot connection but enjoyable; Reddit says watch
        #   417     – canon (was incorrectly grouped with filler 416)
        #   464-468 – past events needed to understand main story
        #
        (28, 28),       # Skip directly
        (91, 109),      # Three-Tails filler (110-112 kept visible above)
        (170, 171),     # Skip directly
        (176, 196),     # Gray area – no essential story content
        (223, 242),     # Skip directly
        (257, 260),     # Skip directly
        (271, 271),     # Skip directly
        (279, 281),     # Skip directly
        (306, 306),     # Filler within 303-320 block
        (309, 316),     # Filler within 303-320 block
        (318, 321),     # Filler within 303-320 block + 321 (barely non-filler)
        (376, 377),     # Skip directly
        (394, 413),     # Old Chunin Exams – boring, cuts main story; skip recommended
        (416, 416),     # Skip directly (417 is canon!)
        (422, 423),     # Skip directly
        (427, 450),     # Skip directly
        (480, 483),     # Skip directly
    ),
}

FILLER_EPISODES = {
    series_id: set(
        ep_num
        for start, end in ranges
        for ep_num in range(start, end + 1)
    )
    for series_id, ranges in FILLER_RANGES.items()
}


def is_filler_episode(series_id, ep_num):
    return ep_num in FILLER_EPISODES.get(series_id, set())


def visible_episode_numbers(series_id, total, skip_fillers):
    if not skip_fillers:
        return list(range(1, total + 1))

    fillers = FILLER_EPISODES.get(series_id, set())
    return [
        ep_num
        for ep_num in range(1, total + 1)
        if ep_num not in fillers
    ]


def is_visible_episode(series_id, ep_num, skip_fillers):
    return not skip_fillers or not is_filler_episode(series_id, ep_num)
