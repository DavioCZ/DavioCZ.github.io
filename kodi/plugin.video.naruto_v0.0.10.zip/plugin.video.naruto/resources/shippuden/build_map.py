# resources/shippuden/build_map.py
# -*- coding: utf-8 -*-
#
# Naruto Shippuden – build_map.py
# Generuje resources/shippuden/map.json z resources/shippuden/naruto-shippuden.torrent
#
# Soubory v torrentu mají formát:
#   "Naruto Shippuden  001.mkv"         -> E001
#   "Naruto Shippuden  006-007.mkv"     -> E006, E007  (double-epizoda)

import io, os, re, json, argparse
from collections import OrderedDict

MIN_ELEMENTUM_CANDIDATE_SIZE = 4 * 1024 * 1024

# Regex pro single epizodu:  "  042.mkv"
SINGLE_RE = re.compile(r'(\d{3})\.mkv$', re.IGNORECASE)
# Regex pro double epizodu:  "  006-007.mkv"
DOUBLE_RE = re.compile(r'(\d{3})-(\d{3})\.mkv$', re.IGNORECASE)


# ---------------------------------------------------------------------------
# Minimalistický bdecoder
# ---------------------------------------------------------------------------
def bdecode(data: bytes):
    s = io.BytesIO(data)

    def r(n=1):
        b = s.read(n)
        if not b:
            raise ValueError("Unexpected EOF")
        return b

    def p():
        x = s.read(1)
        if not x:
            return b""
        s.seek(-1, 1)
        return x

    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-':
                num += ch; ch = r(1)
            while ch != b'e':
                if not (b'0' <= ch <= b'9'):
                    raise ValueError("Bad int")
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e':
                out.append(parse())
            r(1)
            return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                d[bytes(k)] = parse()
            r(1)
            return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                ln += ch; ch = r(1)
            return r(int(ln))
        raise ValueError("Bad prefix: %r" % c)

    return parse()


def load_files(torrent_path):
    """Vrátí seznam (torrent_index, path, length) pro .mkv soubory."""
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})
    files = []
    if b'files' in info:
        for torrent_index, f in enumerate(info[b'files']):
            parts = [p.decode('utf-8', 'ignore') for p in f.get(b'path', [])]
            files.append((torrent_index, '/'.join(parts), int(f.get(b'length', 0))))
    elif b'name' in info and b'length' in info:
        files.append((0, info[b'name'].decode('utf-8', 'ignore'), int(info[b'length'])))
    else:
        raise ValueError("Nepodporovaná struktura torrentu.")

    return [(i, p, l) for i, p, l in files if p.lower().endswith('.mkv')]


def parse_episodes(filename):
    """
    Ze jména souboru vrátí seznam čísel epizod (int).
    Vrátí None pokud nezjistíme.
    """
    base = os.path.basename(filename)
    if 'shippuden' not in base.lower():
        return None
    m = DOUBLE_RE.search(base)
    if m:
        return [int(m.group(1)), int(m.group(2))]
    m = SINGLE_RE.search(base)
    if m:
        return [int(m.group(1))]
    return None


def build_map(files):
    candidate_files = [(i, p, l) for i, p, l in files
                       if l >= MIN_ELEMENTUM_CANDIDATE_SIZE]
    sorted_paths = sorted(p for _, p, _ in candidate_files)
    path2eidx = {p: i for i, p in enumerate(sorted_paths)}

    e2idx = {}
    e2oidx = {}
    idx2e = {}
    oidx2e = {}

    for torrent_index, path, _ in candidate_files:
        ep_nums = parse_episodes(path)
        if ep_nums is None:
            continue
        eidx = path2eidx[path]
        eidx_str = str(eidx)
        oidx_str = str(torrent_index)
        if eidx_str not in idx2e:
            idx2e[eidx_str] = []
        if oidx_str not in oidx2e:
            oidx2e[oidx_str] = []
        for ep_num in ep_nums:
            key = f"E{ep_num:03d}"
            e2idx[key] = eidx
            e2oidx[key] = torrent_index
            if key not in idx2e[eidx_str]:
                idx2e[eidx_str].append(key)
            if key not in oidx2e[oidx_str]:
                oidx2e[oidx_str].append(key)

    return e2idx, idx2e, e2oidx, oidx2e


def main():
    script_dir      = os.path.dirname(os.path.abspath(__file__))
    default_torrent = os.path.join(script_dir, 'naruto-shippuden.torrent')
    default_json    = os.path.join(script_dir, 'map.json')

    ap = argparse.ArgumentParser(description='Naruto Shippuden – generátor mapy epizod')
    ap.add_argument('--torrent', '-t', default=default_torrent)
    ap.add_argument('--out-json', default=default_json)
    args = ap.parse_args()

    if not os.path.isfile(args.torrent):
        print(f"Chybí soubor: {args.torrent}")
        raise SystemExit(2)

    files = load_files(args.torrent)
    if not files:
        print("V torrentu nejsou žádné .mkv soubory.")
        raise SystemExit(3)

    print(f"Nalezeno souborů: {len(files)}")
    e2idx, idx2e, e2oidx, oidx2e = build_map(files)

    with open(args.out_json, 'w', encoding='utf-8') as f:
        json.dump({'e2idx': e2idx, 'idx2e': idx2e, 'e2oidx': e2oidx, 'oidx2e': oidx2e}, f, ensure_ascii=False, indent=2)

    print(f"Mapa vytvořena: {len(e2idx)} epizod namapováno -> {args.out_json}")

    doubles = [(k, v) for k, v in idx2e.items() if len(v) > 1]
    if doubles:
        print(f"\nDouble-epizody ({len(doubles)}):")
        for eidx, keys in sorted(doubles, key=lambda x: int(x[0]))[:5]:
            print(f"  Elementum [{eidx}] -> {', '.join(sorted(keys))}")


if __name__ == '__main__':
    main()
