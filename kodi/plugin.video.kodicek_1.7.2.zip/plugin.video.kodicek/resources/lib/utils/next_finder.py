# -*- coding: utf-8 -*-
from resources.lib import tmdb

def compute_next_episode(tmdb_id: int, season: int, episode: int):
    from resources.lib.utils.logger import log
    show = tmdb.get_show_details(tmdb_id)
    if not show:
        log.warning("next_finder", "get_show_details vrátil None pro tmdb_id={}", tmdb_id)
        return None
    tvshowtitle = show.get('name') or show.get('original_name') or ""
    episodes = tmdb.get_season_episodes(tmdb_id, season) or []
    log.debug("next_finder", "S{}E{}: {} epizod v sezóně, episode_numbers={}", season, episode,
              len(episodes), [ep.get('episode_number') for ep in episodes[:5]])

    # Najdi aktuální epizodu podle episode_number (ne podle indexu)
    current_idx = next((i for i, ep in enumerate(episodes)
                        if ep.get('episode_number') == episode), None)
    if current_idx is None:
        log.warning("next_finder", "Epizoda S{}E{} nenalezena v TMDb listu", season, episode)
        return None

    if current_idx + 1 < len(episodes):
        nxt = episodes[current_idx + 1]
        nxt_ep_num = nxt.get('episode_number', episode + 1)
        log.debug("next_finder", "Další epizoda: S{}E{}", season, nxt_ep_num)
        return _meta(tvshowtitle, season, nxt_ep_num, nxt)

    next_season = season + 1
    if tmdb.season_exists(tmdb_id, next_season):
        eps2 = tmdb.get_season_episodes(tmdb_id, next_season) or []
        if eps2:
            nxt = eps2[0]
            nxt_ep_num = nxt.get('episode_number', 1)
            log.debug("next_finder", "Přechod na sezónu {}, epizoda {}", next_season, nxt_ep_num)
            return _meta(tvshowtitle, next_season, nxt_ep_num, nxt)
    log.debug("next_finder", "Žádná další epizoda po S{}E{}", season, episode)
    return None

def _meta(tvshowtitle, season, episode, tmdb_ep):
    title = tmdb_ep.get('name') or ""
    plot = tmdb_ep.get('overview') or ""
    duration = int(tmdb_ep.get('runtime') or 0) * 60
    art = {
        "thumb":  tmdb.image_url(tmdb_ep.get('still_path')),
        "poster": tmdb.image_url(tmdb_ep.get('poster_path') or tmdb_ep.get('show_poster')),
        "fanart": tmdb.image_url(tmdb_ep.get('backdrop_path') or tmdb_ep.get('show_backdrop')),
    }
    art = {k: v for k, v in art.items() if v}
    return {
        "tvshowtitle": tvshowtitle,
        "title": title,
        "season": int(season),
        "episode": int(episode),
        "plot": plot,
        "duration": duration,
        "art": art,
    }
