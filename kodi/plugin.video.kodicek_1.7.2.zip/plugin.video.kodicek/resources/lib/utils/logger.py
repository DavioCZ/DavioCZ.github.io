# -*- coding: utf-8 -*-
"""
Centralizovaný logger pro Kodíček plugin.
Formát: [Kodíček:{modul}] {zpráva}

Použití:
    from resources.lib.utils.logger import log
    log.info("router", "Spouštím vyhledávání pro: {}", query)
    log.debug("scoring", "Soubor '{}' skóre: {:.1f}", fname, score)
    log.error("webshare", "API call selhalo: {}", e)
"""

import xbmc
import xbmcaddon
import time

_PREFIX = "Kodíček"

# Map our levels to xbmc levels
_LEVEL_MAP = {
    "debug": xbmc.LOGDEBUG,
    "info": xbmc.LOGINFO,
    "warning": xbmc.LOGWARNING,
    "error": xbmc.LOGERROR,
}


def _is_debug_enabled():
    """Check if debug logging is enabled in plugin settings."""
    try:
        return xbmcaddon.Addon().getSetting("debug_logging") == "true"
    except Exception:
        return False


def _log(level_name, module, msg, *args):
    """Core logging function."""
    xbmc_level = _LEVEL_MAP.get(level_name, xbmc.LOGINFO)

    # Skip debug messages if debug logging is not enabled
    if xbmc_level == xbmc.LOGDEBUG and not _is_debug_enabled():
        return

    try:
        if args:
            formatted = msg.format(*args)
        else:
            formatted = msg
    except (IndexError, KeyError):
        formatted = f"{msg} (log format error, args={args})"

    xbmc.log(f"[{_PREFIX}:{module}] {formatted}", level=xbmc_level)


class _Logger:
    """Logger instance with convenience methods."""

    def debug(self, module, msg, *args):
        _log("debug", module, msg, *args)

    def info(self, module, msg, *args):
        _log("info", module, msg, *args)

    def warning(self, module, msg, *args):
        _log("warning", module, msg, *args)

    def error(self, module, msg, *args):
        _log("error", module, msg, *args)

    def api_call(self, module, endpoint, params=None, result_count=None, duration_ms=None):
        """Log an API call with standardized format."""
        parts = [f"API {endpoint}"]
        if params:
            # Filter out sensitive data
            safe_params = {k: v for k, v in params.items() if k not in ('password', 'wst')}
            if safe_params:
                parts.append(f"params={safe_params}")
        if result_count is not None:
            parts.append(f"results={result_count}")
        if duration_ms is not None:
            parts.append(f"time={duration_ms}ms")
        _log("debug", module, " | ".join(parts))

    def scoring(self, module, filename, score, breakdown):
        """Log scoring details for a file."""
        _log("debug", module, "SCORE {:.1f} | {} | {}", score, filename, breakdown)


# Singleton instance
log = _Logger()
