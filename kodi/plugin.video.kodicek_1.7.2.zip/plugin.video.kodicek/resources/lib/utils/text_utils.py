# -*- coding: utf-8 -*-
"""
Text normalization utilities for Kodíček.
Single source of truth for all text normalization used in search and matching.
"""

import re
import unidecode

def normalize_for_matching(text):
    """Normalize text for substring/regex matching against Webshare filenames.

    Pipeline:
      1. unidecode  – removes all diacritics (CZ/SK/DE/…) via transliteration
      2. lowercase
      3. separators (. _ -) → single space  (filenames use dots, titles use spaces)
      4. strip non-alphanumeric except spaces
      5. collapse repeated spaces and trim

    Examples:
      "Jurský park"              → "jursky park"
      "Jurský.Park.1993.1080p"   → "jursky park 1993 1080p"
      "Game.of.Thrones.S01E01"   → "game of thrones s01e01"
      "Hra o trůny"              → "hra o truny"
    """
    if not text:
        return ""
    text = unidecode.unidecode(text)
    text = text.lower()
    text = re.sub(r'[._\-]+', ' ', text)
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def normalize_for_display(text):
    """Normalize text for display in Kodi UI.

    Keeps diacritics and unicode, just trims whitespace and collapses
    internal multiple spaces. Does not lowercase.

    Examples:
      "  Jurský  park  "   → "Jurský park"
      "Game of Thrones"    → "Game of Thrones"
    """
    if not text:
        return ""
    return " ".join(text.split())


if __name__ == '__main__':
    # Quick sanity tests – run with: python text_utils.py
    tests = [
        ("Jurský park", "jursky park"),
        ("Jurský.Park.1993.1080p.CZE.mkv", "jursky park 1993 1080p cze mkv"),
        ("Game.of.Thrones.S01E01.720p", "game of thrones s01e01 720p"),
        ("Hra o trůny", "hra o truny"),
        ("Hänschen.klein", "hanschen klein"),
        ("", ""),
        (None, ""),
    ]
    all_ok = True
    for inp, expected in tests:
        result = normalize_for_matching(inp)
        status = "OK" if result == expected else f"FAIL (got '{result}')"
        print(f"  {status}: normalize_for_matching({inp!r}) → '{result}'")
        if result != expected:
            all_ok = False
    print("All tests passed." if all_ok else "SOME TESTS FAILED.")
