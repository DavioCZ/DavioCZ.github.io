# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import xbmcaddon

# Manually add the addon's root to the Python path
addon_path = xbmcaddon.Addon().getAddonInfo('path')
if addon_path not in sys.path:
    sys.path.insert(0, addon_path)

import xbmc
import xbmcplugin
import xbmcgui
import xbmcvfs
import requests
import hashlib
import time
import json
import re
from xml.etree import ElementTree as ET
from resources.lib.utils import md5crypt
from resources.lib.utils.logger import log
from resources.lib.utils.text_utils import normalize_for_matching

# Základní proměnné a session
addon = xbmcaddon.Addon()
plugin_name = "Kodíček"
WEBSHARE_API_BASE_URL = "https://webshare.cz/api/"
TMDB_API_BASE_URL = "https://api.themoviedb.org/3/"

_session = requests.Session()
_session.headers.update({'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"})

MOD = "pm"  # module name for logging
_LAST_STREAM_ERROR = {"code": None, "message": None}

# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

# 4.1  In-memory Webshare search cache
_SEARCH_CACHE_TTL = 600   # 10 minutes
_SEARCH_CACHE_MAX = 50
_search_cache = {}        # key: (token_prefix, query) → {'results': list, 'ts': float}

def clear_search_cache():
    """Invalidate all cached Webshare search results (call after re-login)."""
    global _search_cache
    _search_cache = {}
    log.debug(MOD, "Webshare search cache cleared")

def _ws_cache_get(token, query):
    key = (token[:8] if token else '', query)
    entry = _search_cache.get(key)
    if entry and (time.time() - entry['ts']) < _SEARCH_CACHE_TTL:
        return entry['results']
    return None

def _ws_cache_set(token, query, results):
    if len(_search_cache) >= _SEARCH_CACHE_MAX:
        oldest = min(_search_cache, key=lambda k: _search_cache[k]['ts'])
        del _search_cache[oldest]
    key = (token[:8] if token else '', query)
    _search_cache[key] = {'results': results, 'ts': time.time()}


# 4.2  Persistent TMDb response cache (JSON file, TTL 1 hour)
_TMDB_CACHE_TTL = 3600    # 1 hour
_tmdb_cache = None        # lazy-loaded from file

def _tmdb_cache_path():
    return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.kodicek/tmdb_cache.json')

def _load_tmdb_cache():
    global _tmdb_cache
    if _tmdb_cache is not None:
        return _tmdb_cache
    path = _tmdb_cache_path()
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            # Evict stale entries on load to keep the file small
            now = time.time()
            _tmdb_cache = {k: v for k, v in raw.items()
                           if now - v.get('ts', 0) < _TMDB_CACHE_TTL}
        else:
            _tmdb_cache = {}
    except Exception as e:
        log.warning(MOD, "TMDb cache load error: {}", e)
        _tmdb_cache = {}
    return _tmdb_cache

def _save_tmdb_cache():
    path = _tmdb_cache_path()
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(_tmdb_cache, f, ensure_ascii=False)
    except Exception as e:
        log.warning(MOD, "TMDb cache save error: {}", e)

def _tmdb_cache_key(endpoint, params):
    return f"{endpoint}|{json.dumps(params, sort_keys=True) if params else ''}"


# --- API helper functions ---

def api_call(endpoint, data=None, method='post', base_url=WEBSHARE_API_BASE_URL):
    url = base_url + endpoint
    if base_url == WEBSHARE_API_BASE_URL and not endpoint.endswith('/'):
        url += "/"

    timeout_s = 4 if endpoint == 'file_link' else 10
    t0 = time.time()
    last_exc = None
    for attempt in range(2):  # 1 attempt + 1 retry
        if attempt > 0:
            time.sleep(1)
            log.warning(MOD, "API retry #{} for {}", attempt, url)
        try:
            if method == 'post':
                response = _session.post(url, data=data, timeout=timeout_s)
            else:
                response = _session.get(url, params=data, timeout=timeout_s)
            response.raise_for_status()
            duration_ms = int((time.time() - t0) * 1000)
            log.api_call(MOD, endpoint, data, duration_ms=duration_ms)
            return response.content
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            last_exc = e
            if endpoint == 'file_link':
                _LAST_STREAM_ERROR["code"] = "TIMEOUT"
                _LAST_STREAM_ERROR["message"] = str(e)
        except requests.exceptions.RequestException as e:
            duration_ms = int((time.time() - t0) * 1000)
            log.error(MOD, "API call to {} failed after {}ms: {}", url, duration_ms, e)
            return None
    duration_ms = int((time.time() - t0) * 1000)
    log.error(MOD, "API call to {} failed after {}ms (2 attempts): {}", url, duration_ms, last_exc)
    return None

def is_xml_ok(xml_root):
    if xml_root is None:
        return False
    status_node = xml_root.find('status')
    if status_node is not None and status_node.text == 'OK':
        return True
    message_node = xml_root.find('message')
    error_message = message_node.text if message_node is not None else "Unknown API error"

    if "File temporarily unavailable" in error_message:
        log.warning(MOD, "Soubor dočasně nedostupný: {}", error_message)
    else:
        log.error(MOD, "API response not OK: {}", error_message)

    return False


def reset_last_stream_error():
    _LAST_STREAM_ERROR["code"] = None
    _LAST_STREAM_ERROR["message"] = None


def get_last_stream_error():
    return dict(_LAST_STREAM_ERROR)

def search_webshare(token, query):
    cached = _ws_cache_get(token, query)
    if cached is not None:
        log.debug(MOD, "WS cache HIT: '{}' → {} výsledků", query, len(cached))
        return cached

    search_params = {
        'wst': token,
        'what': query,
        'category': 'video',
        'limit': 100,
        'sort': 'rating'
    }
    log.info(MOD, "Webshare search: query='{}', limit=100", query)
    t0 = time.time()
    search_response_content = api_call('search', search_params, method='post', base_url=WEBSHARE_API_BASE_URL)

    if not search_response_content:
        log.warning(MOD, "Webshare search vrátil prázdnou odpověď pro: '{}'", query)
        return []
    try:
        search_xml = ET.fromstring(search_response_content)
    except ET.ParseError as e:
        log.error(MOD, "Failed to parse search XML: {}. Response: {}", e, search_response_content[:200])
        return []
    if not is_xml_ok(search_xml):
        return []
    files_list = []
    for file_elem in search_xml.iter('file'):
        file_data = {
            'ident': file_elem.findtext('ident'),
            'name': file_elem.findtext('name'),
            'size': int(file_elem.findtext('size', '0')),
        }
        if file_data['ident'] and file_data['name']:
            files_list.append(file_data)

    duration_ms = int((time.time() - t0) * 1000)
    log.info(MOD, "Webshare search: query='{}' → {} výsledků ({}ms)", query, len(files_list), duration_ms)
    _ws_cache_set(token, query, files_list)
    return files_list

def verify_token(token):
    """Verify if a Webshare token is valid by calling user_data endpoint."""
    if not token:
        return False, "Token je prázdný"
    response = api_call('user_data', {'wst': token}, method='post', base_url=WEBSHARE_API_BASE_URL)
    if not response:
        return False, "API neodpovídá"
    try:
        xml = ET.fromstring(response)
    except ET.ParseError:
        return False, "Neplatná XML odpověď"
    if not is_xml_ok(xml):
        return False, "Token neplatný"
    # Extract VIP status
    vip_node = xml.find('vip')
    vip_status = vip_node.text if vip_node is not None else "unknown"
    ident_node = xml.find('ident')
    username_node = xml.find('username')
    log.info(MOD, "Token platný: user='{}', vip={}",
             username_node.text if username_node is not None else "?", vip_status)
    return True, vip_status

def _is_valid_stream_url(url):
    """Validates that a stream URL is actually usable, not an error redirect."""
    if not url:
        return False
    # Webshare returns URLs with ?error= or /error= when something goes wrong
    if 'error=' in url or '?error' in url:
        return False
    # A valid stream URL should be https:// pointing to a CDN, not http://webshare.cz/file/
    if 'webshare.cz/file/' in url:
        return False
    return True

def get_stream_link(token, ident):
    reset_last_stream_error()
    possible_params = [
        {'wst': token, 'ident': ident, 'download_type': 'video_stream'},
        {'wst': token, 'ident': ident, 'download_type': 'file_download'},
        {'wst': token, 'ident': ident}
    ]
    for i, link_params in enumerate(possible_params):
        dl_type = link_params.get('download_type', 'default')
        log.info(MOD, "get_stream_link: pokus {}/3 (type={}, ident={})", i+1, dl_type, ident)
        link_response_content = api_call('file_link', link_params, method='post', base_url=WEBSHARE_API_BASE_URL)
        if not link_response_content:
            log.warning(MOD, "file_link: prázdná odpověď (type={})", dl_type)
            continue
        # Log raw XML for diagnostics (first 500 chars)
        log.info(MOD, "file_link raw response (type={}): {}", dl_type, link_response_content[:500] if isinstance(link_response_content, str) else link_response_content.decode('utf-8', errors='replace')[:500])
        try:
            link_xml = ET.fromstring(link_response_content)
        except ET.ParseError as e:
            log.error(MOD, "file_link: XML parse error: {}", e)
            continue
        code_node = link_xml.find('code')
        message_node = link_xml.find('message')
        _LAST_STREAM_ERROR["code"] = code_node.text if code_node is not None else None
        _LAST_STREAM_ERROR["message"] = message_node.text if message_node is not None else None
        if not is_xml_ok(link_xml):
            log.warning(MOD, "file_link: status not OK (type={})", dl_type)
            continue
        link_node = link_xml.find('link')
        if link_node is not None and link_node.text:
            stream_url = link_node.text.strip()
            log.info(MOD, "file_link: URL vrácena (type={}): {}", dl_type, stream_url[:200])
            if _is_valid_stream_url(stream_url):
                log.info(MOD, "Stream link PLATNÝ (type={}): ident={}", dl_type, ident)
                return stream_url
            else:
                log.warning(MOD, "Stream link NEPLATNÝ (type={}): obsahuje error/redirect", dl_type)
                continue
        else:
            log.warning(MOD, "file_link: XML neobsahuje <link> element (type={})", dl_type)
    log.error(MOD, "Nepodařilo se získat stream link pro ident: {} (všechny 3 pokusy selhaly)", ident)
    return None


def is_temporarily_unavailable_error():
    code = (_LAST_STREAM_ERROR.get("code") or "").upper()
    message = (_LAST_STREAM_ERROR.get("message") or "").lower()
    return code == "FILE_LINK_FATAL_4" or "temporarily unavailable" in message


def is_timeout_stream_error():
    code = (_LAST_STREAM_ERROR.get("code") or "").upper()
    message = (_LAST_STREAM_ERROR.get("message") or "").lower()
    return code == "TIMEOUT" or "timed out" in message or "timeout" in message


def build_episode_queries(show_title, season, episode, ep_title=None, year=None):
    cleaned_show_title = show_title.replace('*', '')
    ep_title = ep_title or ""
    show_title = " ".join(cleaned_show_title.split())
    ep_title = " ".join(ep_title.split())

    s_full = f"{season:02d}"
    s_short = str(season)
    e_full = f"{episode:02d}"
    e_short = str(episode)

    code_formats = [
        f"S{s_full}E{e_full}", f"{s_full}x{e_full}",
        f"S{s_short}E{e_short}", f"{s_short}x{e_short}",
    ]

    potential_queries = []
    if year and ep_title:
        for code in code_formats[:2]:
            potential_queries.append(f"{show_title} {code} {ep_title} {year}")
    if ep_title:
        for code in code_formats:
            potential_queries.append(f"{show_title} {code} {ep_title}")
    if year:
        for code in code_formats:
            potential_queries.append(f"{show_title} {code} {year}")
    for code in code_formats:
        potential_queries.append(f"{show_title} {code}")

    final_queries = []
    seen_queries = set()
    for q_str in potential_queries:
        normalized_q_str = " ".join(q_str.split())
        if normalized_q_str and normalized_q_str not in seen_queries:
            final_queries.append(normalized_q_str)
            seen_queries.add(normalized_q_str)

    log.debug(MOD, "build_episode_queries: show='{}' S{}E{} → {} queries", show_title, season, episode, len(final_queries))
    return final_queries

def filter_episode_results(files, show_title, season, episode):
    norm_show = normalize_for_matching(show_title)
    regex_patterns = [
        r'\bs0?%s\s?[e\.]0?%s\b' % (season, episode),
        r'\b0?%s\s?x\s?0?%s\b' % (season, episode)
    ]
    combined_regex = re.compile('|'.join(regex_patterns), re.IGNORECASE)

    out = []
    for f_item in files:
        fname_normalized = normalize_for_matching(f_item['name'])
        if norm_show not in fname_normalized:
            continue
        if combined_regex.search(fname_normalized):
            out.append(f_item)

    log.debug(MOD, "filter_episode_results: show='{}' S{}E{} → {}/{} prošlo filtrem", show_title, season, episode, len(out), len(files))
    return out

def tmdb_api_request(api_key, endpoint, params=None, method='get'):
    if not api_key:
        log.error(MOD, "TMDb API key chybí pro request: {}", endpoint)
        return None

    # Cache lookup (GET requests only)
    if method == 'get':
        cache = _load_tmdb_cache()
        key = _tmdb_cache_key(endpoint, params)
        entry = cache.get(key)
        if entry and (time.time() - entry.get('ts', 0)) < _TMDB_CACHE_TTL:
            log.debug(MOD, "TMDb cache HIT: {}", endpoint)
            return entry['data']

    url = f"{TMDB_API_BASE_URL}{endpoint.lstrip('/')}"
    all_params = {'api_key': api_key}
    if params:
        all_params.update(params)
    t0 = time.time()
    last_exc = None
    for attempt in range(2):  # 1 attempt + 1 retry
        if attempt > 0:
            time.sleep(1)
            log.warning(MOD, "TMDb retry #{} for {}", attempt, url)
        try:
            if method == 'get':
                response = _session.get(url, params=all_params, timeout=10)
            else:
                return None
            response.raise_for_status()
            duration_ms = int((time.time() - t0) * 1000)
            result = response.json()
            log.api_call(MOD, f"TMDb {endpoint}", params, duration_ms=duration_ms)

            # Store in cache
            cache[key] = {'data': result, 'ts': time.time()}
            _save_tmdb_cache()

            return result
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            last_exc = e
        except requests.exceptions.RequestException as e:
            duration_ms = int((time.time() - t0) * 1000)
            log.error(MOD, "TMDb API call to {} failed after {}ms: {}", url, duration_ms, e)
            return None
        except json.JSONDecodeError as e:
            log.error(MOD, "Failed to parse TMDb JSON from {}: {}", url, e)
            return None
    duration_ms = int((time.time() - t0) * 1000)
    log.error(MOD, "TMDb API call to {} failed after {}ms (2 attempts): {}", url, duration_ms, last_exc)
    return None

def get_all_episode_sources(token, tmdb_id, season_number, episode_number, show_title, show_year):
    """Find Webshare sources for an episode.

    Strategy:
    1. Broad query (show + SxxExx) → filter locally. Fast: usually 1 API call.
    2. If 0 results: fallback through specific queries (with ep title / year).
    """
    api_key = addon.getSetting("tmdb_api_key")
    episode_name_cs = ""
    episode_name_en = ""

    log.info(MOD, "get_all_episode_sources: show='{}' S{}E{} tmdb_id={}", show_title, season_number, episode_number, tmdb_id)

    if api_key:
        ep_details_cs = tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}/episode/{episode_number}", {'language': 'cs-CZ'})
        if ep_details_cs and ep_details_cs.get('name'):
            episode_name_cs = ep_details_cs.get('name')
        ep_details_en = tmdb_api_request(api_key, f"/tv/{tmdb_id}/season/{season_number}/episode/{episode_number}", {'language': 'en-US'})
        if ep_details_en and ep_details_en.get('name'):
            episode_name_en = ep_details_en.get('name')

    episode_name_for_search = episode_name_cs if episode_name_cs else episode_name_en
    log.debug(MOD, "Episode name for search: cs='{}' en='{}' → using '{}'", episode_name_cs, episode_name_en, episode_name_for_search)

    # --- Broad-first: single query, local filter (typically 1 API call) ---
    broad_query = f"{show_title} S{season_number:02d}E{episode_number:02d}"
    log.debug(MOD, "Episode broad query: '{}'", broad_query)
    broad_results = search_webshare(token, broad_query)
    filtered = filter_episode_results(broad_results, show_title, season_number, episode_number)
    if filtered:
        log.info(MOD, "Episode search: {} zdrojů (broad query úspěšný)", len(filtered))
        return filtered

    # --- Fallback: remaining queries from build_episode_queries ---
    fallback_queries = build_episode_queries(show_title, season_number, episode_number, episode_name_for_search, show_year)
    fallback_queries = [q for q in fallback_queries if q != broad_query]
    log.debug(MOD, "Episode broad query nenalezl nic, zkoušíme {} fallback queries", len(fallback_queries))

    all_by_ident = {}
    for i, query in enumerate(fallback_queries):
        log.debug(MOD, "Episode fallback query {}/{}: '{}'", i + 1, len(fallback_queries), query)
        results = search_webshare(token, query)
        for f in filter_episode_results(results, show_title, season_number, episode_number):
            if f['ident'] not in all_by_ident:
                all_by_ident[f['ident']] = f
        if all_by_ident:
            log.info(MOD, "Episode search: {} zdrojů po fallback query #{}: '{}'", len(all_by_ident), i + 1, query)
            break

    webshare_files = list(all_by_ident.values())
    if not webshare_files:
        log.warning(MOD, "Episode search: žádné zdroje nalezeny pro '{}' S{}E{}", show_title, season_number, episode_number)
    return webshare_files
