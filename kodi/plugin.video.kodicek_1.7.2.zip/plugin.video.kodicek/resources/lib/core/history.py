import xbmcvfs
import io
import json
import xbmcaddon
import os
import xbmc
from resources.lib.utils.logger import log

_MOD = "history"

# For maximum compatibility (all platforms)
try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

PROFILE = translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
HISTORY_FILE = os.path.join(PROFILE, "history.json")
SEARCH_HISTORY_FILE = os.path.join(PROFILE, "search_history.json")
MAX_HISTORY = 100
MAX_SEARCH_HISTORY = 50

def ensure_profile_dir():
    """Ensures the profile directory exists."""
    if not xbmcvfs.exists(PROFILE):
        log.debug(_MOD, "Profile directory does not exist, creating: {}", PROFILE)
        if xbmcvfs.mkdirs(PROFILE):
            log.debug(_MOD, "Created profile directory: {}", PROFILE)
        else:
            log.error(_MOD, "Failed to create profile directory: {}", PROFILE)

def load_history():
    """Loads the playback history from the JSON file."""
    ensure_profile_dir()
    if not xbmcvfs.exists(HISTORY_FILE):
        log.debug(_MOD, "Playback history file does not exist: {}", HISTORY_FILE)
        return []
    try:
        with io.open(HISTORY_FILE, 'r', encoding='utf8') as f:
            history_data = json.load(f)
            log.debug(_MOD, "Loaded playback history: {} items", len(history_data))
            return history_data
    except Exception as e:
        log.error(_MOD, "Error loading playback history: {}", e)
        try:
            if xbmcvfs.delete(HISTORY_FILE):
                log.warning(_MOD, "Deleted corrupted playback history file")
            else:
                log.error(_MOD, "Failed to delete corrupted playback history file")
        except Exception as delete_e:
            log.error(_MOD, "Error deleting corrupted history file: {}", delete_e)
        return []

def save_history(history):
    """Saves the playback history to the JSON file, limiting to MAX_HISTORY items."""
    ensure_profile_dir()
    try:
        with io.open(HISTORY_FILE, 'w', encoding='utf8') as f:
            json.dump(history[:MAX_HISTORY], f, ensure_ascii=False, indent=2)
        log.debug(_MOD, "Saved playback history: {} items", len(history[:MAX_HISTORY]))
    except Exception as e:
        log.error(_MOD, "Error saving playback history: {}", e)

def add_to_history(item):
    """Adds an item to the playback history, ensuring no duplicates based on 'ident'."""
    history = load_history()
    item_ident = item.get('ident')
    if item_ident is not None:
        history = [h for h in history if h.get('ident') != item_ident]
    else:
        log.warning(_MOD, "Item missing 'ident': {}", item.get('name', 'Unknown'))
    history.insert(0, item)
    save_history(history)

# --- Search History Functions ---

def load_search_history():
    """Loads the search history from the JSON file."""
    ensure_profile_dir()
    if not xbmcvfs.exists(SEARCH_HISTORY_FILE):
        log.debug(_MOD, "Search history file does not exist")
        return []
    try:
        with io.open(SEARCH_HISTORY_FILE, 'r', encoding='utf8') as f:
            search_history_data = json.load(f)
            log.debug(_MOD, "Loaded search history: {} items", len(search_history_data))
            return search_history_data
    except Exception as e:
        log.error(_MOD, "Error loading search history: {}", e)
        try:
            if xbmcvfs.delete(SEARCH_HISTORY_FILE):
                log.warning(_MOD, "Deleted corrupted search history file")
            else:
                log.error(_MOD, "Failed to delete corrupted search history file")
        except Exception as delete_e:
            log.error(_MOD, "Error deleting corrupted search history file: {}", delete_e)
        return []

def save_search_history(search_history):
    """Saves the search history to the JSON file, limiting to MAX_SEARCH_HISTORY items."""
    ensure_profile_dir()
    try:
        with io.open(SEARCH_HISTORY_FILE, 'w', encoding='utf8') as f:
            json.dump(search_history[:MAX_SEARCH_HISTORY], f, ensure_ascii=False, indent=2)
        log.debug(_MOD, "Saved search history: {} items", len(search_history[:MAX_SEARCH_HISTORY]))
    except Exception as e:
        log.error(_MOD, "Error saving search history: {}", e)

def add_to_search_history(item):
    """Adds a search query item to the search history."""
    search_history = load_search_history()
    current_query = item.get('query')
    if current_query is not None:
        search_history = [h for h in search_history if h.get('query') != current_query]
    else:
        log.warning(_MOD, "Search item missing 'query': {}", item)
        return
    search_history.insert(0, item)
    save_search_history(search_history)
