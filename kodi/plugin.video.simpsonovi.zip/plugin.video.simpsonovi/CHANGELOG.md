# Changelog – The Simpsons (Elementum)

Všechny významné změny v tomto projektu budou dokumentovány v tomto souboru.

Formát je založen na [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) a projekt dodržuje [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
### Fixed
- **Spolehlivost přehrávání**: Opraveno nesprávné kódování URL adresy předávané do Elementum, které způsobovalo ztrátu informací o vybraném souboru a vedlo k zobrazení dialogu pro výběr souboru.
- **Výběr souboru v Elementum**: Opraven problém, kdy se po kliknutí na epizodu zobrazil dialog pro výběr souboru místo přímého přehrávání. Do URL pro Elementum byla přidána **metadata o seriálu**, aby se přehrávání spustilo automaticky.
- **Přehrávání z torrentu**: Opravena chyba, která bránila spuštění přehrávání kvůli nesprávnému formátu cesty k `.torrent` souboru předávané přehrávači Elementum.
- **Integrace s "Up Next"**: Opraven problém, kdy služba "Up Next" nesprávně identifikovala přehrávanou epizodu. Do přehrávané položky byla přidána **metadata (číslo série a epizody)**, což zajišťuje správnou funkci automatického přehrávání další epizody.
### Added
- **Interní dokumentace**: Vytvořen soubor `DOCUMENTATION.md`, který podrobně popisuje princip fungování doplňku, jeho architekturu a komunikaci s Elementum.

## [0.1.0] - 2025-07-15
### Added
- **Základní struktura** repozitáře (`.gitignore`, `README.md`, `CHANGELOG.md`, `TASK_LIST.md`).
- **Skeleton addonu** (`addon.xml`) s metadaty a závislostmi.
- **Základní router** v `default.py` pro procházení **Série** → **Epizoda**.
- **Přehrávání epizod** přes `plugin.video.elementum` s pevně daným info-hashem.
### Changed
- **Zásadní změna logiky přehrávání**: Doplněk již negeneruje `magnet:` linky. Místo toho předává Elementu přímo cestu k lokálnímu `.torrent` souboru a název souboru epizody. Tím se eliminuje zpoždění a chyby při získávání metadat z DHT sítě.

### Fixed
- **Přehrávání správné epizody**: Opravena chyba, kdy Elementum přehrávalo jinou epizodu, než která byla vybrána. Změněn parametr `index` na `oindex` pro zajištění **správného výběru souboru** na základě původního pořadí v torrentu.
- **Oprava přehrávání na Windows**: Vyřešen problém s dvojitým kódováním URL a chybným parsováním parametrů, který bránil přehrávání na platformě Windows. Přehrávání je nyní stabilní.
- **Spolehlivá detekce epizod**: Nahrazena nespolehlivá metoda pro parsování názvů souborů **regulárním výrazem**. Tím je zajištěna přesná identifikace série a epizody, což opravuje chyby při přehrávání.
- **Výběr souboru**: Opraven problém, kdy se po kliknutí na epizodu zobrazil dialog pro výběr souboru místo přímého přehrávání. Do URL pro Elementum byl přidán **index souboru**, aby se přehrávání spustilo automaticky.
- **Stabilita a spolehlivost**: Kompletně vyřešeny problémy způsobující pád aplikace a zamrzání při spouštění přehrávání.
- **Dynamické epizody**: Seznam epizod a jejich názvy se nyní dynamicky načítají z metadat `.torrent` souboru.
- **Oprava cesty k doplňku**: Nahrazeno nespolehlivé volání `xbmc.translatePath` za moderní metodu `xbmcaddon.Addon().getAddonInfo('path')`.
