# resources/build_metadata.py
# -*- coding: utf-8 -*-
#
# Demon Slayer (Kimetsu no Yaiba) - build_metadata.py
# Stáhne metadata epizod z TMDB a uloží jako resources/metadata.json
#
# TMDB ID Demon Slayer: Kimetsu no Yaiba = 85937
#
# Naše lokální číslování sérií je souvislé (1, 2, 3 - bez mezer), ale
# neshoduje se s číslováním sezón na TMDB (tam chybí fansub torrent pro
# "Entertainment District Arc", takže TMDB sezóny mají jinou mezeru).
# Proto je tu explicitní mapování:
#   lokální série 1 (demonslayer_s01.torrent, 26 dílů)        -> TMDB sezóna 1
#   lokální série 2 (Kovárna mečů, 11 dílů)                   -> TMDB sezóna 4
#   lokální série 3 (Výcvik Hashirů, 8 dílů)                  -> TMDB sezóna 5
#
# Spuštění:
#   python3 resources/build_metadata.py

import json
import os
import re
import time
import argparse
import urllib.request
import urllib.parse

# TMDB vrací pro nepřeložené epizody placeholder "N. epizoda" / "Episode N" -
# v takovém případě chceme raději anglický název než neinformativní placeholder.
PLACEHOLDER_TITLE_RE = re.compile(r'^\s*(\d+\s*\.\s*epizoda|episode\s*\d+)\s*$', re.IGNORECASE)


def is_placeholder_title(title):
    return bool(title) and bool(PLACEHOLDER_TITLE_RE.match(title))

# ---------------------------------------------------------------------------
TMDB_API_KEY = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_SHOW_ID = 85937  # Kimetsu no Yaiba / Demon Slayer

# lokální_série -> TMDB_sezóna
LOCAL_TO_TMDB_SEASON = {
    1: 1,
    2: 4,
    3: 5,
}
# ---------------------------------------------------------------------------


def tmdb_get(endpoint, params=None):
    if params is None:
        params = {}
    params['api_key'] = TMDB_API_KEY
    url = f"{TMDB_BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        print(f"  Chyba {endpoint}: {e}")
        return None


def build_metadata():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, 'metadata.json')

    metadata = {}

    for local_season, tmdb_season in LOCAL_TO_TMDB_SEASON.items():
        print(f"Lokální série {local_season} <- TMDB sezóna {tmdb_season}...", end=' ', flush=True)

        s_cs = tmdb_get(f"/tv/{TMDB_SHOW_ID}/season/{tmdb_season}", {'language': 'cs-CZ'})
        s_en = tmdb_get(f"/tv/{TMDB_SHOW_ID}/season/{tmdb_season}", {'language': 'en-US'})
        time.sleep(0.25)

        if not s_cs:
            print("přeskočena (chyba)")
            continue

        en_map = {ep['episode_number']: ep for ep in s_en.get('episodes', [])} if s_en else {}
        ep_count = 0

        for ep_cs in s_cs.get('episodes', []):
            ep_num = ep_cs.get('episode_number')
            if ep_num is None:
                continue

            key = f"S{local_season:02d}E{ep_num:02d}"
            ep_en = en_map.get(ep_num, {})

            title_cs = ep_cs.get('name')
            title_en = ep_en.get('name')
            if title_cs and not is_placeholder_title(title_cs):
                title = title_cs
            else:
                title = title_en or title_cs or f"Epizoda {ep_num}"
            plot = ep_cs.get('overview') or ep_en.get('overview') or "Popis není k dispozici."
            path = ep_cs.get('still_path') or ep_en.get('still_path')
            thumb = f"https://image.tmdb.org/t/p/w500{path}" if path else ""

            metadata[key] = {'title': title, 'plot': plot, 'thumb': thumb}
            ep_count += 1

        print(f"{ep_count} ep")

    print(f"\nCelkem získáno: {len(metadata)} epizod")

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    print(f"Uloženo -> {output_file}")

    keys = sorted(metadata.keys())
    if keys:
        print(f"Rozsah: {keys[0]} – {keys[-1]}")


def main():
    ap = argparse.ArgumentParser(description="Demon Slayer – generátor metadat z TMDB")
    ap.parse_args()
    build_metadata()


if __name__ == '__main__':
    main()
