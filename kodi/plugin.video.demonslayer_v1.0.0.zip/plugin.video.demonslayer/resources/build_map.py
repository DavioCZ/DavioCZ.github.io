# resources/build_map.py
# -*- coding: utf-8 -*-
#
# Demon Slayer (Kimetsu no Yaiba) - build_map.py
# Generuje map.json ze tří torrent souborů (každý = jedna série).
#
# Soubory v torrentech nejsou pojmenované jako "SxxExx", ale např.:
#   "Kimetsu no Yaiba (Demon Slayer) - 01 (2160p) (Bilibili).mkv"
#   "Kimetsu no Yaiba - Katanakaji no Sato-hen - 01.mkv"
#   "Kimetsu no Yaiba - Hashira Geiko-hen - 01.mkv"
# Číslo epizody se vytahuje regexem a doplní se podle SEASON_NUM pro ten torrent.
#
# Výstup map.json:
#   {
#     "torrents":      { "1": "demonslayer_s01.torrent", ... },
#     "season_labels": { "S01": "Série 1", ... },
#     "e2idx":  { "S01E01": 1, "S01E02": 3, ... }   <- klíč -> Elementum index
#     "idx2e":  { "1": { "1": ["S01E01"], ... }, ... }
#   }

import io
import json
import os
import re
from collections import OrderedDict

EPISODE_RE = re.compile(r'-\s*(\d{1,2})(?:\s+END)?\s*[\(\.]')
VIDEO_EXTS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv'}

# (lokální_série, torrent_soubor)
# Fansub torrenty jsou značené S01 / S03 / S04 (chybí S02 - Entertainment
# District Arc), ale my je číslujeme souvisle 1, 2, 3, ať v Kodi nejsou
# mezery v číslování.
TORRENTS = [
    (1, "demonslayer_s01.torrent"),              # fansub S01 (26 dílů)
    (2, "demonslayer_s03_swordsmith.torrent"),   # fansub S03 - Kovárna mečů (11 dílů)
    (3, "demonslayer_s04_hashira.torrent"),       # fansub S04 - Výcvik Hashirů (8 dílů)
]

SEASON_LABELS = {
    "S01": "Série 1",
    "S02": "Série 2 – Kovárna mečů",
    "S03": "Série 3 – Výcvik Hashirů",
}


def bdecode(data: bytes):
    s = io.BytesIO(data)

    def r(n=1):
        b = s.read(n)
        if not b:
            raise ValueError("Unexpected EOF")
        return b

    def p():
        x = s.read(1)
        if not x:
            return b""
        s.seek(-1, 1)
        return x

    def parse():
        c = r(1)
        if c == b'i':
            num = b""
            ch = r(1)
            if ch == b'-':
                num += ch
                ch = r(1)
            while ch != b'e':
                num += ch
                ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e':
                out.append(parse())
            r(1)
            return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                d[bytes(k)] = parse()
            r(1)
            return d
        if b'0' <= c <= b'9':
            ln = c
            ch = r(1)
            while ch != b':':
                ln += ch
                ch = r(1)
            return r(int(ln))
        raise ValueError("Bad prefix: %r" % c)

    return parse()


def list_all_files(torrent_path):
    """Vrátí seznam VŠECH souborů v torrentu (abecedně, jak je indexuje Elementum)."""
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})

    all_files = []
    if b'files' in info:
        for f in info[b'files']:
            parts = [p.decode('utf-8', 'ignore') for p in f.get(b'path', [])]
            all_files.append('/'.join(parts))
    elif b'name' in info and b'length' in info:
        all_files.append(info[b'name'].decode('utf-8', 'ignore'))

    return sorted(all_files)


def parse_episode(filename):
    m = EPISODE_RE.search(os.path.basename(filename))
    if m:
        return int(m.group(1))
    return None


def build_map():
    script_dir = os.path.dirname(os.path.abspath(__file__))

    torrents_map = {}
    e2idx = {}
    idx2e = {}
    unmatched = []

    for season_num, torrent_file in TORRENTS:
        torrent_path = os.path.join(script_dir, torrent_file)
        if not os.path.isfile(torrent_path):
            print(f"Chybí torrent soubor: {torrent_path}")
            continue

        torrents_map[str(season_num)] = torrent_file

        sorted_all = list_all_files(torrent_path)
        idx2e[str(season_num)] = {}

        print(f"Série {season_num} ({torrent_file}): {len(sorted_all)} souborů v torrentu")

        for idx, path in enumerate(sorted_all):
            ext = os.path.splitext(path)[1].lower()
            if ext not in VIDEO_EXTS:
                continue
            ep_num = parse_episode(path)
            if ep_num is None:
                unmatched.append(f"{torrent_file}: {path}")
                continue
            key = f"S{season_num:02d}E{ep_num:02d}"
            e2idx[key] = idx
            idx2e[str(season_num)][str(idx)] = [key]

    data = {
        "torrents": torrents_map,
        "season_labels": SEASON_LABELS,
        "e2idx": e2idx,
        "idx2e": idx2e,
    }

    out_path = os.path.join(script_dir, "map.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"\nMapa vytvořena: {len(e2idx)} epizod -> {out_path}")
    for key in sorted(e2idx.keys()):
        print(f"  {key} -> Elementum index {e2idx[key]}")

    if unmatched:
        print(f"\nBez matche ({len(unmatched)}):")
        for p in unmatched:
            print(f"  {p}")


if __name__ == '__main__':
    build_map()
