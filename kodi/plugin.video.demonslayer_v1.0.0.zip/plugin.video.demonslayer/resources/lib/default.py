# -*- coding: utf-8 -*-
"""Kodi doplněk pro přehrávání seriálu Kimetsu no Yaiba (Demon Slayer) přes Elementum."""

import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

SHOW_NAME = "Demon Slayer"
DEFAULT_TORRENT_FILE = "demonslayer_s01.torrent"


def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def addon_path():
    return xbmcaddon.Addon().getAddonInfo("path")


def load_json(filename):
    try:
        path = os.path.join(addon_path(), "resources", filename)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as source:
                return json.load(source)
    except Exception as exc:
        xbmc.log(
            f"[demonslayer] Chyba při načítání {filename}: {exc}",
            level=xbmc.LOGWARNING,
        )
    return {}


def get_torrent_path(season_num, torrents_map):
    torrent_file = torrents_map.get(str(season_num), DEFAULT_TORRENT_FILE)
    return os.path.join(addon_path(), "resources", torrent_file), torrent_file


def list_episodes():
    """Zobrazí všechny epizody napříč všemi sériemi v jednom plochém seznamu."""
    xbmcplugin.setPluginCategory(_HANDLE, SHOW_NAME)
    xbmcplugin.setContent(_HANDLE, "episodes")

    data_map = load_json("map.json")
    e2idx = data_map.get("e2idx", {})
    torrents_map = data_map.get("torrents", {})
    metadata = load_json("metadata.json")

    episode_keys = sorted(e2idx.keys())

    if not episode_keys:
        xbmcgui.Dialog().notification(
            "Chyba",
            "map.json je prázdný nebo chybí.",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    torrent_uri_cache = {}

    for key in episode_keys:
        season_num = int(key[1:3])
        episode_num = int(key[4:6])

        if season_num not in torrent_uri_cache:
            torrent_path, torrent_file = get_torrent_path(season_num, torrents_map)
            if not os.path.exists(torrent_path):
                xbmcgui.Dialog().notification(
                    "Chyba",
                    f"Torrent soubor nenalezen: resources/{torrent_file}",
                    xbmcgui.NOTIFICATION_ERROR,
                )
                continue
            torrent_uri_cache[season_num] = urllib.parse.quote_plus(torrent_path)

        torrent_uri = torrent_uri_cache.get(season_num)
        if torrent_uri is None:
            continue

        metadata_item = metadata.get(key, {})
        title = metadata_item.get("title", f"Epizoda {episode_num}")
        plot = metadata_item.get("plot", "Popis není k dispozici.")
        thumb = metadata_item.get("thumb", "")
        display_title = f"{key} – {title}"

        elementum_url = (
            "plugin://plugin.video.elementum/play"
            f"?uri={torrent_uri}&index={e2idx[key]}"
        )
        play_url = (
            f"{_URL}?action=play&uri={urllib.parse.quote_plus(elementum_url)}"
        )

        item = xbmcgui.ListItem(label=display_title)
        item.setInfo(
            "video",
            {
                "title": display_title,
                "episode": episode_num,
                "season": season_num,
                "plot": plot,
                "tvshowtitle": SHOW_NAME,
                "mediatype": "episode",
            },
        )
        if thumb:
            item.setArt({"thumb": thumb, "icon": thumb, "fanart": thumb})
        item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            handle=_HANDLE, url=play_url, listitem=item, isFolder=False
        )

    xbmcplugin.endOfDirectory(_HANDLE)


def play_item(uri):
    item = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=item)


def router():
    params = get_params()
    action = params.get("action")

    if action == "play":
        play_item(urllib.parse.unquote_plus(params.get("uri", "")))
    else:
        list_episodes()


if __name__ == "__main__":
    router()
