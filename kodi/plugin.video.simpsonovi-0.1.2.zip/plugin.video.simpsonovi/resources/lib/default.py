# -*- coding: utf-8 -*-

import sys
import os
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import bencode

# Základní URL a handle pluginu
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])


def get_params():
    """
    Vrátí parametry pluginu jako slovník.
    """
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}

def list_seasons():
    """
    Zobrazí seznam sérií (1-34).
    """
    xbmcplugin.setPluginCategory(_HANDLE, "Série")
    for i in range(1, 35):
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i})
        url = f"{_URL}?action=list_episodes&season={i}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(_HANDLE)

def list_episodes(season):
    """
    Zobrazí seznam epizod pro danou sérii.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'simpsons.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        return

    with open(torrent_file_path, 'rb') as f:
        torrent_data = bencode.bdecode(f.read())
    
    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f[b'path']]
            files_in_torrent.append({'path': os.path.join(*path_parts), 'index': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'index': 0})

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")
    
    episode_items = []
    # Regex pro extrakci série a epizody (např. s01e01)
    episode_pattern = re.compile(r's(\d{2})e(\d{2})', re.IGNORECASE)
    
    for file_info in files_in_torrent:
        f_path = file_info['path']
        f_index = file_info['index']
        filename = os.path.basename(f_path)

        if not filename.lower().endswith('.mkv'):
            continue

        match = episode_pattern.search(filename)
        if match:
            file_season = int(match.group(1))
            episode_num = int(match.group(2))

            if file_season == int(season):
                list_item = xbmcgui.ListItem(label=filename)
                list_item.setInfo('video', {'title': filename, 'season': file_season, 'episode': episode_num})
                list_item.setProperty('IsPlayable', 'true')
                
                # Elementum vyžaduje URI souboru, ne jen cestu
                # Elementum URL se nesmí kódovat dvakrát.
                # Parametr 'uri' pro Elementum musí být kódovaný, ale celý plugin:// URL pro náš 'play' action ne.
                torrent_uri_encoded = urllib.parse.quote_plus(torrent_file_path)
                elementum_url = f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&index={f_index}"
                
                # Předáme Elementum URL přímo, bez dalšího kódování.
                play_url = f"{_URL}?action=play&uri={elementum_url}"
                
                episode_items.append((episode_num, play_url, list_item))

    # Seřadíme epizody podle čísla a přidáme je do seznamu
    for ep_num, url, item in sorted(episode_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)

def play_item(uri):
    """
    Vytvoří přehrávatelnou položku a předá ji Kodi k přehrání.
    """
    xbmc.log(f"Attempting to play URI: {uri}", level=xbmc.LOGINFO)
    # Vytvoříme novou položku seznamu s cestou nastavenou na finální URL
    list_item = xbmcgui.ListItem(path=uri)
    # Předáme ji Kodi k přehrání pomocí setResolvedUrl
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)

def router(paramstring):
    """
    Hlavní router pluginu.
    """
    # Parametry parsujeme odlišně v závislosti na akci, protože akce 'play'
    # obsahuje v parametru 'uri' URL, což by narušilo jednoduché parsování.
    if 'action=play' in paramstring:
        try:
            # Pro akci 'play' extrahujeme URI manuálně.
            uri_part = paramstring.split('&uri=', 1)[1]
            play_item(uri_part)
        except IndexError:
            xbmc.log("Failed to parse URI for playback.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Chyba", "Nepodařilo se zpracovat URL pro přehrání.", xbmcgui.NOTIFICATION_ERROR)
    else:
        params = get_params()
        action = params.get('action')

        if action is None:
            list_seasons()
        elif action == 'list_episodes':
            list_episodes(params['season'])

if __name__ == '__main__':
    router(sys.argv[2])
