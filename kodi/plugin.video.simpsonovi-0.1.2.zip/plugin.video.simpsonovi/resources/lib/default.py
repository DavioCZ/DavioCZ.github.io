# -*- coding: utf-8 -*-

import sys
import os
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import bencode
import json

# Základní URL a handle pluginu
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])


def _json_rpc(method, params):
    """
    Pomocná funkce pro volání Kodi JSON-RPC API.
    """
    request = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1
    }
    response_json = xbmc.executeJSONRPC(json.dumps(request))
    return json.loads(response_json)

def ensure_library_exists_and_mark_watched(current_season, current_episode):
    """
    Zajistí, že seriál Simpsonovi existuje v knihovně, a označí
    předchozí epizody jako zhlédnuté.
    """
    tvshow_title = "Simpsonovi"
    tvshow_tmdb_id = "456"

    # 1. Zjistit, jestli seriál už existuje v knihovně
    response = _json_rpc("VideoLibrary.GetTVShows", {
        "filter": {"field": "title", "operator": "is", "value": tvshow_title},
        "properties": ["title"]
    })
    
    tvshow_id = None
    if response.get("result", {}).get("tvshows"):
        tvshow_id = response["result"]["tvshows"][0]["tvshowid"]
        xbmc.log(f"[plugin.video.simpsonovi] Nalezen seriál '{tvshow_title}' v knihovně (ID: {tvshow_id}).", xbmc.LOGINFO)
    else:
        xbmc.log(f"[plugin.video.simpsonovi] Seriál '{tvshow_title}' nenalezen. Vytvářím novou knihovnu.", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Simpsonovi", "Vytvářím položky v knihovně...", xbmcgui.NOTIFICATION_INFO, 3000)
        tvshow_id = _create_library_entries(tvshow_title, tvshow_tmdb_id)

    if tvshow_id:
        _mark_previous_episodes_as_watched(tvshow_id, int(current_season), int(current_episode))

def _mark_previous_episodes_as_watched(tvshow_id, current_season, current_episode):
    """
    Označí všechny epizody předcházející aktuální jako zhlédnuté.
    """
    response = _json_rpc("VideoLibrary.GetEpisodes", {
        "tvshowid": tvshow_id,
        "properties": ["season", "episode", "playcount"]
    })

    if "error" in response or "episodes" not in response.get("result", {}):
        xbmc.log(f"[plugin.video.simpsonovi] Chyba při načítání epizod z knihovny.", xbmc.LOGERROR)
        return

    episodes_to_mark = []
    for ep in response["result"]["episodes"]:
        is_before = ep["season"] < current_season or \
                    (ep["season"] == current_season and ep["episode"] < current_episode)
        
        if is_before and ep.get("playcount", 0) == 0:
            episodes_to_mark.append(ep["episodeid"])

    if episodes_to_mark:
        xbmc.log(f"[plugin.video.simpsonovi] Označuji {len(episodes_to_mark)} epizod jako zhlédnutých.", xbmc.LOGINFO)
        for episode_id in episodes_to_mark:
            _json_rpc("VideoLibrary.SetEpisodeDetails", {
                "episodeid": episode_id,
                "playcount": 1
            })

def _create_library_entries(tvshow_title, tvshow_tmdb_id):
    """
    Vytvoří v knihovně Kodi "falešné" položky pro seriál a všechny jeho epizody.
    Slouží pouze pro sledování stavu zhlédnutí.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'simpsons.torrent')

    if not os.path.exists(torrent_file_path):
        return None

    with open(torrent_file_path, 'rb') as f:
        torrent_data = bencode.bdecode(f.read())

    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for f in torrent_info[b'files']:
            path_parts = [part.decode('utf-8', errors='ignore') for part in f[b'path']]
            files_in_torrent.append(os.path.join(*path_parts))
    elif b'name' in torrent_info:
        files_in_torrent.append(torrent_info[b'name'].decode('utf-8', errors='ignore'))

    # Vytvoření seriálu
    response = _json_rpc("VideoLibrary.SetTVShowDetails", {
        "tvshowtitle": tvshow_title,
        "tvshowid": -1,
        "uniqueid": {"tmdb": tvshow_tmdb_id}
    })
    
    if "error" in response:
        xbmc.log(f"[plugin.video.simpsonovi] Chyba při vytváření seriálu: {response['error']}", xbmc.LOGERROR)
        return None
    
    # Získání ID nově vytvořeného seriálu
    response = _json_rpc("VideoLibrary.GetTVShows", {
        "filter": {"field": "title", "operator": "is", "value": tvshow_title},
        "properties": []
    })
    if not response.get("result", {}).get("tvshows"):
        return None
    tvshow_id = response["result"]["tvshows"][0]["tvshowid"]

    episode_pattern = re.compile(r's(\d{2})e(\d{2})', re.IGNORECASE)
    
    for f_path in files_in_torrent:
        filename = os.path.basename(f_path)
        if not filename.lower().endswith('.mkv'):
            continue

        match = episode_pattern.search(filename)
        if match:
            season_num = int(match.group(1))
            episode_num = int(match.group(2))
            
            dummy_path = f"plugin://plugin.video.simpsonovi/dummy/{season_num}/{episode_num}"

            _json_rpc("VideoLibrary.SetEpisodeDetails", {
                "episodeid": -1,
                "tvshowid": tvshow_id,
                "season": season_num,
                "episode": episode_num,
                "title": filename,
                "file": dummy_path,
                "uniqueid": {"unknown": f"simpsonovi-s{season_num}e{episode_num}"}
            })
    
    xbmc.log(f"[plugin.video.simpsonovi] Úspěšně vytvořeny položky v knihovně pro seriál ID {tvshow_id}.", xbmc.LOGINFO)
    return tvshow_id

def get_params():
    """
    Vrátí parametry pluginu jako slovník.
    """
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}

def list_seasons():
    """
    Zobrazí seznam sérií (1-34).
    """
    xbmcplugin.setPluginCategory(_HANDLE, "Série")
    for i in range(1, 35):
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i})
        url = f"{_URL}?action=list_episodes&season={i}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(_HANDLE)

def list_episodes(season):
    """
    Zobrazí seznam epizod pro danou sérii.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'simpsons.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        return

    with open(torrent_file_path, 'rb') as f:
        torrent_data = bencode.bdecode(f.read())
    
    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f[b'path']]
            files_in_torrent.append({'path': os.path.join(*path_parts), 'index': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'index': 0})

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")
    
    episode_items = []
    # Regex pro extrakci série a epizody (např. s01e01)
    episode_pattern = re.compile(r's(\d{2})e(\d{2})', re.IGNORECASE)
    
    for file_info in files_in_torrent:
        f_path = file_info['path']
        f_index = file_info['index']
        filename = os.path.basename(f_path)

        if not filename.lower().endswith('.mkv'):
            continue

        match = episode_pattern.search(filename)
        if match:
            file_season = int(match.group(1))
            episode_num = int(match.group(2))

            if file_season == int(season):
                list_item = xbmcgui.ListItem(label=filename)
                list_item.setInfo('video', {'title': filename, 'season': file_season, 'episode': episode_num})
                list_item.setProperty('IsPlayable', 'true')

                play_url = f"{_URL}?action=play_playlist&season={file_season}&episode={episode_num}"
                
                episode_items.append((episode_num, play_url, list_item))

    # Seřadíme epizody podle čísla a přidáme je do seznamu
    for ep_num, url, item in sorted(episode_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)

def play_playlist(season, start_episode):
    """
    Vytvoří playlist od zadané epizody a spustí přehrávání.
    Nejprve zajistí existenci seriálu v knihovně a označí zhlédnuté díly.
    """
    ensure_library_exists_and_mark_watched(season, start_episode)

    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'simpsons.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        return

    with open(torrent_file_path, 'rb') as f:
        torrent_data = bencode.bdecode(f.read())

    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f[b'path']]
            files_in_torrent.append({'path': os.path.join(*path_parts), 'index': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'index': 0})

    episode_pattern = re.compile(r's(\d{2})e(\d{2})', re.IGNORECASE)
    
    all_episodes_in_season = []
    for file_info in files_in_torrent:
        f_path = file_info['path']
        f_index = file_info['index']
        filename = os.path.basename(f_path)

        if not filename.lower().endswith('.mkv'):
            continue

        match = episode_pattern.search(filename)
        if match:
            file_season = int(match.group(1))
            episode_num = int(match.group(2))

            if file_season == int(season):
                all_episodes_in_season.append({
                    'season': file_season,
                    'episode': episode_num,
                    'title': filename,
                    'oindex': f_index,
                    'torrent_path': torrent_file_path
                })

    # Seřadíme všechny epizody v sérii
    all_episodes_in_season.sort(key=lambda x: x['episode'])

    # Najdeme index startovací epizody
    start_index = -1
    for i, ep in enumerate(all_episodes_in_season):
        if ep['episode'] == int(start_episode):
            start_index = i
            break
    
    if start_index == -1:
        xbmcgui.Dialog().notification("Chyba", "Startovací epizoda nebyla nalezena.", xbmcgui.NOTIFICATION_ERROR)
        return

    # Vytvoříme playlist
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    # Přidáme startovací a následující epizody (max 10)
    for i in range(start_index, min(start_index + 10, len(all_episodes_in_season))):
        ep = all_episodes_in_season[i]
        
        torrent_uri_encoded = urllib.parse.quote_plus(f"file://{ep['torrent_path']}")
        title_encoded = urllib.parse.quote_plus(ep['title'])
        
        elementum_url = (f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&oindex={ep['oindex']}"
                         f"&title={title_encoded}&show=Simpsonovi&season={ep['season']}&episode={ep['episode']}&tmdbid=456")

        list_item = xbmcgui.ListItem(label=ep['title'])
        list_item.setInfo('video', {
            'title': ep['title'],
            'season': ep['season'],
            'episode': ep['episode'],
            'tvshowtitle': 'Simpsonovi'
        })
        list_item.setProperty('IsPlayable', 'true')
        
        playlist.add(url=elementum_url, listitem=list_item)

    xbmc.Player().play(playlist)


def router(paramstring):
    """
    Hlavní router pluginu.
    """
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if action == 'play_playlist':
        play_playlist(params['season'], params['episode'])
    elif action == 'list_episodes':
        list_episodes(params.get('season'))
    else:
        list_seasons()

if __name__ == '__main__':
    router(sys.argv[2])
