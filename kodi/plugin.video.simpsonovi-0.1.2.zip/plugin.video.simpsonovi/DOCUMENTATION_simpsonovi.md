# Dokumentace k doplňku The Simpsons (Elementum)

Tento dokument popisuje interní fungování Kodi doplňku `plugin.video.simpsonovi`. Cílem je poskytnout jasný přehled o jeho architektuře, závislostech a logice, aby kdokoli mohl pochopit, jak doplněk pracuje.

## 1. Základní princip

Doplněk funguje jako **specializovaný prohlížeč** pro jeden jediný torrent balík, který obsahuje série a epizody seriálu Simpsonovi. Neobsahuje žádný video obsah, pouze metadata a logiku pro komunikaci s doplňkem **Elementum**, který se stará o samotné stahování a přehrávání torrentu.

Stručně řečeno, jeho role je:
1.  Zobrazit uživateli přehledný seznam sérií.
2.  Po výběru série zobrazit seznam epizod v ní obsažených.
3.  Při pokusu o přehrání předat "úkol" doplňku Elementum ve správném formátu.

## 2. Struktura a klíčové soubory

-   `addon.xml`: Definuje základní vlastnosti doplňku, jako je jeho ID, verze, název a především **závislosti**. Klíčovou závislostí je `plugin.video.elementum`.
-   `resources/lib/default.py`: Hlavní soubor obsahující veškerou logiku doplňku.
-   `resources/lib/bencode.py`: Malá pomocná knihovna pro parsování `.torrent` souborů.
-   `resources/simpsons.torrent`: Torrent soubor, který obsahuje metadata o všech souborech v balíku (názvy, velikosti, pořadí).

## 3. Detailní popis fungování (krok za krokem)

Fungování doplňku lze rozdělit do tří hlavních fází:

### Fáze 1: Zobrazení seznamu sérií

1.  Uživatel spustí doplněk.
2.  Kodi zavolá `default.py`.
3.  Spustí se funkce `router()`, která zjistí, že nebyly předány žádné parametry (`action=None`).
4.  Zavolá se funkce `list_seasons()`.
5.  Tato funkce vytvoří statický seznam 34 položek ("Série 1" až "Série 34"). Každá položka je v Kodi zobrazena jako složka.
6.  URL adresa každé složky směřuje zpět na tento doplněk, ale s parametrem `action=list_episodes` a číslem dané série (např. `?action=list_episodes&season=5`).

### Fáze 2: Zobrazení seznamu epizod

1.  Uživatel klikne na jednu ze složek (např. "Série 5").
2.  Kodi znovu spustí `default.py`, tentokrát s URL `plugin://plugin.video.simpsonovi/?action=list_episodes&season=5`.
3.  Funkce `router()` rozpozná `action=list_episodes` a zavolá funkci `list_episodes(season=5)`.
4.  Tato funkce provede následující:
    a. **Načte soubor** `resources/simpsons.torrent`.
    b. Pomocí knihovny `bencode` **rozparsuje jeho obsah**. Tím získá kompletní seznam souborů obsažených v torrentu a jejich pořadí (index).
    c. Prochází tento seznam souborů a pomocí regulárního výrazu `s(\d{2})e(\d{2})` hledá v názvech souborů ty, které odpovídají zvolené sérii (v našem příkladu `s05e...`).
    d. Pro každý nalezený soubor vytvoří v Kodi položku (např. název souboru). Tato položka již není složka, ale přehrávatelný soubor (`IsPlayable=true`).

### Fáze 3: Přehrání epizody (předání Elementumu)

Toto je nejdůležitější část, která zajišťuje komunikaci mezi doplňky.

1.  Pro každou přehrávatelnou položku epizody se **vygeneruje speciální URL**, která nesměřuje na video, ale slouží jako **příkaz pro Elementum**.
2.  Tato URL má formát:
    ```
    plugin://plugin.video.elementum/play?uri=<cesta_k_torrentu>&oindex=<index_souboru>
    ```
    -   `uri`: Obsahuje URL-enkódovanou cestu k lokálnímu souboru `simpsons.torrent`.
    -   `oindex`: Obsahuje číselný **index** konkrétního souboru epizody uvnitř torrent balíku. Tím Elementum ví, který soubor z balíku má přehrát.

3.  Tato "Elementum URL" je následně "zabalena" do další URL, která směřuje zpět na náš doplněk:
    ```
    plugin://plugin.video.simpsonovi/?action=play&uri=<cela_elementum_url>
    ```

4.  Když uživatel klikne na epizodu, Kodi spustí náš doplněk s touto URL.
5.  Funkce `router()` detekuje `action=play` a zavolá funkci `play_item(uri=...)`, kde `uri` je ona plná "Elementum URL".
6.  Funkce `play_item()` už pouze provede finální krok: zavolá funkci `xbmcplugin.setResolvedUrl()`.
7.  Tímto příkazem doplněk říká Kodi: "Našel jsem finální, přehrávatelnou adresu. Tady je." a předá mu onu "Elementum URL".
8.  Kodi následně tuto URL zpracuje, což v praxi znamená, že **spustí doplněk Elementum** s danými parametry (`/play`, `uri`, `oindex`).
9.  Elementum se postará o zbytek – najde torrent, začne stahovat/streamovat vybraný soubor a zobrazí video.

## 4. Závěr

Doplněk `plugin.video.simpsonovi` je tedy pouze **inteligentní "most"** mezi uživatelem a doplňkem Elementum. Jeho přidaná hodnota spočívá v tom, že uživateli poskytuje jednoduché a přehledné rozhraní pro procházení obsahu jednoho velkého torrent balíku, aniž by uživatel musel s torrent souborem nebo s Elementumem přímo interagovat.
