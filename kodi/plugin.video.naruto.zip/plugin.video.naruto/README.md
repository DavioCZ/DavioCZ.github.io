# plugin.video.naruto

Kodi plugin pro přehrávání **Naruto** a **Naruto Shippuden** z torrent balíků
pomocí doplňku **Elementum**.

| Seriál | Epizody | Torrent soubor |
|--------|---------|----------------|
| Naruto (2002–2007) | E001–E220 | `resources/naruto/naruto.torrent` |
| Naruto Shippuden | E001–E500 | `resources/shippuden/naruto-shippuden.torrent` |

---

## Požadavky

- Kodi 19+ (Matrix) nebo novější
- Doplněk **Elementum** (nainstalovaný a funkční)
- Příslušné torrent soubory (viz níže)

---

## Instalace krok za krokem

### 1. Zkopíruj torrent soubory

```
resources/naruto/naruto.torrent              ← tvůj torrent s Naruto (2002)
resources/shippuden/naruto-shippuden.torrent ← tvůj torrent s Naruto Shippuden
```

> Plugin funguje i s jen jedním torrentem – chybějící jednoduše nevygeneruješ.

### 2. Vygeneruj mapy epizod

```bash
# Naruto (2002)
python3 resources/naruto/build_map.py

# Naruto Shippuden
python3 resources/shippuden/build_map.py
```

Každý skript hledá torrent ve stejné složce jako on sám.

### 3. Stáhni metadata z TMDB (volitelné, ale doporučené)

```bash
# Naruto (2002)
python3 resources/naruto/build_metadata.py

# Naruto Shippuden
python3 resources/shippuden/build_metadata.py
```

Stáhne názvy epizod, popisy a náhledy z TheMovieDB (cs-CZ / en-US záloha).

### 4. Přidej ikonku (volitelné)

Vlož `icon.png` do kořene složky pluginu.

### 5. Nainstaluj do Kodi

Zabal složku `plugin.video.naruto/` jako ZIP a nainstaluj přes:

> **Doplňky → Nainstalovat ze ZIP souboru**

---

## Struktura souborů

```
plugin.video.naruto/
├── addon.xml
├── icon.png                                ← přidej ručně
├── resources/
│   ├── lib/
│   │   ├── default.py                      ← hlavní logika pluginu
│   │   └── bencode.py                      ← torrent parser
│   │
│   ├── naruto/                             ← Naruto (2002–2007)
│   │   ├── naruto.torrent                  ← ZKOPÍRUJ SEM svůj torrent
│   │   ├── map.json                        ← generuje build_map.py
│   │   ├── metadata.json                   ← generuje build_metadata.py
│   │   ├── build_map.py
│   │   └── build_metadata.py
│   │
│   └── shippuden/                          ← Naruto Shippuden
│       ├── naruto-shippuden.torrent        ← ZKOPÍRUJ SEM svůj torrent
│       ├── map.json                        ← generuje build_map.py
│       ├── metadata.json                   ← generuje build_metadata.py
│       ├── build_map.py
│       └── build_metadata.py
```

---

## Jak plugin funguje

- **Hlavní menu**: výběr seriálu (Naruto / Naruto Shippuden)
- **Bloky**: epizody po 50 (E001–E050, E051–E100, …)
- **Přehrání**: Elementum otevře konkrétní soubor pomocí `index=N`

### Multi-epizody

Pokud torrent obsahuje více epizod v jednom souboru (např. `006-007.mkv` nebo
`203-204-205.mkv`), plugin je zobrazí jako jeden item s označením
`E006+E007 – Název`. Po přehrání se přehraje celý soubor.

---

## Přegenerování map.json

Pokud torrent nahradíš (jiné pořadí souborů), znovu spusť příslušný build_map.py:

```bash
python3 resources/naruto/build_map.py
python3 resources/shippuden/build_map.py
```

---

## Licence

MIT
