# resources/shippuden/build_metadata.py
# -*- coding: utf-8 -*-
#
# Naruto Shippuden – build_metadata.py
# Stáhne metadata všech 500 epizod z TMDB a uloží jako metadata.json
#
# TMDB ID Naruto Shippuden = 31910
# Na TMDB je seriál rozdělen do 22 sezón (po arcích).
# Každá sezóna čísluje epizody od 1, ale TMDB vrací i absolute_episode_number.
#
# Spuštění:
#   python3 resources/shippuden/build_metadata.py

import json, os, time, argparse
import urllib.request, urllib.parse

# ---------------------------------------------------------------------------
TMDB_API_KEY  = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_SHOW_ID  = 31910   # Naruto: Shippuden  (pozor, NENÍ 46260 – to je původní Naruto)
# ---------------------------------------------------------------------------


def tmdb_get(endpoint, params=None):
    if params is None:
        params = {}
    params['api_key'] = TMDB_API_KEY
    url = f"{TMDB_BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        print(f"  Chyba {endpoint}: {e}")
        return None


def build_metadata(show_id):
    script_dir  = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, 'metadata.json')

    # Zjistíme počet sezón
    print(f"Stahuji info o seriálu (ID {show_id})...")
    show_info = tmdb_get(f"/tv/{show_id}", {'language': 'cs-CZ'})
    if not show_info:
        print("Nepodařilo se získat info o seriálu!")
        return

    num_seasons = show_info.get('number_of_seasons', 0)
    print(f"Počet sezón: {num_seasons}")

    metadata = {}
    abs_counter = 0  # záložní čítač pro případ chybějícího absolute_episode_number

    for season_num in range(1, num_seasons + 1):
        print(f"  Sezóna {season_num}/{num_seasons}...", end=' ', flush=True)

        s_cs = tmdb_get(f"/tv/{show_id}/season/{season_num}", {'language': 'cs-CZ'})
        s_en = tmdb_get(f"/tv/{show_id}/season/{season_num}", {'language': 'en-US'})
        time.sleep(0.25)

        if not s_cs:
            print("přeskočena (chyba)")
            continue

        en_map = {ep['episode_number']: ep for ep in s_en.get('episodes', [])} if s_en else {}
        ep_count = 0

        for ep_cs in s_cs.get('episodes', []):
            abs_counter += 1
            # Preferujeme absolute_episode_number z TMDB, jinak spočítáme sami
            abs_ep = ep_cs.get('absolute_episode_number') or abs_counter
            ep_num_in_season = ep_cs.get('episode_number', 0)

            key   = f"E{abs_ep:03d}"
            ep_en = en_map.get(ep_num_in_season, {})

            title = ep_cs.get('name') or ep_en.get('name') or f"Epizoda {abs_ep}"
            plot  = ep_cs.get('overview') or ep_en.get('overview') or "Popis není k dispozici."
            path  = ep_cs.get('still_path') or ep_en.get('still_path')
            thumb = f"https://image.tmdb.org/t/p/w500{path}" if path else ""

            metadata[key] = {'title': title, 'plot': plot, 'thumb': thumb}
            ep_count += 1

        print(f"{ep_count} ep (celkem zatím {len(metadata)})")

    print(f"\nCelkem získáno: {len(metadata)} epizod")

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    print(f"Uloženo -> {output_file}")

    # Sanity check
    keys = sorted(metadata.keys())
    if keys:
        print(f"Rozsah: {keys[0]} – {keys[-1]}")
        missing = [f"E{i:03d}" for i in range(1, 501) if f"E{i:03d}" not in metadata]
        if missing:
            print(f"Chybí ({len(missing)}): {missing[:10]}{'...' if len(missing)>10 else ''}")
        else:
            print("Všechny epizody E001–E500 pokryty!")


def main():
    global TMDB_API_KEY
    ap = argparse.ArgumentParser(description='Naruto Shippuden – generátor metadat z TMDB')
    ap.add_argument('--api-key', default=TMDB_API_KEY,
                    help='TMDB API klíč')
    ap.add_argument('--show-id', type=int, default=TMDB_SHOW_ID,
                    help=f'TMDB ID seriálu (výchozí: {TMDB_SHOW_ID})')
    args = ap.parse_args()
    TMDB_API_KEY = args.api_key
    build_metadata(args.show_id)


if __name__ == '__main__':
    main()
