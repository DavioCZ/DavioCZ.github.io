# resources/naruto/build_map.py
# -*- coding: utf-8 -*-
#
# Naruto (2002–2007) – build_map.py
# Generuje resources/naruto/map.json z resources/naruto/naruto.torrent
#
# Soubory v torrentu mají různé formáty názvů (smíšená kolekce):
#   [CNT]_Naruto_129_[hash].mkv        -> E129
#   [CNT]_Naruto_147-148_[hash].mkv    -> E147, E148  (double)
#   [CNT]_Naruto_203-204-205_[hash].mkv-> E203, E204, E205  (triple)
#   Naruto_CZ_099-04x21.avi            -> E099
#   Naruto 104.mp4                     -> E104
#   Naruto 120 cz dabing.avi           -> E120
#   Naruto 125-cz-dabing.avi           -> E125
#   naruto-121-cz-titulky.mkv          -> E121

import io, os, re, json, argparse
from collections import OrderedDict

# Elementum /play?index=... indexuje svůj candidate list, ne raw torrent list.
# Pro seriály nastavujeme stejný minimální limit jako Elementum: 4 MB.
MIN_ELEMENTUM_CANDIDATE_SIZE = 4 * 1024 * 1024

# ---------------------------------------------------------------------------
# Regex patterny – seřazeny od nejspecifičtějšího po nejobecnější
# ---------------------------------------------------------------------------
PATTERNS = [
    # Triple ep: Naruto_203-204-205_
    re.compile(r'[Nn]aruto[_ ](\d{2,3})-(\d{2,3})-(\d{2,3})'),
    # Double ep s [ nebo _ za čísly: Naruto_147-148_  nebo Naruto 147-148[
    re.compile(r'[Nn]aruto[_ ](\d{2,3})-(\d{2,3})[_\[ ]'),
    # CZ dabing s SxxExx: Naruto_CZ_099-04x21
    re.compile(r'[Nn]aruto_CZ_(\d{2,3})'),
    # Single s podtržítkem/[: Naruto_129_  nebo Naruto_129[
    re.compile(r'[Nn]aruto[_](\d{2,3})[_\[]'),
    # Single s mezerou a tečkou/mezerou: "Naruto 104.mp4", "Naruto 120 cz"
    re.compile(r'[Nn]aruto[ ](\d{2,3})[ .]'),
    # Single/double s -cz: "Naruto 125-cz-dabing", "Naruto 133-cz-dabink"
    re.compile(r'[Nn]aruto[ _](\d{2,3})-cz', re.IGNORECASE),
    # Single s pomlčkou: naruto-121-cz
    re.compile(r'[Nn]aruto[-](\d{2,3})[-]'),
]


# ---------------------------------------------------------------------------
# Minimalistický bdecoder
# ---------------------------------------------------------------------------
def bdecode(data: bytes):
    s = io.BytesIO(data)

    def r(n=1):
        b = s.read(n)
        if not b:
            raise ValueError("Unexpected EOF")
        return b

    def p():
        x = s.read(1)
        if not x:
            return b""
        s.seek(-1, 1)
        return x

    def parse():
        c = r(1)
        if c == b'i':
            num = b""; ch = r(1)
            if ch == b'-':
                num += ch; ch = r(1)
            while ch != b'e':
                if not (b'0' <= ch <= b'9'):
                    raise ValueError("Bad int")
                num += ch; ch = r(1)
            return int(num)
        if c == b'l':
            out = []
            while p() != b'e':
                out.append(parse())
            r(1)
            return out
        if c == b'd':
            d = OrderedDict()
            while p() != b'e':
                k = parse()
                d[bytes(k)] = parse()
            r(1)
            return d
        if b'0' <= c <= b'9':
            ln = c; ch = r(1)
            while ch != b':':
                ln += ch; ch = r(1)
            return r(int(ln))
        raise ValueError("Bad prefix: %r" % c)

    return parse()


def load_files(torrent_path):
    """Vrátí seznam (torrent_index, path, length) pro video soubory."""
    with open(torrent_path, 'rb') as f:
        t = bdecode(f.read())
    info = t.get(b'info', {})
    files = []
    if b'files' in info:
        for torrent_index, f in enumerate(info[b'files']):
            parts = [p.decode('utf-8', 'ignore') for p in f.get(b'path', [])]
            files.append((torrent_index, '/'.join(parts), int(f.get(b'length', 0))))
    elif b'name' in info and b'length' in info:
        files.append((0, info[b'name'].decode('utf-8', 'ignore'), int(info[b'length'])))
    else:
        raise ValueError("Nepodporovaná struktura torrentu.")

    VIDEO_EXTS = {'.mkv', '.avi', '.mp4', '.mov', '.wmv'}
    return [(i, p, l) for i, p, l in files
            if os.path.splitext(p)[1].lower() in VIDEO_EXTS]


def parse_episodes(filename):
    """
    Ze jména souboru vrátí seznam čísel epizod (int).
    Vrátí None pokud nezjistíme.
    """
    base = os.path.basename(filename)
    if 'shippuden' in base.lower():
        return None
    for pat in PATTERNS:
        m = pat.search(base)
        if m:
            return [int(g) for g in m.groups() if g is not None]
    return None


def build_map(files):
    """
    Vytvoří:
      e2idx  – "E042" -> Elementum file index (abecední pořadí video souborů)
      idx2e  – "12"   -> ["E042"] nebo ["E042","E043"]
    """
    candidate_files = [(i, p, l) for i, p, l in files
                       if l >= MIN_ELEMENTUM_CANDIDATE_SIZE]
    sorted_paths = sorted(p for _, p, _ in candidate_files)
    path2eidx = {p: i for i, p in enumerate(sorted_paths)}

    e2idx = {}
    idx2e = {}

    unmatched = []
    for _, path, _ in candidate_files:
        ep_nums = parse_episodes(path)
        if ep_nums is None:
            unmatched.append(path)
            continue
        eidx = path2eidx[path]
        eidx_str = str(eidx)
        if eidx_str not in idx2e:
            idx2e[eidx_str] = []
        for ep_num in ep_nums:
            key = f"E{ep_num:03d}"
            e2idx[key] = eidx
            if key not in idx2e[eidx_str]:
                idx2e[eidx_str].append(key)

    return e2idx, idx2e, unmatched


def main():
    script_dir      = os.path.dirname(os.path.abspath(__file__))
    default_torrent = os.path.join(script_dir, 'naruto.torrent')
    default_json    = os.path.join(script_dir, 'map.json')

    ap = argparse.ArgumentParser(description='Naruto (2002–2007) – generátor mapy epizod')
    ap.add_argument('--torrent', '-t', default=default_torrent)
    ap.add_argument('--out-json', default=default_json)
    args = ap.parse_args()

    if not os.path.isfile(args.torrent):
        print(f"Chybí soubor: {args.torrent}")
        raise SystemExit(2)

    files = load_files(args.torrent)
    if not files:
        print("V torrentu nejsou žádné video soubory.")
        raise SystemExit(3)

    print(f"Nalezeno souborů: {len(files)}")
    e2idx, idx2e, unmatched = build_map(files)

    with open(args.out_json, 'w', encoding='utf-8') as f:
        json.dump({'e2idx': e2idx, 'idx2e': idx2e}, f, ensure_ascii=False, indent=2)

    print(f"Mapa vytvořena: {len(e2idx)} epizod namapováno -> {args.out_json}")

    doubles = [(k, v) for k, v in idx2e.items() if len(v) > 1]
    if doubles:
        print(f"\nMulti-epizody ({len(doubles)}):")
        for eidx, keys in sorted(doubles, key=lambda x: int(x[0])):
            print(f"  Elementum [{eidx}] -> {', '.join(sorted(keys))}")

    if unmatched:
        print(f"\nSOUBORY BEZ MATCHE ({len(unmatched)}) – nebudou dostupné v pluginu:")
        for p in unmatched:
            print(f"  {p}")


if __name__ == '__main__':
    main()
