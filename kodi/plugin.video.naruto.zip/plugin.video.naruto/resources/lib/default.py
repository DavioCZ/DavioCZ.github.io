# -*- coding: utf-8 -*-
#
# Naruto + Naruto Shippuden – resources/lib/default.py
# Kodi plugin pro přehrávání obou seriálů přes Elementum.
#
# Struktura menu:
#   Hlavní menu
#     ├── Naruto (2002–2007)         -> bloky po BLOCK_SIZE epizod
#     │     └── E001–E050, ...       -> jednotlivé epizody
#     └── Naruto Shippuden           -> bloky po BLOCK_SIZE epizod
#           └── E001–E050, ...       -> jednotlivé epizody
#
# Soubory v resources/:
#   naruto/naruto.torrent            <- zkopíruj svůj torrent
#   naruto/map.json                  <- generuje naruto/build_map.py
#   naruto/metadata.json             <- generuje naruto/build_metadata.py
#   shippuden/naruto-shippuden.torrent
#   shippuden/map.json
#   shippuden/metadata.json

import sys
import os
import urllib.parse
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

_URL    = sys.argv[0]
_HANDLE = int(sys.argv[1])

BLOCK_SIZE = 50

SERIES = {
    'naruto': {
        'label':    'Naruto (2002–2007)',
        'folder':   'naruto',
        'torrent':  'naruto.torrent',
        'total':    220,
        'tvshow':   'Naruto',
        'season':   1,
    },
    'shippuden': {
        'label':    'Naruto Shippuden',
        'folder':   'shippuden',
        'torrent':  'naruto-shippuden.torrent',
        'total':    500,
        'tvshow':   'Naruto: Shippuden',
        'season':   1,
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def load_json_file(series_folder, filename):
    try:
        addon      = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        file_path  = os.path.join(addon_path, 'resources', series_folder, filename)
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"[naruto] Chyba při načítání {series_folder}/{filename}: {e}",
                 level=xbmc.LOGWARNING)
    return {}


def get_torrent_path(series_folder, torrent_name):
    addon      = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    return os.path.join(addon_path, 'resources', series_folder, torrent_name)


# ---------------------------------------------------------------------------
# Hlavní menu – výběr seriálu
# ---------------------------------------------------------------------------

def list_series():
    xbmcplugin.setPluginCategory(_HANDLE, "Naruto")
    xbmcplugin.setContent(_HANDLE, 'tvshows')

    for series_id, cfg in SERIES.items():
        li = xbmcgui.ListItem(label=cfg['label'])
        li.setInfo('video', {
            'title':       cfg['label'],
            'tvshowtitle': cfg['tvshow'],
            'mediatype':   'tvshow',
        })
        url = f"{_URL}?action=list_blocks&series={series_id}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Bloky epizod pro daný seriál
# ---------------------------------------------------------------------------

def list_blocks(series_id):
    cfg = SERIES.get(series_id)
    if not cfg:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, cfg['label'])
    xbmcplugin.setContent(_HANDLE, 'tvshows')

    ep = 1
    while ep <= cfg['total']:
        ep_from = ep
        ep_to   = min(ep + BLOCK_SIZE - 1, cfg['total'])
        label   = f"Epizody {ep_from:03d}–{ep_to:03d}"

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':       label,
            'tvshowtitle': cfg['tvshow'],
        })
        url = (f"{_URL}?action=list_episodes"
               f"&series={series_id}&from={ep_from}&to={ep_to}")
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=li, isFolder=True)
        ep += BLOCK_SIZE

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Seznam epizod v bloku
# ---------------------------------------------------------------------------

def list_episodes(series_id, ep_from, ep_to):
    cfg = SERIES.get(series_id)
    if not cfg:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    folder       = cfg['folder']
    torrent_name = cfg['torrent']
    tvshow       = cfg['tvshow']
    season_num   = cfg['season']

    label = f"E{ep_from:03d}–E{ep_to:03d}"
    xbmcplugin.setPluginCategory(_HANDLE, f"{cfg['label']} – {label}")
    xbmcplugin.setContent(_HANDLE, 'episodes')

    torrent_path = get_torrent_path(folder, torrent_name)
    if not os.path.exists(torrent_path):
        xbmcgui.Dialog().notification(
            "Chyba",
            f"Torrent soubor nenalezen:\nresources/{folder}/{torrent_name}",
            xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    data_map = load_json_file(folder, 'map.json')
    e2idx    = data_map.get('e2idx', {})
    e2oidx   = data_map.get('e2oidx', e2idx)
    idx2e    = data_map.get('idx2e', {})
    oidx2e   = data_map.get('oidx2e', idx2e)
    metadata = load_json_file(folder, 'metadata.json')

    torrent_uri = urllib.parse.quote_plus(torrent_path)
    episode_items = []

    for ep_num in range(ep_from, ep_to + 1):
        key = f"E{ep_num:03d}"

        if key not in e2idx:
            # Může být součástí multi-ep souboru pod nižším klíčem –
            # zobrazíme jen jako hlavní (nižší) klíč, duplikát přeskočíme
            continue

        eidx = e2idx[key]
        play_idx = e2oidx.get(key, eidx)
        paired_keys = oidx2e.get(str(play_idx), idx2e.get(str(eidx), [key]))
        is_multi    = len(paired_keys) > 1

        meta      = metadata.get(key, {})
        raw_title = meta.get('title', f"Epizoda {ep_num}")
        plot      = meta.get('plot', 'Popis není k dispozici.')
        thumb     = meta.get('thumb', '')

        if is_multi:
            others = [k for k in sorted(paired_keys) if k != key]
            suffix = '+'.join(others)
            prefix = f"{key}+{suffix} – "
        else:
            prefix = f"{key} – "

        display_title = prefix + raw_title

        elementum_url = (
            f"plugin://plugin.video.elementum/play"
            f"?uri={torrent_uri}&oindex={play_idx}"
        )
        play_url = (f"{_URL}?action=play"
                    f"&uri={urllib.parse.quote_plus(elementum_url)}")

        li = xbmcgui.ListItem(label=display_title)
        li.setInfo('video', {
            'title':       display_title,
            'episode':     ep_num,
            'season':      season_num,
            'plot':        plot,
            'tvshowtitle': tvshow,
            'mediatype':   'episode',
        })
        if thumb:
            li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')

        episode_items.append((ep_num, play_url, li))

    for _, url, item in episode_items:
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Přehrání
# ---------------------------------------------------------------------------

def play_item(uri):
    li = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def router(paramstring):
    params = get_params()
    action = params.get('action')

    if action == 'play':
        raw_uri = params.get('uri', '')
        play_item(urllib.parse.unquote_plus(raw_uri))

    elif action == 'list_blocks':
        series_id = params.get('series', 'naruto')
        list_blocks(series_id)

    elif action == 'list_episodes':
        series_id = params.get('series', 'naruto')
        ep_from   = int(params.get('from', 1))
        ep_to     = int(params.get('to', BLOCK_SIZE))
        list_episodes(series_id, ep_from, ep_to)

    else:
        list_series()


if __name__ == '__main__':
    router(sys.argv[2])
