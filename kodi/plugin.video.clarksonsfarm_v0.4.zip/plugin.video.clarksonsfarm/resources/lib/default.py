# -*- coding: utf-8 -*-
#
# Clarksonova farma – resources/lib/default.py
# Kodi plugin pro přehrávání S01–S05 přes Elementum.
#
# Struktura menu:
#   Hlavní menu  -> seznam sezón (S01, S02, S03, S04)
#   Sezóna       -> seznam epizod s metadaty
#   Epizoda      -> přehrání přes Elementum

import sys
import os
import urllib.parse
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

_URL    = sys.argv[0]
_HANDLE = int(sys.argv[1])

SHOW_NAME   = "Clarksonova farma"
DEFAULT_TORRENT_FILE = "clarkson_farm.torrent"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def addon_path():
    return xbmcaddon.Addon().getAddonInfo('path')


def load_json(filename):
    try:
        path = os.path.join(addon_path(), 'resources', filename)
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"[clarksonsfarm] Chyba při načítání {filename}: {e}",
                 level=xbmc.LOGWARNING)
    return {}


def get_torrent_path(season_num=None, episode_key=None):
    """Vrátí cestu k torrent souboru.

    Nejprve se zkusí najít torrent pro konkrétní epizodu (map.json ->
    "episode_torrents"), protože některé série (např. S05) jsou rozdělené
    do více torrentů. Pokud epizoda není v "episode_torrents", použije se
    torrent pro celou sezónu (map.json -> "torrents").
    """
    data_map = load_json('map.json')
    torrent_file = DEFAULT_TORRENT_FILE

    if episode_key is not None:
        episode_torrents = data_map.get('episode_torrents', {})
        if episode_key in episode_torrents:
            torrent_file = episode_torrents[episode_key]
            return os.path.join(addon_path(), 'resources', torrent_file), torrent_file

    if season_num is not None:
        torrents = data_map.get('torrents', {})
        torrent_file = torrents.get(str(season_num), DEFAULT_TORRENT_FILE)

    return os.path.join(addon_path(), 'resources', torrent_file), torrent_file


# ---------------------------------------------------------------------------
# Hlavní menu – seznam sezón
# ---------------------------------------------------------------------------

def list_seasons():
    xbmcplugin.setPluginCategory(_HANDLE, SHOW_NAME)
    xbmcplugin.setContent(_HANDLE, 'tvshows')

    data_map = load_json('map.json')
    e2idx    = data_map.get('e2idx', {})

    # Zjistíme dostupné sezóny z map.json
    seasons = sorted(set(key[:3] for key in e2idx.keys()))  # ["S01","S02","S03"]

    if not seasons:
        xbmcgui.Dialog().notification(
            "Chyba", "map.json je prázdný nebo chybí. Spusť build_map.py.",
            xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    for season_str in seasons:
        season_num = int(season_str[1:])
        label      = f"Série {season_num}"

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':       label,
            'tvshowtitle': SHOW_NAME,
            'season':      season_num,
            'mediatype':   'season',
        })
        url = f"{_URL}?action=list_episodes&season={season_num}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Seznam epizod v sérii
# ---------------------------------------------------------------------------

def list_episodes(season_num):
    xbmcplugin.setPluginCategory(_HANDLE, f"{SHOW_NAME} – Série {season_num}")
    xbmcplugin.setContent(_HANDLE, 'episodes')

    data_map = load_json('map.json')
    e2idx    = data_map.get('e2idx', {})
    metadata = load_json('metadata.json')

    season_str  = f"S{season_num:02d}"

    # Filtrujeme epizody patřící do dané sezóny, seřadíme
    season_keys = sorted(k for k in e2idx.keys() if k.startswith(season_str))

    if not season_keys:
        xbmcgui.Dialog().notification(
            "Chyba", f"Série {season_num} nenalezena v map.json",
            xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    for key in season_keys:
        ep_num = int(key[4:])   # "S01E03" -> 3
        eidx   = e2idx[key]

        # Torrent se zjišťuje per-epizoda, protože některé série
        # (např. S05) jsou rozdělené do více torrent souborů.
        torrent_path, torrent_file = get_torrent_path(season_num, episode_key=key)
        if not os.path.exists(torrent_path):
            xbmcgui.Dialog().notification(
                "Chyba",
                f"Torrent soubor nenalezen:\nresources/{torrent_file}",
                xbmcgui.NOTIFICATION_ERROR)
            continue
        torrent_uri = urllib.parse.quote_plus(torrent_path)

        meta      = metadata.get(key, {})
        raw_title = meta.get('title', f"Epizoda {ep_num}")
        plot      = meta.get('plot', 'Popis není k dispozici.')
        thumb     = meta.get('thumb', '')

        display_title = f"{key} – {raw_title}"

        elementum_url = (
            f"plugin://plugin.video.elementum/play"
            f"?uri={torrent_uri}&index={eidx}"
        )
        play_url = f"{_URL}?action=play&uri={urllib.parse.quote_plus(elementum_url)}"

        li = xbmcgui.ListItem(label=display_title)
        li.setInfo('video', {
            'title':       display_title,
            'episode':     ep_num,
            'season':      season_num,
            'plot':        plot,
            'tvshowtitle': SHOW_NAME,
            'mediatype':   'episode',
        })
        if thumb:
            li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=play_url,
                                    listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Přehrání
# ---------------------------------------------------------------------------

def play_item(uri):
    li = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def router(paramstring):
    params = get_params()
    action = params.get('action')

    if action == 'play':
        play_item(urllib.parse.unquote_plus(params.get('uri', '')))
    elif action == 'list_episodes':
        list_episodes(int(params.get('season', 1)))
    else:
        list_seasons()


if __name__ == '__main__':
    router(sys.argv[2])
