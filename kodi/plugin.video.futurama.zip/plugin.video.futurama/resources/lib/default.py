# -*- coding: utf-8 -*-

import sys
import os
import re
import urllib.parse
import json

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import bencode

# Základní URL a handle pluginu
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])


def get_params():
    """
    Vrátí parametry pluginu jako slovník.
    """
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def load_map():
    """
    Načte mapu z resources/map.json
    Očekává strukturu:
      {
        "o2e": { "0": 17, ... },
        "se2e": { "S01E01": 0, ... }
      }
    """
    try:
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        map_path = os.path.join(addon_path, 'resources', 'map.json')
        if os.path.exists(map_path):
            with open(map_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    data.setdefault("se2e", {})
                    data.setdefault("o2e", {})
                    return data
    except Exception as e:
        xbmc.log(f"[futurama] load_map() error: {e}", level=xbmc.LOGWARNING)
    return {"se2e": {}, "o2e": {}}


def list_seasons():
    """
    Zobrazí seznam sérií a položku pro Futurama filmy.
    Filmy budou na konci seznamu.
    """
    xbmcplugin.setPluginCategory(_HANDLE, "Futurama")

    # Nejprve přidáme všechny série
    for i in range(1, 9):  # Rozsah pro 8 sérií
        list_item = xbmcgui.ListItem(label=f"Série {i}")
        list_item.setInfo('video', {'title': f"Série {i}", 'season': i, 'tvshowtitle': 'Futurama'})
        url = f"{_URL}?action=list_episodes&season={i}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)

    # Pak přidáme položku pro Futurama filmy
    list_item = xbmcgui.ListItem(label="Futurama filmy")
    list_item.setInfo('video', {'title': "Futurama filmy", 'mediatype': 'movie'})
    url = f"{_URL}?action=list_movies"
    xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)


def get_torrent_files_info():
    """
    Pomocná funkce pro načtení a dekódování torrentu,
    aby se kód neopakoval ve více funkcích.
    """
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    torrent_file_path = os.path.join(addon_path, 'resources', 'futurama.torrent')

    if not os.path.exists(torrent_file_path):
        xbmcgui.Dialog().notification("Chyba", "Torrent soubor nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[futurama] Torrent file not found: {torrent_file_path}", level=xbmc.LOGERROR)
        return None, None

    try:
        with open(torrent_file_path, 'rb') as f:
            torrent_data = bencode.bdecode(f.read())
    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", f"Nepodařilo se načíst torrent: {e}", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[futurama] Failed to decode torrent: {e}", level=xbmc.LOGERROR)
        return None, None

    files_in_torrent = []
    torrent_info = torrent_data.get(b'info', {})
    if b'files' in torrent_info:
        for idx, f in enumerate(torrent_info[b'files']):
            path_parts = [part.decode('utf-8', errors='ignore') for part in f.get(b'path', [])]
            if not path_parts:
                continue
            files_in_torrent.append({'path': os.path.join(*path_parts), 'oindex': idx})
    elif b'name' in torrent_info:
        files_in_torrent.append({'path': torrent_info[b'name'].decode('utf-8', errors='ignore'), 'oindex': 0})
    else:
        xbmcgui.Dialog().notification("Chyba", "Torrent neobsahuje podporovanou strukturu (files/name).", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log("[futurama] Torrent has unsupported structure.", level=xbmc.LOGERROR)
        return None, None

    return files_in_torrent, torrent_file_path


def list_episodes(season):
    """
    Zobrazí seznam epizod pro danou sérii.
    Použije map.json (se2e) k překladu na správný Elementum index.
    """
    files_in_torrent, torrent_file_path = get_torrent_files_info()
    if files_in_torrent is None:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, f"Série {season}")

    # Regex pro xxYyy, aby se odfiltrovaly filmy
    episode_pattern = re.compile(r'(\d{2})x(\d{2})', re.IGNORECASE)

    emap = load_map()
    se2e = emap.get("se2e", {})

    episode_items = []

    for file_info in files_in_torrent:
        f_path = file_info['path']
        oindex = file_info['oindex']
        filename = os.path.basename(f_path)

        if not filename.lower().endswith('.avi'):
            continue

        match = episode_pattern.search(filename)
        if not match:
            # Přeskočí soubory, které neodpovídají vzoru epizody (tj. filmy)
            continue

        file_season = int(match.group(1))
        episode_num = int(match.group(2))

        if file_season != int(season):
            continue

        episode_key = f"S{file_season:02d}E{episode_num:02d}"
        mapped_index = se2e.get(episode_key, oindex)

        torrent_uri_encoded = urllib.parse.quote_plus(torrent_file_path)
        elementum_url = f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&index={mapped_index}"

        label = filename
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {
            'title': label,
            'season': file_season,
            'episode': episode_num,
            'tvshowtitle': 'Futurama'
        })
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{_URL}?action=play&uri={elementum_url}"
        episode_items.append((episode_num, play_url, list_item))

    for ep_num, url, item in sorted(episode_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)


def list_movies():
    """
    Zobrazí seznam Futurama filmů.
    """
    files_in_torrent, torrent_file_path = get_torrent_files_info()
    if files_in_torrent is None:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, "Futurama filmy")

    # Názvy souborů filmů, jak jsou v torrentu
    movie_filenames = [
        "Milion a jedno chapadlo.avi",
        "Benderovo parádní terno.avi",
        "Fialový trpaslík.avi",
        "Benderova hra.avi"
    ]

    emap = load_map()
    o2e = emap.get("o2e", {}) # Pro filmy použijeme o2e mapu, protože nemají SxxExx

    movie_items = []

    for file_info in files_in_torrent:
        f_path = file_info['path']
        oindex = file_info['oindex']
        filename = os.path.basename(f_path)

        if filename in movie_filenames:
            # Zde neřešíme SxxExx, ale přímo originální index z torrentu.
            # Předpokládáme, že build_map.py vytvořil o2e mapu.
            mapped_index = o2e.get(oindex, oindex)

            torrent_uri_encoded = urllib.parse.quote_plus(torrent_file_path)
            elementum_url = f"plugin://plugin.video.elementum/play?uri={torrent_uri_encoded}&index={mapped_index}"

            list_item = xbmcgui.ListItem(label=filename.replace('.avi', '')) # Odstraní příponu pro lepší vzhled
            list_item.setInfo('video', {
                'title': filename.replace('.avi', ''),
                'tvshowtitle': 'Futurama',
                'mediatype': 'movie' # Označí jako film
            })
            list_item.setProperty('IsPlayable', 'true')

            play_url = f"{_URL}?action=play&uri={elementum_url}"
            movie_items.append((filename, play_url, list_item)) # Řadit podle názvu filmu

    # Seřadíme filmy abecedně
    for filename, url, item in sorted(movie_items, key=lambda x: x[0]):
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)


def play_item(uri):
    """
    Vytvoří přehrávatelnou položku a předá ji Kodi k přehrání.
    """
    xbmc.log(f"[futurama] Attempting to play URI: {uri}", level=xbmc.LOGINFO)
    list_item = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)


def router(paramstring):
    """
    Hlavní router pluginu.
    """
    if 'action=play' in paramstring:
        try:
            uri_part = paramstring.split('&uri=', 1)[1]
            play_item(uri_part)
        except IndexError:
            xbmc.log("[futurama] Failed to parse URI for playback.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Chyba", "Nepodařilo se zpracovat URL pro přehrání.", xbmcgui.NOTIFICATION_ERROR)
    else:
        params = get_params()
        action = params.get('action')

        if action is None:
            list_seasons()
        elif action == 'list_episodes':
            list_episodes(params['season'])
        elif action == 'list_movies': # Nová akce pro filmy
            list_movies()


if __name__ == '__main__':
    router(sys.argv[2])