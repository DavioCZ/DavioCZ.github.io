# -*- coding: utf-8 -*-
"""Vygeneruje map.json z resources/loki.torrent."""

import argparse
import io
import json
import os
import re
from collections import OrderedDict


EPISODE_RE = re.compile(r"[Ss](\d{1,2})[Ee](\d{1,2})")
VIDEO_EXTENSIONS = {".avi", ".mkv", ".mov", ".mp4", ".wmv"}


def bdecode(data):
    stream = io.BytesIO(data)

    def peek():
        value = stream.read(1)
        stream.seek(-1, 1)
        return value

    def parse():
        prefix = stream.read(1)
        if prefix == b"i":
            value = b""
            byte = stream.read(1)
            while byte != b"e":
                value += byte
                byte = stream.read(1)
            return int(value)
        if prefix == b"l":
            result = []
            while peek() != b"e":
                result.append(parse())
            stream.read(1)
            return result
        if prefix == b"d":
            result = OrderedDict()
            while peek() != b"e":
                key = parse()
                result[key] = parse()
            stream.read(1)
            return result
        if b"0" <= prefix <= b"9":
            length = prefix
            byte = stream.read(1)
            while byte != b":":
                length += byte
                byte = stream.read(1)
            return stream.read(int(length))
        raise ValueError(f"Neplatný bencode prefix: {prefix!r}")

    return parse()


def torrent_paths(torrent_path):
    with open(torrent_path, "rb") as source:
        info = bdecode(source.read()).get(b"info", {})

    if b"files" in info:
        return [
            "/".join(part.decode("utf-8", "ignore") for part in item[b"path"])
            for item in info[b"files"]
        ]
    if b"name" in info and b"length" in info:
        return [info[b"name"].decode("utf-8", "ignore")]
    raise ValueError("Nepodporovaná struktura torrentu.")


def build_map(torrent_path, torrent_filename):
    # Stejně jako Clarksonova předloha počítáme indexy přes abecedně
    # seřazený úplný seznam souborů, který používá Elementum.
    all_paths = sorted(torrent_paths(torrent_path))
    e2idx = {}
    idx2e = {}
    seasons = set()

    for index, path in enumerate(all_paths):
        if os.path.splitext(path)[1].lower() not in VIDEO_EXTENSIONS:
            continue
        match = EPISODE_RE.search(os.path.basename(path))
        if not match:
            continue
        season = int(match.group(1))
        episode = int(match.group(2))
        key = f"S{season:02d}E{episode:02d}"
        e2idx[key] = index
        idx2e[str(index)] = [key]
        seasons.add(season)

    return {
        "torrents": {str(season): torrent_filename for season in sorted(seasons)},
        "e2idx": dict(sorted(e2idx.items())),
        "idx2e": idx2e,
    }


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    default_torrent = os.path.join(script_dir, "loki.torrent")
    default_output = os.path.join(script_dir, "map.json")

    parser = argparse.ArgumentParser(description="Loki – generátor mapy epizod")
    parser.add_argument("--torrent", "-t", default=default_torrent)
    parser.add_argument("--out-json", default=default_output)
    args = parser.parse_args()

    result = build_map(args.torrent, os.path.basename(args.torrent))
    with open(args.out_json, "w", encoding="utf-8") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)

    print(f"Mapa vytvořena: {len(result['e2idx'])} epizod -> {args.out_json}")
    for key, index in result["e2idx"].items():
        print(f"  {key} -> Elementum index {index}")


if __name__ == "__main__":
    main()
