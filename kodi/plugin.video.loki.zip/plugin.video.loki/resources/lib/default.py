# -*- coding: utf-8 -*-
"""Kodi doplněk pro přehrávání seriálu Loki přes Elementum."""

import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

SHOW_NAME = "Loki"
DEFAULT_TORRENT_FILE = "loki.torrent"


def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def addon_path():
    return xbmcaddon.Addon().getAddonInfo("path")


def load_json(filename):
    try:
        path = os.path.join(addon_path(), "resources", filename)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as source:
                return json.load(source)
    except Exception as exc:
        xbmc.log(
            f"[loki] Chyba při načítání {filename}: {exc}",
            level=xbmc.LOGWARNING,
        )
    return {}


def get_torrent_path(season_num):
    data_map = load_json("map.json")
    torrent_file = data_map.get("torrents", {}).get(
        str(season_num), DEFAULT_TORRENT_FILE
    )
    return os.path.join(addon_path(), "resources", torrent_file), torrent_file


def list_seasons():
    xbmcplugin.setPluginCategory(_HANDLE, SHOW_NAME)
    xbmcplugin.setContent(_HANDLE, "tvshows")

    e2idx = load_json("map.json").get("e2idx", {})
    seasons = sorted({key[:3] for key in e2idx if key.startswith("S")})

    if not seasons:
        xbmcgui.Dialog().notification(
            "Chyba",
            "map.json je prázdný nebo chybí.",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    for season_key in seasons:
        season_num = int(season_key[1:])
        label = f"Série {season_num}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo(
            "video",
            {
                "title": label,
                "tvshowtitle": SHOW_NAME,
                "season": season_num,
                "mediatype": "season",
            },
        )
        url = f"{_URL}?action=list_episodes&season={season_num}"
        xbmcplugin.addDirectoryItem(
            handle=_HANDLE, url=url, listitem=item, isFolder=True
        )

    xbmcplugin.endOfDirectory(_HANDLE)


def list_episodes(season_num):
    xbmcplugin.setPluginCategory(_HANDLE, f"{SHOW_NAME} – Série {season_num}")
    xbmcplugin.setContent(_HANDLE, "episodes")

    e2idx = load_json("map.json").get("e2idx", {})
    metadata = load_json("metadata.json")
    season_key = f"S{season_num:02d}"
    episode_keys = sorted(key for key in e2idx if key.startswith(season_key))

    if not episode_keys:
        xbmcgui.Dialog().notification(
            "Chyba",
            f"Série {season_num} nebyla nalezena v map.json.",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    torrent_path, torrent_file = get_torrent_path(season_num)
    if not os.path.exists(torrent_path):
        xbmcgui.Dialog().notification(
            "Chyba",
            f"Torrent soubor nenalezen: resources/{torrent_file}",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    torrent_uri = urllib.parse.quote_plus(torrent_path)

    for key in episode_keys:
        episode_num = int(key[4:])
        metadata_item = metadata.get(key, {})
        title = metadata_item.get("title", f"Epizoda {episode_num}")
        plot = metadata_item.get("plot", "Popis není k dispozici.")
        thumb = metadata_item.get("thumb", "")
        display_title = f"{key} – {title}"

        elementum_url = (
            "plugin://plugin.video.elementum/play"
            f"?uri={torrent_uri}&index={e2idx[key]}"
        )
        play_url = (
            f"{_URL}?action=play&uri={urllib.parse.quote_plus(elementum_url)}"
        )

        item = xbmcgui.ListItem(label=display_title)
        item.setInfo(
            "video",
            {
                "title": display_title,
                "episode": episode_num,
                "season": season_num,
                "plot": plot,
                "tvshowtitle": SHOW_NAME,
                "mediatype": "episode",
            },
        )
        if thumb:
            item.setArt({"thumb": thumb, "icon": thumb, "fanart": thumb})
        item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            handle=_HANDLE, url=play_url, listitem=item, isFolder=False
        )

    xbmcplugin.endOfDirectory(_HANDLE)


def play_item(uri):
    item = xbmcgui.ListItem(path=uri)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=item)


def router():
    params = get_params()
    action = params.get("action")

    if action == "play":
        # parse_qsl už dekóduje vnější query parametr. Vnitřní uri torrentu
        # musí zůstat URL-enkódované pro Elementum.
        play_item(params.get("uri", ""))
    elif action == "list_episodes":
        list_episodes(int(params.get("season", 1)))
    else:
        list_seasons()


if __name__ == "__main__":
    router()
