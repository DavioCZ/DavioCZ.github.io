# -*- coding: utf-8 -*-
"""Stáhne česká metadata epizod seriálu Loki z TMDB."""

import argparse
import json
import os
import time
import urllib.parse
import urllib.request


TMDB_API_KEY = "cc58aa7b24e4b6e297f8ec4b5ee0931c"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_SHOW_ID = 84958


def tmdb_get(endpoint, language):
    query = urllib.parse.urlencode(
        {"api_key": TMDB_API_KEY, "language": language}
    )
    request = urllib.request.Request(
        f"{TMDB_BASE_URL}{endpoint}?{query}",
        headers={"User-Agent": "Kodi Loki metadata builder"},
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        return json.loads(response.read().decode("utf-8"))


def build_metadata(show_id):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, "metadata.json")
    metadata = {}

    for season_num in (1, 2):
        cs_data = tmdb_get(f"/tv/{show_id}/season/{season_num}", "cs-CZ")
        en_data = tmdb_get(f"/tv/{show_id}/season/{season_num}", "en-US")
        en_episodes = {
            item["episode_number"]: item for item in en_data.get("episodes", [])
        }

        for cs_item in cs_data.get("episodes", []):
            episode_num = cs_item.get("episode_number")
            if episode_num is None:
                continue
            en_item = en_episodes.get(episode_num, {})
            image_path = cs_item.get("still_path") or en_item.get("still_path")
            key = f"S{season_num:02d}E{episode_num:02d}"
            metadata[key] = {
                "title": cs_item.get("name")
                or en_item.get("name")
                or f"Epizoda {episode_num}",
                "plot": cs_item.get("overview")
                or en_item.get("overview")
                or "Popis není k dispozici.",
                "thumb": (
                    f"https://image.tmdb.org/t/p/w500{image_path}"
                    if image_path
                    else ""
                ),
            }
        time.sleep(0.25)

    with open(output_file, "w", encoding="utf-8") as output:
        json.dump(metadata, output, ensure_ascii=False, indent=2)
    print(f"Uloženo {len(metadata)} epizod -> {output_file}")


def main():
    global TMDB_API_KEY
    parser = argparse.ArgumentParser(description="Loki – generátor metadat z TMDB")
    parser.add_argument("--api-key", default=TMDB_API_KEY)
    parser.add_argument("--show-id", type=int, default=TMDB_SHOW_ID)
    args = parser.parse_args()
    TMDB_API_KEY = args.api_key
    build_metadata(args.show_id)


if __name__ == "__main__":
    main()
