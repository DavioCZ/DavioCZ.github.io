# -*- coding: utf-8 -*-
#
# Naruto + Naruto Shippuden – resources/lib/default.py
# Kodi plugin pro přehrávání obou seriálů přes Elementum.
#
# Struktura menu:
#   Hlavní menu
#     ├── Naruto (2002–2007)         -> bloky po BLOCK_SIZE epizod
#     │     └── E001–E050, ...       -> jednotlivé epizody
#     └── Naruto Shippuden           -> bloky po BLOCK_SIZE epizod
#           └── E001–E050, ...       -> jednotlivé epizody
#
# Soubory v resources/:
#   naruto/naruto.torrent            <- zkopíruj svůj torrent
#   naruto/map.json                  <- generuje naruto/build_map.py
#   naruto/metadata.json             <- generuje naruto/build_metadata.py
#   shippuden/naruto-shippuden.torrent
#   shippuden/map.json
#   shippuden/metadata.json

import sys
import os
import urllib.parse
import json
import time
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from fillers import is_visible_episode, visible_episode_numbers
from progress import load_progress

_URL    = sys.argv[0]
_HANDLE = int(sys.argv[1])

BLOCK_SIZE = 50
SERIES_ORDER = ('naruto', 'shippuden')
PLAYBACK_PROPERTY_PREFIX = 'plugin.video.naruto.playback.'

SERIES = {
    'naruto': {
        'label':    'Naruto (2002–2007)',
        'folder':   'naruto',
        'torrent':  'naruto.torrent',
        'total':    220,
        'tvshow':   'Naruto',
        'season':   1,
    },
    'shippuden': {
        'label':    'Naruto Shippuden',
        'folder':   'shippuden',
        'torrent':  'naruto-shippuden.torrent',
        'total':    500,
        'tvshow':   'Naruto: Shippuden',
        'season':   1,
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_params():
    paramstring = sys.argv[2][1:]
    if paramstring:
        return dict(urllib.parse.parse_qsl(paramstring))
    return {}


def set_playback_context(series_id, ep_num):
    if not series_id or not ep_num:
        return

    window = xbmcgui.Window(10000)
    window.setProperty(PLAYBACK_PROPERTY_PREFIX + 'series', str(series_id))
    window.setProperty(PLAYBACK_PROPERTY_PREFIX + 'episode', str(int(ep_num)))
    window.setProperty(PLAYBACK_PROPERTY_PREFIX + 'time', str(time.time()))


def skip_fillers_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('skip_fillers')
    except AttributeError:
        return xbmcaddon.Addon().getSetting('skip_fillers') == 'true'
    except Exception:
        return False


def load_json_file(series_folder, filename):
    try:
        addon      = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        file_path  = os.path.join(addon_path, 'resources', series_folder, filename)
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"[naruto] Chyba při načítání {series_folder}/{filename}: {e}",
                 level=xbmc.LOGWARNING)
    return {}


def get_torrent_path(series_folder, torrent_name):
    addon      = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    return os.path.join(addon_path, 'resources', series_folder, torrent_name)


def episode_key(ep_num):
    return f"E{ep_num:03d}"


def find_next_episode(series_id, ep_num, data_map, skip_fillers=False):
    cfg = SERIES[series_id]
    e2idx = data_map.get('e2idx', {})
    current_idx = e2idx.get(episode_key(ep_num))

    for next_ep in range(ep_num + 1, cfg['total'] + 1):
        if not is_visible_episode(series_id, next_ep, skip_fillers):
            continue

        next_key = episode_key(next_ep)
        if next_key not in e2idx:
            continue
        if current_idx is not None and e2idx.get(next_key) == current_idx:
            continue
        return next_ep
    return None


def first_available_episode(series_id, data_map, skip_fillers=False):
    return find_next_episode(series_id, 0, data_map, skip_fillers)


def make_episode_play_url(series_id, ep_num):
    cfg = SERIES.get(series_id)
    if not cfg:
        return None

    torrent_path = get_torrent_path(cfg['folder'], cfg['torrent'])
    if not os.path.exists(torrent_path):
        return None

    data_map = load_json_file(cfg['folder'], 'map.json')
    metadata = load_json_file(cfg['folder'], 'metadata.json')
    torrent_uri = urllib.parse.quote_plus(torrent_path)
    episode_item = make_episode_item(cfg, torrent_uri, data_map, metadata, ep_num)
    if not episode_item:
        return None

    _, elementum_url, _ = episode_item
    return (
        f"{_URL}?action=play"
        f"&series={series_id}&episode={ep_num}"
        f"&uri={urllib.parse.quote_plus(elementum_url)}"
    )


def get_continue_target():
    skip_fillers = skip_fillers_enabled()
    progress = load_progress()
    last = progress.get('last') if isinstance(progress, dict) else None

    if isinstance(last, dict):
        series_id = last.get('series')
        try:
            last_ep = int(last.get('episode', 0))
        except Exception:
            last_ep = 0
    else:
        series_id = None
        last_ep = 0

    if series_id not in SERIES_ORDER:
        series_id = SERIES_ORDER[0]
        last_ep = 0

    start_index = SERIES_ORDER.index(series_id)
    for order_index in range(start_index, len(SERIES_ORDER)):
        current_series = SERIES_ORDER[order_index]
        cfg = SERIES[current_series]
        data_map = load_json_file(cfg['folder'], 'map.json')
        from_ep = last_ep if current_series == series_id else 0
        next_ep = find_next_episode(current_series, from_ep, data_map, skip_fillers)
        if not next_ep and from_ep == 0:
            next_ep = first_available_episode(current_series, data_map, skip_fillers)
        if next_ep:
            return current_series, next_ep

    return None, None


def continue_label(series_id, ep_num):
    meta = get_episode_metadata(series_id, ep_num)
    title = meta.get('title') or f"Epizoda {ep_num}"
    return f"Pokračovat - E{ep_num:03d} {title}"


def get_episode_metadata(series_id, ep_num):
    cfg = SERIES[series_id]
    metadata = load_json_file(cfg['folder'], 'metadata.json')
    return metadata.get(episode_key(ep_num), {})


def continue_item(series_id, ep_num):
    cfg = SERIES[series_id]
    meta = get_episode_metadata(series_id, ep_num)
    title = meta.get('title') or f"Epizoda {ep_num}"
    plot = meta.get('plot') or 'Popis neni k dispozici.'
    thumb = meta.get('thumb') or ''
    label = continue_label(series_id, ep_num)

    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {
        'title': label,
        'episode': ep_num,
        'season': cfg['season'],
        'plot': plot,
        'tvshowtitle': cfg['tvshow'],
        'mediatype': 'episode',
    })
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
    else:
        li.setArt({'icon': 'DefaultInProgressShows.png'})
    li.setProperty('IsPlayable', 'true')
    return li


def make_episode_item(cfg, torrent_uri, data_map, metadata, ep_num):
    key = episode_key(ep_num)
    e2idx = data_map.get('e2idx', {})
    e2oidx = data_map.get('e2oidx', e2idx)
    idx2e = data_map.get('idx2e', {})
    oidx2e = data_map.get('oidx2e', idx2e)

    if key not in e2idx:
        return None

    eidx = e2idx[key]
    play_idx = eidx
    paired_keys = oidx2e.get(str(play_idx), idx2e.get(str(eidx), [key]))
    is_multi = len(paired_keys) > 1

    meta = metadata.get(key, {})
    raw_title = meta.get('title', f"Epizoda {ep_num}")
    plot = meta.get('plot', 'Popis neni k dispozici.')
    thumb = meta.get('thumb', '')

    if is_multi:
        others = [k for k in sorted(paired_keys) if k != key]
        suffix = '+'.join(others)
        prefix = f"{key}+{suffix} - "
    else:
        prefix = f"{key} - "

    display_title = prefix + raw_title

    elementum_url = (
        f"plugin://plugin.video.elementum/play"
        f"?uri={torrent_uri}&index={play_idx}&doresume=false"
    )

    li = xbmcgui.ListItem(label=display_title)
    li.setInfo('video', {
        'title':       display_title,
        'episode':     ep_num,
        'season':      cfg['season'],
        'plot':        plot,
        'tvshowtitle': cfg['tvshow'],
        'mediatype':   'episode',
    })
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
    li.setProperty('IsPlayable', 'true')

    return ep_num, elementum_url, li


# ---------------------------------------------------------------------------
# Hlavní menu – výběr seriálu
# ---------------------------------------------------------------------------

def list_series():
    xbmcplugin.setPluginCategory(_HANDLE, "Naruto")
    xbmcplugin.setContent(_HANDLE, 'tvshows')

    continue_series, continue_ep = get_continue_target()
    if continue_series and continue_ep:
        li = continue_item(continue_series, continue_ep)
        url = f"{_URL}?action=continue"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=li, isFolder=False)

    for series_id, cfg in SERIES.items():
        li = xbmcgui.ListItem(label=cfg['label'])
        li.setInfo('video', {
            'title':       cfg['label'],
            'tvshowtitle': cfg['tvshow'],
            'mediatype':   'tvshow',
        })
        url = f"{_URL}?action=list_blocks&series={series_id}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Bloky epizod pro daný seriál
# ---------------------------------------------------------------------------

def list_blocks(series_id):
    cfg = SERIES.get(series_id)
    if not cfg:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, cfg['label'])
    xbmcplugin.setContent(_HANDLE, 'tvshows')

    visible_eps = visible_episode_numbers(
        series_id,
        cfg['total'],
        skip_fillers_enabled(),
    )

    for start in range(0, len(visible_eps), BLOCK_SIZE):
        block_eps = visible_eps[start:start + BLOCK_SIZE]
        ep_from = block_eps[0]
        ep_to = block_eps[-1]
        label = f"Epizody {ep_from:03d}-{ep_to:03d}"

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':       label,
            'tvshowtitle': cfg['tvshow'],
        })
        url = (f"{_URL}?action=list_episodes"
               f"&series={series_id}&from={ep_from}&to={ep_to}")
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Seznam epizod v bloku
# ---------------------------------------------------------------------------

def list_episodes(series_id, ep_from, ep_to):
    cfg = SERIES.get(series_id)
    if not cfg:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    folder       = cfg['folder']
    torrent_name = cfg['torrent']

    label = f"E{ep_from:03d}-E{ep_to:03d}"
    xbmcplugin.setPluginCategory(_HANDLE, f"{cfg['label']} - {label}")
    xbmcplugin.setContent(_HANDLE, 'episodes')

    torrent_path = get_torrent_path(folder, torrent_name)
    if not os.path.exists(torrent_path):
        xbmcgui.Dialog().notification(
            "Chyba",
            f"Torrent soubor nenalezen:\nresources/{folder}/{torrent_name}",
            xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    data_map    = load_json_file(folder, 'map.json')
    metadata    = load_json_file(folder, 'metadata.json')
    torrent_uri = urllib.parse.quote_plus(torrent_path)

    episode_items = []
    skip_fillers  = skip_fillers_enabled()
    for ep_num in range(ep_from, ep_to + 1):
        if not is_visible_episode(series_id, ep_num, skip_fillers):
            continue

        episode_item = make_episode_item(cfg, torrent_uri, data_map, metadata, ep_num)
        if not episode_item:
            continue

        _, elementum_url, li = episode_item
        play_url = (f"{_URL}?action=play"
                    f"&series={series_id}&episode={ep_num}"
                    f"&uri={urllib.parse.quote_plus(elementum_url)}")
        episode_items.append((ep_num, play_url, li))

    for _, url, item in episode_items:
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url,
                                    listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE)


# ---------------------------------------------------------------------------
# Přehrání
# ---------------------------------------------------------------------------

def play_item(uri, series_id=None, ep_num=None):
    li = xbmcgui.ListItem(path=uri)
    if series_id and ep_num:
        set_playback_context(series_id, ep_num)
        cfg = SERIES.get(series_id, {})
        meta = get_episode_metadata(series_id, ep_num)
        title = meta.get('title') or f"Epizoda {ep_num}"
        li.setInfo('video', {
            'title':       title,
            'episode':     ep_num,
            'season':      cfg.get('season', 1),
            'tvshowtitle': cfg.get('tvshow', ''),
            'mediatype':   'episode',
        })
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)


def play_episode(series_id, ep_num):
    play_url = make_episode_play_url(series_id, ep_num)
    if not play_url:
        xbmcgui.Dialog().notification(
            "Chyba",
            "Nelze najít epizodu pro pokračování.",
            xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    params = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(play_url).query))
    raw_uri = params.get('uri', '')
    play_item(urllib.parse.unquote_plus(raw_uri), series_id, ep_num)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def router(paramstring):
    params = get_params()
    action = params.get('action')

    if action == 'play':
        raw_uri = params.get('uri', '')
        series_id = params.get('series')
        try:
            ep_num = int(params.get('episode', 0)) or None
        except Exception:
            ep_num = None
        play_item(urllib.parse.unquote_plus(raw_uri), series_id, ep_num)

    elif action == 'continue':
        series_id, ep_num = get_continue_target()
        if series_id and ep_num:
            play_episode(series_id, ep_num)
        else:
            xbmcgui.Dialog().notification(
                "Naruto",
                "Neni k dispozici dalsi epizoda.",
                xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(_HANDLE)

    elif action == 'list_blocks':
        series_id = params.get('series', 'naruto')
        list_blocks(series_id)

    elif action == 'list_episodes':
        series_id = params.get('series', 'naruto')
        ep_from   = int(params.get('from', 1))
        ep_to     = int(params.get('to', BLOCK_SIZE))
        list_episodes(series_id, ep_from, ep_to)

    else:
        list_series()


if __name__ == '__main__':
    router(sys.argv[2])
