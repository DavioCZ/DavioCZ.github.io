# This file makes 'resources/lib' a Python package.
