# -*- coding: utf-8 -*-
"""
Base interfaces for host resolvers.
"""
from typing import Protocol, List, Optional, TypedDict

class File(TypedDict):
    """Represents a file found by a search."""
    name: str
    size: str
    page_url: str
    length: str

class HostResolver(Protocol):
    """
    A protocol that all hoster resolver modules should implement.
    """
    name: str

    def search(self, query: str, limit: int = 50) -> List[File]:
        """
        Searches the host for a given query.
        Returns a list of File objects.
        """
        ...

    def resolve(self, page_url: str) -> Optional[str]:
        """
        Tries to resolve a page URL into a direct, streamable media URL.
        Returns the streamable URL as a string, or None if it fails.
        """
        ...
