# -*- coding: utf-8 -*-
"""
Resolver for FastShare.cz free downloads.
"""
import re
import time
import logging
import requests
from bs4 import BeautifulSoup
from typing import Optional
from urllib.parse import urljoin

# Setup
SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36"
})
LOGGER = logging.getLogger(__name__)
name = "fastshare"

def resolve(page_url: str, timeout: int = 15) -> Optional[str]:
    """
    Resolves a FastShare.cz or related URL into a direct, streamable media URL.
    This function is robust and handles multiple scenarios, including direct
    redirects and pages with JavaScript-based redirects.
    """
    try:
        LOGGER.debug("FastShare Resolver: Starting resolution for %s", page_url)
        
        # First, do a HEAD request to check headers and final URL without downloading content.
        head_r = SESSION.head(page_url, timeout=timeout, allow_redirects=True)
        head_r.raise_for_status()
        
        final_url = head_r.url
        content_type = head_r.headers.get("Content-Type", "").lower()
        
        # Scenario 1: The final URL is already a video/binary file.
        is_direct_link = (
            "video" in content_type or
            "application/octet-stream" in content_type or
            "sdilej_free.php" in final_url
        )
        if is_direct_link:
            LOGGER.info("FastShare: Resolved directly to streamable URL via HEAD: %s", final_url)
            return final_url

        # Scenario 2: The page is HTML, possibly with a JS redirect.
        # Now we do a GET request to fetch the page content.
        LOGGER.debug("FastShare: URL is an HTML page, performing GET to parse for JS redirect.")
        get_r = SESSION.get(page_url, timeout=timeout, allow_redirects=True)
        get_r.raise_for_status()

        # Look for a script tag containing the download link.
        js_redirect_match = re.search(r"window\.location\s*=\s*['\"]([^'\"]+)['\"]", get_r.text)
        
        if js_redirect_match:
            js_url = js_redirect_match.group(1)
            # The URL in the script might be relative, so we join it with the page URL.
            absolute_js_url = urljoin(get_r.url, js_url)
            LOGGER.info("FastShare: Found JS redirect. Following to: %s", absolute_js_url)
            
            # Now, we do a final HEAD request on this URL to get the final link.
            final_head = SESSION.head(absolute_js_url, allow_redirects=True, timeout=timeout)
            final_head.raise_for_status()
            
            LOGGER.info("FastShare: Resolved final URL after JS redirect: %s", final_head.url)
            return final_head.url

        LOGGER.warning("FastShare: Could not find a direct link or a known JS redirect.")
        return None

    except requests.exceptions.RequestException as e:
        LOGGER.error("FastShare: A network error occurred: %s", e)
        return None
    except Exception as e:
        LOGGER.error("FastShare: An unexpected error occurred: %s", e)
        return None
