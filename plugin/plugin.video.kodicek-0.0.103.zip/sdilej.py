# -*- coding: utf-8 -*-
import requests
import re
import html
import logging
from urllib.parse import quote, urljoin
from typing import Optional, Tuple, List, Dict, Any

# --- Základné nastavenie ---
_sess = requests.Session()
_sess.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'cs,sk;q=0.8,en-US;q=0.5,en;q=0.3',
})
BASE_URL = 'https://www.sdilej.cz'
LOGGER = logging.getLogger(__name__)

# --- Regulárne výrazy na parsovanie ---
SEARCH_RESULTS_RE = re.compile(
    r'<div class="videobox-desc">.*?'
    r'<p class="videobox-title"><a href="(?P<url>[^"]+)"[^>]*>(?P<name>.+?)</a></p>.*?'
    r'<p>(?P<size>[\d.,]+\s*\w*B)',
    re.DOTALL | re.IGNORECASE
)
FREE_DOWNLOAD_RE = re.compile(r'<a href="(?P<url>[^"]+)"[^>]*>\s*Stáhnout zdarma\s*</a>')
STREAM_URL_RE = re.compile(r'data-url="(?P<url>https?://[^"]+)"')

def search(query: str, limit: int = 25) -> List[Dict[str, Any]]:
    """
    Vyhľadá na Sdilej.cz a vráti zoznam výsledkov.
    """
    results = []
    safe_query = quote(query.strip())
    search_url = f'{BASE_URL}/{safe_query}/s'
    try:
        resp = _sess.get(search_url, timeout=10)
        resp.raise_for_status()
        html_content = resp.text
        matches = SEARCH_RESULTS_RE.finditer(html_content)
        for match in matches:
            if len(results) >= limit: break
            data = match.groupdict()
            name = html.unescape(data.get('name', '').strip())
            page_url = html.unescape(data.get('url', ''))
            size = data.get('size', '').strip()
            if name and page_url:
                results.append({"name": name, "url": page_url, "size": size})
    except requests.RequestException as e:
        LOGGER.error(f"Sdilej.cz search failed for query '{query}': {e}")
    return results

def resolve(page_url: str) -> Optional[Tuple[str, str]]:
    """
    Preloží URL a extrahuje finálny stream link rýchlo a efektívne.
    """
    try:
        # KROK 1: Stránka súboru
        resp1 = _sess.get(page_url, allow_redirects=True, timeout=5)
        resp1.raise_for_status()
        
        # KROK 2: Tlačidlo "Stáhnout zdarma"
        match1 = FREE_DOWNLOAD_RE.search(resp1.text)
        if not match1:
            LOGGER.error(f"Could not find 'Stáhnout zdarma' button on {resp1.url}")
            return None
        
        # KROK 3: Stránka s časovačom
        next_url = urljoin(BASE_URL, match1.group('url'))
        
        # Trik pre rýchlosť: použijeme stream=True a čítame po kúskoch
        with _sess.get(next_url, allow_redirects=True, timeout=5, stream=True) as resp2:
            resp2.raise_for_status()
            final_page_url = resp2.url
            
            # Prečítame len prvých pár KB, kde sa data-url nachádza
            chunk = resp2.content[:4096].decode('utf-8', errors='ignore')
            
            match2 = STREAM_URL_RE.search(chunk)
            if not match2:
                LOGGER.error(f"Could not find stream URL (data-url) in the initial chunk of {final_page_url}")
                return None
                
            stream_url = html.unescape(match2.group('url'))
            
            LOGGER.info(f"Successfully resolved stream URL: {stream_url}")
            return stream_url, final_page_url

    except requests.RequestException as e:
        LOGGER.error(f"Failed to resolve {page_url}: {e}")
        return None
