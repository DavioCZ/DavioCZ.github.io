import os
import sys
import zipfile

# --- Configuration ---
ADDON_ID = 'plugin.video.kodicek'
BUILD_DIR = 'build'

# Soubory a adresáře, které mají být zahrnuty v ZIPu.
# Toto zajišťuje, že do balíčku nebudou zahrnuty vývojové skripty a soubory.
FILES_TO_INCLUDE = [
    'addon.xml',
    'CHANGELOG.md',
    'fanart.jpg',
    'icon.png',
    'kodicek.py',
    'LICENSE',
    'README.md',
    '__init__.py',
    'history.py',
    'md5crypt.py',
    'resume_helper.py',
    'settings.xml',
    'tmdb.py'
]
DIRS_TO_INCLUDE = [
    'resources'
]

# --- Script ---
def create_plugin_zip(version):
    """
    Vytvoří ZIP soubor pro Kodi plugin s požadovanou strukturou pro repozitář.
    Verze je předána jako argument.
    """
    # Cesta k výslednému ZIP souboru, např. build/zips/plugin.video.kodicek/plugin.video.kodicek-1.8.0.zip
    zip_filename = f'{ADDON_ID}-{version}.zip'
    zip_path = os.path.join(BUILD_DIR, 'zips', ADDON_ID, zip_filename)

    # Vytvoření cílové adresářové struktury
    os.makedirs(os.path.dirname(zip_path), exist_ok=True)
    
    print(f"\n--- Vytváření ZIP balíčku ---")
    print(f"  Cílový soubor: {zip_path}")

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Přidání jednotlivých souborů
        for file in FILES_TO_INCLUDE:
            if os.path.exists(file):
                arcname = os.path.join(ADDON_ID, file)
                zipf.write(file, arcname)
            else:
                print(f"Varování: Soubor '{file}' neexistuje a nebude přidán do ZIPu.")

        # Přidání celých adresářů
        for directory in DIRS_TO_INCLUDE:
            if os.path.exists(directory):
                for root, _, files in os.walk(directory):
                    for file in files:
                        # Vyloučení dočasných souborů Pythonu
                        if '__pycache__' in root or file.endswith('.pyc'):
                            continue
                        file_path = os.path.join(root, file)
                        # Vytvoření správné cesty v archivu (např. plugin.video.kodicek/resources/lib/...)
                        arcname = os.path.join(ADDON_ID, file_path)
                        zipf.write(file_path, arcname)
            else:
                 print(f"Varování: Adresář '{directory}' neexistuje a nebude přidán do ZIPu.")

    print(f"Úspěšně vytvořen soubor: {zip_path}")

if __name__ == "__main__":
    # Získání verze z příkazového řádku
    if len(sys.argv) < 2:
        print("Chyba: Nebyla zadána verze pluginu jako argument.")
        print("Použití: python create_plugin_zip.py <verze_pluginu>")
        sys.exit(1)
    
    plugin_version = sys.argv[1]
    create_plugin_zip(plugin_version)
