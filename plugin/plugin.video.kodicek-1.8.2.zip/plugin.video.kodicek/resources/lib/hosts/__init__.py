# This file makes the 'hosts' directory a Python package.
