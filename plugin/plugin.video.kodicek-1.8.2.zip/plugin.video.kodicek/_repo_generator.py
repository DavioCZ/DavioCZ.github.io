import os
import hashlib
import zipfile
import sys
import xml.etree.ElementTree as ET

def create_repository_zip():
    """Zabalí adresář repository.kodicek do ZIPu se správnou strukturou."""
    repo_dir = 'repository.kodicek'
    build_dir = 'build'
    os.makedirs(build_dir, exist_ok=True)
    zip_path = os.path.join(build_dir, 'repository.kodicek.zip')
    
    if not os.path.exists(repo_dir):
        print(f"Chyba: Adresář '{repo_dir}' neexistuje.")
        return

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(repo_dir):
            for file in files:
                file_path = os.path.join(root, file)
                # Cesta v ZIPu musí začínat názvem adresáře
                arcname = os.path.join(repo_dir, os.path.relpath(file_path, repo_dir))
                zipf.write(file_path, arcname)
    print(f"Vytvořen soubor: {zip_path}")


class Generator:
    """
    Generuje addons.xml a addons.xml.md5 pro Kodi repozitář.
    Před generováním aktualizuje addon.xml repozitáře na základě verze pluginu.
    """

    def __init__(self):
        """
        Hlavní metoda, která řídí celý proces generování.
        """
        # Získání verze z příkazového řádku
        if len(sys.argv) < 2:
            print("Chyba: Nebyla zadána verze pluginu jako argument.")
            print("Použití: python _repo_generator.py <verze_pluginu>")
            sys.exit(1)
        self.plugin_version = sys.argv[1]

        # 1. Aktualizace souboru addon.xml pro repozitář
        self._update_repo_addon_xml()

        # 2. Vytvoření ZIPu s obsahem repozitáře (po aktualizaci addon.xml)
        self.build_dir = "build"
        os.makedirs(self.build_dir, exist_ok=True)
        create_repository_zip()
        
        # 3. Generování finálních souborů (addons.xml a MD5 hash)
        self._generate_addons_file()
        self._generate_md5_file()
        print("\n>>> Generování repozitáře úspěšně dokončeno. <<<")

    def _update_repo_addon_xml(self):
        """
        Aktualizuje soubor repository.kodicek/addon.xml:
        - Nastaví novou verzi repozitáře (odvozenou z verze pluginu).
        - Aktualizuje URL cesty pro info, checksum a datadir na GitHub Pages.
        """
        repo_addon_xml_path = os.path.join('repository.kodicek', 'addon.xml')
        
        # Výpočet verze repozitáře ve formátu 0.1.Z (kde Z je z verze pluginu X.Y.Z)
        try:
            z_part = self.plugin_version.split('.')[-1]
            repo_version = f"0.1.{z_part}"
        except IndexError:
            print(f"Chyba: Neočekávaný formát verze '{self.plugin_version}'. Očekáván formát X.Y.Z.")
            sys.exit(1)

        print(f"\n--- Aktualizace {repo_addon_xml_path} ---")
        print(f"  Nová verze repozitáře: {repo_version}")

        # Použití ElementTree pro bezpečnou úpravu XML
        try:
            tree = ET.parse(repo_addon_xml_path)
            root = tree.getroot()
        except (ET.ParseError, FileNotFoundError) as e:
            print(f"Chyba při parsování XML souboru {repo_addon_xml_path}: {e}")
            sys.exit(1)

        # Aktualizace verze v kořenovém elementu <addon>
        root.set('version', repo_version)

        # Základní URL pro GitHub Pages
        base_url = "https://daviocz.github.io"

        # Najít a aktualizovat elementy v <extension>
        extension = root.find('extension[@point="xbmc.addon.repository"]')
        if extension is not None:
            # Info URL
            info = extension.find('info')
            if info is None: info = ET.SubElement(extension, 'info')
            info.text = f"{base_url}/addons.xml"
            info.set('compressed', 'false')
            print(f"  <info> -> {info.text}")

            # Checksum URL
            checksum = extension.find('checksum')
            if checksum is None: checksum = ET.SubElement(extension, 'checksum')
            checksum.text = f"{base_url}/addons.xml.md5"
            print(f"  <checksum> -> {checksum.text}")

            # Datadir URL
            datadir = extension.find('datadir')
            if datadir is None: datadir = ET.SubElement(extension, 'datadir')
            datadir.text = f"{base_url}/"
            datadir.set('zip', 'true')
            print(f"  <datadir> -> {datadir.text}")
        else:
            print(f"Varování: V {repo_addon_xml_path} nebyl nalezen tag <extension point=\"xbmc.addon.repository\">.")

        # Uložení změn s XML deklarací pro kompatibilitu
        try:
            tree.write(repo_addon_xml_path, encoding='utf-8', xml_declaration=True)
            print(f"Soubor {repo_addon_xml_path} byl úspěšně aktualizován.")
        except Exception as e:
            print(f"Chyba při ukládání souboru {repo_addon_xml_path}: {e}")
            sys.exit(1)

    def _generate_addons_file(self):
        """
        Skenuje všechny addon.xml soubory a spojí je do jednoho `build/addons.xml`.
        """
        addons = []
        # Prohledávané lokace pro addon.xml
        addon_locations = ['.', 'repository.kodicek']

        print("\n--- Generování build/addons.xml ---")
        for location in addon_locations:
            addon_xml_path = os.path.join(location, "addon.xml")
            if os.path.isfile(addon_xml_path):
                try:
                    with open(addon_xml_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        # Odstranění XML deklarace, pokud existuje, aby byl výsledný soubor validní
                        if content.strip().startswith('<?xml'):
                            content = content.split('?>', 1)[-1].strip()
                        addons.append(content)
                    print(f"-> Zpracován: {addon_xml_path}")
                except Exception as e:
                    print(f"Chyba při čtení souboru {addon_xml_path}: {e}")
            else:
                print(f"-> Soubor nenalezen (přeskakuji): {addon_xml_path}")

        if addons:
            header = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<addons>\n'
            footer = '\n</addons>'
            final_xml = header + "\n\n".join(addons) + footer
            
            addons_xml_path = os.path.join(self.build_dir, "addons.xml")
            with open(addons_xml_path, "w", encoding="utf-8") as f:
                f.write(final_xml)
            print(f"Vytvořen soubor: {addons_xml_path}")
        else:
            print("Nenalezen žádný addon.xml soubor, addons.xml nebylo vytvořeno.")

    def _generate_md5_file(self):
        """
        Vytvoří MD5 hash pro `build/addons.xml` a uloží ho do `build/addons.xml.md5`.
        """
        addons_xml_path = os.path.join(self.build_dir, "addons.xml")
        addons_md5_path = os.path.join(self.build_dir, "addons.xml.md5")
        
        print("\n--- Generování MD5 hashe ---")
        try:
            with open(addons_xml_path, "rb") as f:
                md5_hash = hashlib.md5(f.read()).hexdigest()
            
            with open(addons_md5_path, "w", encoding="utf-8") as f:
                f.write(md5_hash)
            print(f"Vytvořen soubor: {addons_md5_path} ({md5_hash})")
        except FileNotFoundError:
            print(f"Chyba: Soubor {addons_xml_path} neexistuje. MD5 hash nebyl vygenerován.")
        except Exception as e:
            print(f"Chyba při generování MD5: {e}")


if __name__ == "__main__":
    Generator()
