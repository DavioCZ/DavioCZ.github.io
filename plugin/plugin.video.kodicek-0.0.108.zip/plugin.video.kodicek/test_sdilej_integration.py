# test_sdilej_integration.py
import sys
from pathlib import Path
import logging

# Add the project root to the path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

# Enable logging to see the output from the resolvers
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

from resources.lib import sdilej

def test_full_resolve_flow():
    """
    Performs a full, live network test of the sdilej.cz resolver.
    This test requires an active internet connection.
    """
    # This URL is taken from the Kodi logs and may expire.
    # If the test fails, a new, valid URL might be needed from the logs.
    test_url = "https://toplinktracker.com/?x=b65883a4c6b4c6674e03c5edcywrwbea87833fabadbf85tyhebhitsi9e2429b6c8691f5634962c172&y=1e29dcf58b95920f862ebd7b5d43fad6a6f749e67473e228"
    
    print(f"\n\n--- Starting Integration Test for Sdilej Resolver ---")
    print(f"➡️  Resolving URL: {test_url}")

    # Clear the cache to ensure a fresh run
    if hasattr(sdilej.resolve, 'cache_clear'):
        sdilej.resolve.cache_clear()
    
    # We need to bypass our own resolver to get the page content for inspection
    print("--- Bypassing resolver to inspect intermediate page ---")
    import requests
    from urllib.parse import urljoin
    from bs4 import BeautifulSoup

    # Step 1: Get sdilej page
    s = requests.Session()
    s.headers.update({'User-Agent': 'Mozilla/5.0'})
    resp1 = s.get(test_url, allow_redirects=True)
    soup1 = BeautifulSoup(resp1.text, 'html.parser')
    link = soup1.find('a', class_='btn-danger')
    
    if not link:
        print("❌ Could not find download button on initial page.")
        return

    intermediate_url = urljoin(resp1.url, link['href'])
    print(f"Intermediate URL from sdilej.cz: {intermediate_url}")

    # Step 2: Get the fastshare page that contains the JS
    resp2 = s.get(intermediate_url, allow_redirects=True)
    
    print(f"Landed on URL: {resp2.url}")
    print("\n--- Page Content for Inspection ---")
    print(resp2.text)
    print("\n--- End of Page Content ---")

    print("--- Test Finished ---")

if __name__ == "__main__":
    test_full_resolve_flow()
