# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import urllib.parse
import time
import json
import playback_manager # Import nového manažeru

ADDON = xbmcaddon.Addon()
ADDONID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

class AutoPlayService(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.next_stream_url = None
        self.next_episode_info = None
        self.precache_triggered = False
        xbmc.log('[AUTO] Služba pro autoplay spuštěna.', xbmc.LOGINFO)

    def onPlayBackStarted(self):
        """ Resetuje stav při spuštění nového přehrávání. """
        self.next_stream_url = None
        self.next_episode_info = None
        self.precache_triggered = False
        xbmc.log('[AUTO] Přehrávání spuštěno, stav pro pre-caching resetován.', xbmc.LOGINFO)

    def trigger_precache(self):
        """ Spustí logiku přednačítání. """
        if self.precache_triggered:
            return

        self.precache_triggered = True
        xbmc.log('[AUTO] Spouštím přednačítání další epizody.', xbmc.LOGINFO)
        
        creds = self._get_credentials()
        if not creds or not creds.get("token"):
            xbmc.log('[AUTO] Pre-caching selhal: chybí přihlašovací údaje/token.', xbmc.LOGERROR)
            return

        next_episode_info = self._get_next_episode_info()
        if not next_episode_info:
            xbmc.log('[AUTO] Pre-caching: Nepodařilo se určit další epizodu.', xbmc.LOGINFO)
            return

        stream_info = playback_manager.find_best_stream_for_episode(
            token=creds["token"],
            tmdb_id=next_episode_info['tmdb_id'],
            season_number=next_episode_info['season'],
            episode_number=next_episode_info['episode'],
            show_title=next_episode_info['show_title'],
            show_year="",
            autoplay_prefs=next_episode_info['prefs']
        )

        if stream_info and stream_info.get('url'):
            self.next_stream_url = stream_info['url']
            self.next_episode_info = next_episode_info
            xbmc.log(f"[AUTO] Pre-caching úspěšný. URL pro další díl je připraveno: {stream_info['name']}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification(ADDON_NAME, "Načítám další díl...", xbmcgui.NOTIFICATION_INFO, 2000, False)
        else:
            xbmc.log("[AUTO] Pre-caching selhal: Nepodařilo se najít stream pro další díl.", xbmc.LOGWARNING)

    def onPlayBackEnded(self):
        xbmc.log('[AUTO] Přehrávání ukončeno, kontroluji nastavení.', xbmc.LOGINFO)
        
        if not self._is_autoplay_enabled():
            return

        if self.next_stream_url:
            if self.next_episode_info:
                win = xbmcgui.Window(10000)
                win.setProperty(f'{ADDONID}.tvshowtitle', self.next_episode_info['show_title'])
                win.setProperty(f'{ADDONID}.season',      str(self.next_episode_info['season']))
                win.setProperty(f'{ADDONID}.episode',     str(self.next_episode_info['episode']))
                win.setProperty(f'{ADDONID}.tmdb_id',     self.next_episode_info['tmdb_id'])
                win.setProperty(f'{ADDONID}.autoplay_prefs', json.dumps(self.next_episode_info['prefs']))
            xbmc.log('[AUTO] Používám přednačtené URL pro okamžité přehrávání.', xbmc.LOGINFO)
            xbmc.executebuiltin(f'PlayMedia({self.next_stream_url})')
            self.next_stream_url = None
            self.next_episode_info = None
        else:
            xbmc.log('[AUTO] Přednačtené URL nebylo nalezeno. Používám záložní (pomalou) metodu.', xbmc.LOGWARNING)
            # Záložní metoda, pokud pre-caching selhal nebo se nestihl
            self._fallback_play_next()

    def _is_autoplay_enabled(self):
        """ Zkontroluje všechna nastavení, zda má autoplay běžet. """
        if not ADDON.getSettingBool('auto_play_enabled'):
            xbmc.log('[AUTO] Vestavěný autoplay je zakázán v nastavení.', xbmc.LOGINFO)
            return False
        if ADDON.getSettingBool('prefer_upnext') and xbmc.getCondVisibility('System.HasAddon(service.upnext)'):
            xbmc.log('[AUTO] Doplněk "Up Next" je aktivní a preferován.', xbmc.LOGINFO)
            return False
        return True

    def _get_credentials(self):
        """ Získá přihlašovací údaje s čerstvou instancí Addon, aby se načetly aktuální settings. """
        fresh_addon = xbmcaddon.Addon()
        token = fresh_addon.getSetting("ws_token") or fresh_addon.getSetting("token")
        if token:
            return {"token": token}
        xbmc.log('[AUTO] Token pro Webshare nebyl v nastavení nalezen.', xbmc.LOGWARNING)
        return None

    def _get_next_episode_info(self):
        """ Získá informace o další epizodě z properties okna. """
        win = xbmcgui.Window(10000)
        show_title = win.getProperty(f'{ADDONID}.tvshowtitle')
        try:
            season = int(win.getProperty(f'{ADDONID}.season'))
            episode = int(win.getProperty(f'{ADDONID}.episode'))
        except (ValueError, TypeError):
            return None

        if not all([show_title, season > -1, episode > -1]):
            return None

        next_season, next_episode = season, episode + 1
        
        show_structure_str = win.getProperty(f'{ADDONID}.show_structure')
        if show_structure_str:
            try:
                show_structure = json.loads(show_structure_str)
                current_season_info = show_structure.get('seasons', {}).get(str(season))
                if current_season_info and episode >= current_season_info['episode_count']:
                    next_season, next_episode = season + 1, 1
                    if str(next_season) not in show_structure.get('seasons', {}):
                        xbmc.log(f"[AUTO] Konec seriálu '{show_title}'.", xbmc.LOGINFO)
                        return None
            except (json.JSONDecodeError, TypeError):
                pass # Pokud selže, pokračujeme s jednoduchým zvýšením čísla epizody

        autoplay_prefs_str = win.getProperty(f'{ADDONID}.autoplay_prefs') or '[]'
        try:
            prefs = json.loads(autoplay_prefs_str)
        except (json.JSONDecodeError, TypeError):
            prefs = []

        return {
            "show_title": show_title,
            "season": next_season,
            "episode": next_episode,
            "tmdb_id": win.getProperty(f'{ADDONID}.tmdb_id'),
            "prefs": prefs
        }

    def _fallback_play_next(self):
        """ Pomalá metoda spuštění další epizody, pokud selže pre-caching. """
        next_episode_info = self._get_next_episode_info()
        if not next_episode_info:
            xbmc.log('[AUTO] Fallback: Nepodařilo se určit další epizodu.', xbmc.LOGINFO)
            return

        autoplay_prefs_str = json.dumps(next_episode_info['prefs'])
        plugin_url = (f'plugin://{ADDONID}/?action=play_episode'
                      f'&show_title={urllib.parse.quote(next_episode_info["show_title"])}'
                      f'&season_number={next_episode_info["season"]}&episode_number={next_episode_info["episode"]}'
                      f'&tmdb_id={next_episode_info["tmdb_id"]}&silent=1'
                      f'&autoplay_prefs={urllib.parse.quote(autoplay_prefs_str)}')

        xbmc.log(f'[AUTO] Fallback: Spouštím další díl: {next_episode_info["show_title"]} S{next_episode_info["season"]:02d}E{next_episode_info["episode"]:02d}', xbmc.LOGINFO)
        xbmc.executebuiltin(f'PlayMedia({plugin_url})')


if __name__ == '__main__':
    xbmc.log('[AUTO] Inicializace služby Kodíček Autoplay.', xbmc.LOGINFO)
    service = AutoPlayService()
    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        player = xbmc.Player()
        if player.isPlayingVideo():
            try:
                total_time = player.getTotalTime()
                current_time = player.getTime()
                # Spustit, pokud do konce zbývá méně než 60s a celková délka je smysluplná (delší než 1 minuta)
                if total_time > 60 and (total_time - current_time) < 60:
                    service.trigger_precache()
            except Exception as e:
                # getTotalTime může selhat, pokud video ještě není plně načteno
                xbmc.log(f"[AUTO] Chyba při zjišťování času přehrávání: {e}", xbmc.LOGWARNING)

        if monitor.waitForAbort(1): # Kontrolujeme každou sekundu
            break
    
    xbmc.log('[AUTO] Služba Kodíček Autoplay byla ukončena.', xbmc.LOGINFO)
