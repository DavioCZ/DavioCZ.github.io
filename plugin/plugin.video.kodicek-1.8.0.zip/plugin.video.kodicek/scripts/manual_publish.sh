#!/bin/bash

# Lokální fallback skript pro sestavení a publikaci Kodi repozitáře.
# Tento skript replikuje kroky z GitHub Actions workflow pro případ, že by selhal.

# Ukončí skript při první chybě
set -e

# --- 1. Získání verze ---
if [ -z "$1" ]; then
  echo "Chyba: Nebyla zadána verze jako argument."
  echo "Použití: ./scripts/manual_publish.sh <verze>"
  echo "Příklad: ./scripts/manual_publish.sh 1.8.0"
  exit 1
fi
PLUGIN_VERSION=$1
echo "Spouštím manuální build pro verzi: $PLUGIN_VERSION"

# --- 2. Spuštění build skriptů ---
echo -e "\n--- Spouštím Python build skripty... ---"
python _repo_generator.py "$PLUGIN_VERSION"
python create_plugin_zip.py "$PLUGIN_VERSION"
echo "Build skripty dokončeny."

# --- 3. Příprava cílového repozitáře ---
# Klonování nebo vyčištění stávajícího repozitáře
PAGES_REPO_DIR="github-io-manual"
PAGES_REPO_URL="git@github.com:DavioCZ/DavioCZ.github.io.git"

if [ -d "$PAGES_REPO_DIR" ]; then
  echo -e "\n--- Čistím existující adresář '$PAGES_REPO_DIR'... ---"
  cd "$PAGES_REPO_DIR"
  # Smazání všeho kromě .git adresáře
  find . -maxdepth 1 ! -name '.git' ! -name '.gitignore' -exec rm -rf {} +
  cd ..
else
  echo -e "\n--- Klonuji repozitář '$PAGES_REPO_URL' do '$PAGES_REPO_DIR'... ---"
  git clone "$PAGES_REPO_URL" "$PAGES_REPO_DIR"
fi

# --- 4. Kopírování sestavených souborů ---
echo -e "\n--- Kopíruji sestavené soubory... ---"
mkdir -p "${PAGES_REPO_DIR}/zips/plugin.video.kodicek"

cp build/addons.xml "${PAGES_REPO_DIR}/"
cp build/addons.xml.md5 "${PAGES_REPO_DIR}/"
cp build/repository.kodicek.zip "${PAGES_REPO_DIR}/"
cp "build/zips/plugin.video.kodicek/plugin.video.kodicek-${PLUGIN_VERSION}.zip" "${PAGES_REPO_DIR}/zips/plugin.video.kodicek/"
touch "${PAGES_REPO_DIR}/.nojekyll"

echo "Soubory zkopírovány. Struktura cílového adresáře:"
ls -R "$PAGES_REPO_DIR"

# --- 5. Commit a Push (volitelné) ---
echo -e "\n--- Příprava na commit... ---"
cd "$PAGES_REPO_DIR"
git add -A

echo "Následující příkazy proveďte ručně, pokud jste si jisti změnami:"
echo "----------------------------------------------------------------"
echo "cd $PAGES_REPO_DIR"
echo "git commit -m \"Publish Kodi repo v${PLUGIN_VERSION} (manual)\""
echo "git push"
echo "----------------------------------------------------------------"

echo -e "\nManuální publikace je připravena v adresáři '$PAGES_REPO_DIR'."
echo "Zkontrolujte změny a proveďte commit a push ručně."
