# -*- coding: utf-8 -*-
import sys
import os
import re

# Add the library path to sys.path to allow imports
lib_path = os.path.join(os.path.dirname(__file__), 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    # Import the actual function to be tested
    from sdilej import _extract_file_id, SdilejError

    print("--- Running Final Sdilej ID Extraction Tests ---")
    
    # Test cases: URL -> Expected slug/ID
    tests = {
        "https://sdilej.cz/12345678901": "12345678901",
        "https://sdilej.cz/b606e2c7": "b606e2c7",
        "https://sdilej.cz/8de0325f54a91aa29e4074dab8fa58b606e2c7": "8de0325f54a91aa29e4074dab8fa58b606e2c7",
        "https://sdilej.cz/bb1cb9682ae1...6feee83b606e2c7": "bb1cb9682ae1...6feee83b606e2c7",
        "https://invalid.url/": None,
        "https://sdilej.cz/toolongandinvalid": None,
    }
    
    all_passed = True
    for url, expected in tests.items():
        try:
            result = _extract_file_id(url)
            if result == expected:
                print(f"PASS: {url} -> {result}")
            else:
                print(f"FAIL: {url} -> Expected '{expected}', got '{result}'")
                all_passed = False
        except SdilejError as e:
            if expected is None:
                print(f"PASS: {url} -> Correctly raised SdilejError: {e}")
            else:
                print(f"FAIL: {url} -> Unexpectedly raised SdilejError: {e}")
                all_passed = False
        except Exception as e:
            print(f"FAIL: {url} -> Threw unexpected exception: {e}")
            all_passed = False

    print("--- Tests Finished ---")
    if all_passed:
        print("All tests passed successfully!")
    else:
        print("Some tests failed.")

except ImportError as e:
    print(f"Failed to import from sdilej: {e}")
except Exception as e:
    print(f"An error occurred during test setup: {e}")
