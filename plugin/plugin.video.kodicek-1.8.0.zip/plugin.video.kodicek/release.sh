#!/bin/bash
set -e 
if [ -z "$1" ]; then
  echo "CHYBA: Nebyla zadána verze." >&2
  echo "Použití: ./release.sh <verze>" >&2
  exit 1
fi
VERSION=$1
TAG="v$VERSION"
ADDON_XML="addon.xml"
if ! git diff-index --quiet HEAD --; then
    echo "CHYBA: Máte neuložené změny. Commitněte je prosím." >&2
    exit 1
fi
echo "Synchronizuji s 'main' větví..."
git checkout main
git pull origin main
echo "Aktualizuji verzi v $ADDON_XML na $VERSION..."
sed -i "s/version=\"[0-9.]*\"/version=\"$VERSION\"/" "$ADDON_XML"
echo "Provádím commit a tagování..."
git add "$ADDON_XML"
git commit -m "chore(release): bump version to $VERSION"
git tag "$TAG"
echo "Nahrávám změny a tag na GitHub..."
git push origin main
git push origin "$TAG"
echo "----------------------------------------------------"
echo "HOTOVO! Verze $VERSION byla úspěšně vydána."
echo "GitHub Actions workflow se nyní automaticky spustí."
echo "----------------------------------------------------"
